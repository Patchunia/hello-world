package test.java.CucumberTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;

import com.cucumber.listener.ExtentProperties;

import cucumber.api.testng.AbstractTestNGCucumberTests;


@RunWith(Cucumber.class)
@CucumberOptions
(
	features 	= "src/main/resources/Features",
	glue		= {"main.java.StepDefinition"},
	tags		={"@DealerVehicleInstalmentBlankMonthlyInstalmentV1, @P2PSellerDetailsValidEmail3V1, @ClientDashboardPageResumebutton"},
//{"@LoginFunctionality, @DealerPersonalInformation, @DealerResidentialAddress, @DealerEmploymentDetails,@DealerBankingDetails,@DealerPersonalIncome, @DeatlerAbountVehicle, @DealerVehicleInstalment, @ClientDashboard, @TimeoutOnAllPages" },
//{"@StepByStepGuide, @StepByStepGuide,@StepByStepGetInsurance, @StepByStepSignContract,@LoginFunctionality, @HomeLandingPage" },
	//{"@LoginFunctionality", "@ValidApproveit", "@ApproveitTimeoutFunctionality"},
	dryRun		= false, 
	monochrome	= true,
	plugin = {"com.cucumber.listener.ExtentCucumberFormatter:output/report.html"}
	//		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:"}
	//plugin = {"pretty" ,   "json:Report/cucumber.json"}
			)
public class Runner extends AbstractTestNGCucumberTests{
//					static AppiumDriverLocalService service;
					static String strPlatformName;
//					public ExtentTest test;
					
					
					@BeforeTest
					public static void setupTest()
					{
						InputStream input = null;
						Properties prop = new Properties();
						
						try
						{
							input = new FileInputStream("global.properties");
							
							// load a properties file
							prop.load(input);
							
						}
						catch (FileNotFoundException e)
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						catch (IOException e)
						{
							// TODO Auto-generated
							e.printStackTrace();
						}
						
						
					}

					@AfterTest
					public void tearDown() throws IOException  {

		//				test.log(LogStatus.INFO, " Ending test");
						System.out.println(" Ending test ");

						
					}
	
				


//					  @AfterClass
//				        public static void teardown() {
//				            Reporter.loadXMLConfig(new File("/src/test/java/com/cumberpr2/step/Extent-Config.xml"));
//
//				            Reporter.setSystemInfo("os", "windows OSX");
//				            Reporter.setTestRunnerOutput("Sample test runner output message");
//				        }
//
				     @BeforeClass
				     public static void setup() {
				    	 ExtentProperties extentProperties = ExtentProperties.INSTANCE;
				    	    extentProperties.setReportPath("output/myreport.html");
				     }
}



