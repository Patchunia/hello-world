package test.java.CucumberTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import cucumber.api.junit.*;
import org.junit.runner.RunWith;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
//import com.relevantcodes.extentreports.*;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
//import io.appium.java_client.service.local.AppiumDriverLocalService;


@RunWith(Cucumber.class)
@CucumberOptions
(
	features 	= "src/main/resources/Features/",
	glue		= {"src.main.java.StepDefinition/"},
	tags		= {"@DealerResidentialAddressPageContentsCheckV1"},
	dryRun		= false, 
	monochrome	= true,
	plugin = {"com.cucumber.listener.ExtentCucumberFormatter:output/report.html"}

			)

			public class TestRunner extends AbstractTestNGCucumberTests
			{
//				static AppiumDriverLocalService service;
//				static String strPlatformName;
//				public ExtentTest test;
				
				
				@BeforeTest
				public static void setupTest()
				{
					InputStream input = null;
					Properties prop = new Properties();
					
					try
					{
						input = new FileInputStream("global.properties");
						
						// load a properties file
						prop.load(input);
						
					}
					catch (FileNotFoundException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					catch (IOException e)
					{
						// TODO Auto-generated
						e.printStackTrace();
					}
					
					
				}
//
//				@AfterTest
//				public void tearDown() throws IOException  {
//
//	//				test.log(LogStatus.INFO, " Ending test");
//					System.out.println(" Ending test ");
//
//					
//				}
			}



