package main.java.Library;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

import main.java.StepDefinition.CommonSteps;
import cucumber.api.Scenario;
import cucumber.api.java.After;
//import io.appium.java_client.android.AndroidDriver;

public class CommonMethods extends CommonSteps
{
	
	public static String strBuildBatFilePath="";

	public CommonMethods()
	{

		Properties prop = new Properties();
		InputStream input = null;

		try
		{
			input = new FileInputStream("global.properties");

			// load a properties file
			prop.load(input);

			//Retrieve the bat build file path from the properties file
			strBuildBatFilePath = prop.getProperty("npm.BuildFetchBatchFilePath");	    
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	

	//*****************************object synchronization***************************************************
	/**
	 * Description: 
	 * @param driver
	 * @param byType
	 * @param byString
	 * @param time
	 * @return
	 */
	public static WebElement isElementPresnt(WebDriver driver,String byType,String byString,int time)
	{

		WebElement ele = null;

		for(int i=0;i<time;i++)
		{
			try
			{
				if (byType.equals("id"))
				{
					ele=driver.findElement(By.id(byString));
					break;
				}
				else
				{
					ele=driver.findElement(By.xpath(byString));
					break;
				}
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(80);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear");
				}
			}
		}
		return ele;
	}

	//*****************************Take Screen shots***************************************************
	/**
	 * Description: 
	 * @param driver
	 * @param screenshotname
	 * @return
	 */
//	@After
//	public void tearDown(Scenario scenario) {
//	    if (scenario.isFailed()) {
//	      // Take a screenshot...
//	      final byte[] screenshot = ((TakesScreenshot) wdriver).getScreenshotAs(OutputType.BYTES);
//	      scenario.embed(screenshot, "image/png"); // ... and embed it in the report.
//	    }
//	}

	
	public static String captureScreenshot (WebDriver driver,String screenshotname)
	{

		if(driver.equals(wdriver))
		{
			String logFilename = new SimpleDateFormat("YYYYMMddHHmmsss").format(new Date());
			try
			{
				TakesScreenshot ts =(TakesScreenshot)wdriver;
				File  source = ts.getScreenshotAs(OutputType.FILE);
				String dest = strBuildBatFilePath + "/ScreenShots/screenshot"+"_"+screenshotname+"_"+logFilename+".png";
				File destination = new File(dest);
				FileUtils.copyFile(source, destination);
				System.out.println("Screenshot taken: " + screenshotname );
				return dest;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return e.getMessage();
			}   
		}
		else
		{
			String logFilename = new SimpleDateFormat("YYYYMMddHHmmsss").format(new Date());
			try
			{
				TakesScreenshot ts =(TakesScreenshot)driver;
				File  source = ts.getScreenshotAs(OutputType.FILE);
				String dest = strBuildBatFilePath + "/ScreenShots/screenshot"+"_"+screenshotname+"_"+logFilename+".png";
				File destination = new File(dest);
				FileUtils.copyFile(source, destination);
				System.out.println("screen shot taken" + screenshotname );
				return dest;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return e.getMessage();
			}   
		}
	}

	

	//************************************************ Object Synchronization*********************************************************************************************************

	/**
	 * 
	 * @param driver
	 * @param id
	 * @param time
	 * @return
	 */
	public static WebElement isElementPresent(WebDriver driver, String id, int time)
	{
		WebElement ele = null;
		for (int i =0;i<time;i++)
		{
			try
			{
				ele=driver.findElement(By.id(id));
				break;
			}
			catch (Exception e)
			{
				try
				{
					Thread.sleep(400);
				}
				catch (InterruptedException e1)
				{

					System.out.println("Waiting for element to appear");
				}
			}
		}
		return ele;

	}

}
