package main.java.Library;

import java.io.File;
//import javax.mail.BodyPart;
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.Multipart;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
//import javax.mail.BodyPart;
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.Multipart;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.ExtentTest;

public class WebDriverUtilities
{
	WebDriver driver;
	public String time;
	public WebDriverUtilities(WebDriver driver)
	{
		this.driver = driver;
	}

	//*****************************Take Screen shots***************************************************
//	public void takescreenshot(String tagname, String Browser) throws Exception
//	{
//		String logFileName = new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date());
//		if(Browser.equalsIgnoreCase("GC")){
//			JavascriptExecutor jse = (JavascriptExecutor) driver;
//			jse.executeScript("window.scrollBy(0,150)", "20");
//		}
//
//		File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);	
//		try
//		{
//			//FileUtils.copyFile(scr, new File("C:\\Users\\cc305906\\Documents\\Selinium\\Screen shots\\output_"+tagname+""+System.currentTimeMillis()+".jpeg"));
//			FileUtils.copyFile(scr, new File("C:\\Users\\cc305906\\Documents\\Selinium\\Screen shots\\TestResults_"+tagname+"_"+logFileName+".jpeg"));
//		}
//		catch (IOException e)
//		{
//			System.out.println("e");
//		}
//	}
//
//	//*****************************object synchronization***************************************************
//	public static WebElement isElementPresnt(WebDriver driver,String xpath,int time)
//	{
//
//		WebElement ele = null;
//
//		for(int i=0;i<time;i++)
//		{
//			try{
//				ele=driver.findElement(By.xpath(xpath));
//				break;
//			}
//			catch(Exception e)
//			{
//				try 
//				{
//					Thread.sleep(1000);
//				} catch (InterruptedException e1) 
//				{
//					System.out.println("Waiting for element to appear");
//				}
//			}
//
//		}
//		return ele;
//
//	}

	//=================================================================================================================================================
	public static void driverquit(WebDriver driver)
	{
		driver.quit();
	}


	//==============================================================================================================================================
	public static void mailreport()
	{

		// Create object of Property file
		Properties props = new Properties();

		// this will set host of server- you can change based on your requirement 
		props.put("mail.smtp.host", "refer to local repository");

		// set the port of socket factory 
		props.put("mail.smtp.socketFactory.port", "00000");

		// set socket factoryx`
		props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");

		// set the authentication to true
		props.put("mail.smtp.auth", "true");

		// set the port of SMTP server
		props.put("mail.smtp.port", "25");

		props.put("mail.smtp.socketFactory.fallback", "true");

		// This will handle the complete authentication
//		Session session = Session.getDefaultInstance(props,new javax.mail.Authenticator() {
//
//			protected PasswordAuthentication getPasswordAuthentication() {
//
//				return new PasswordAuthentication("kksumanth8@gmail.com", "Soumi@123456");

			}

//		});

//		try {
//
//			// Create object of MimeMessage class
//			Message message = new MimeMessage(session);
//
//
//			// Set the from address
//			message.setFrom(new InternetAddress("kksumanth8@gmail.com"));
//
//			// Set the recipient address
//			message.setRecipients(Message.RecipientType.BCC,InternetAddress.parse("kksumanth8@gmail.com,kksumanth8@gmail.com"));
//
//			// Add the subject link
//			message.setSubject("Testing Execution Report");
//
//			// Create object to add multimedia type content
//			BodyPart messageBodyPart1 = new MimeBodyPart();
//
//			// Set the body of email
//			messageBodyPart1.setText("Hi There,"+"\n"+" please find the attached test execution report, request you to go through it."+"\n"+"Regards"+"\n"+"Krishna");
//
//			// Create another object to add another content
//			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
//
//			// Mention the file which you want to send
//			String filename = "C:\\Users\\cc305906\\workspace\\EMA\\log\\application.html";
//
//			// Create data source and pass the filename
//			DataSource source = new FileDataSource(filename);
//
//			// set the handler
//			messageBodyPart2.setDataHandler(new DataHandler(source));
//
//			// set the file
//			messageBodyPart2.setFileName(filename);
//
//			// Create object of MimeMultipart class
//			Multipart multipart = new MimeMultipart();
//
//			// add body part 1
//			multipart.addBodyPart(messageBodyPart2);
//
//			// add body part 2
//			multipart.addBodyPart(messageBodyPart1);	
//
//			//==========================================The below code is for additional mail===================================================== 
//			// Create another object to add another content
//			MimeBodyPart messageBodyPart3 = new MimeBodyPart();
//
//			// Mention the file which you want to send
//			String filename1 = "C:\\Users\\cc305906\\workspace\\EMA\\Reports\\cucumberhtmlreport\\index.html";
//
//			// Create data source and pass the filename
//			DataSource source1 = new FileDataSource(filename1);
//
//			// set the handler
//			messageBodyPart3.setDataHandler(new DataHandler(source1));
//
//			// set the file
//			messageBodyPart3.setFileName(filename1);
//
//			// Create object of MimeMultipart class
//			Multipart multipart1 = new MimeMultipart();
//
//			// add body part 1
//			multipart.addBodyPart(messageBodyPart3);
//
//			// add body part 2
//			//multipart.addBodyPart(messageBodyPart1);
//			//===================================================================================
//
//			// set the content
//			message.setContent(multipart);
//
//			// finally send the email
//			Transport.send(message);
//
//			System.out.println("========Report Sent sucessfully via mail, please check the mail box=======");
//
//		} catch (MessagingException e) {
//
//			throw new RuntimeException(e);
//
//		}

	}


//}
