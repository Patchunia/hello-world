package main.java.Library;

import java.io.File;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;

//import com.relevantcodes.extentreports.DisplayOrder;
//import com.relevantcodes.extentreports.ExtentReports;

import main.java.StepDefinition.CommonSteps;

public class ExtentManager extends CommonSteps {

	private static ExtentReports extent;

	public static ExtentReports getInstance() {
		if (extent == null) {
			Date d = new Date();
			//String fileName = "Assetic TestExecutionReport_"+ d.toString().replace(":", "_") + ".html";
			String fileName = "MFC_FE_TestExecutionReport.html";
//			extent = new ExtentReports(System.getProperty("user.dir") + "//reports//" + fileName, true, DisplayOrder.NEWEST_FIRST);
//			extent.loadConfig(new File(System.getProperty("user.dir")+ "//ReportsConfig.xml"));
//			extent.addSystemInfo("Selenium version", "3.4.0").addSystemInfo("Environment", "QA");
			
		}
		return extent;
	}
}
