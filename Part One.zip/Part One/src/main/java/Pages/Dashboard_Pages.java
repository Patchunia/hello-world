package main.java.Pages;

public class Dashboard_Pages {
	
	public static String Dashb_AppGreeting_css = ".greeting-title";
	public static String TermsNCondtion_page_xpath = "//div[@class='heading'][contains(text(),'Please confirm below')]";
	public static String TermsNCondition_accept_xpath = "//button[@class='gd-primary-btn']";
	public static String TermsNCondition_exit_xpath = "//div[@class='exitBtn']";
	public static String ResumeApplication_page = "//div[@class='heading']";
	public static String ResumeApplication_personalDetails_xpath="//div[@class='item-text'][contains(text(),'Personal details')]";
	public static String ResumeApplication_ResidentialAddress_xpath="//div[@class='item-text'][contains(text(),'Residential address')]";
	public static String ResumeApplication_EmploymentDetails_xpath="//div[@class='item-text'][contains(text(),'Employement details')]";
	public static String ResumeApplication_FinanceAmount_xpath="//div[@class='item-text'][contains(text(),'Finance amount')]";
	public static String ResumeApplication_Bankingdetails_xpath="//div[@class='item-text'][contains(text(),'Banking details')]";
	public static String ResumeApplication_NextArrow_xpath="//span[@class='next-arrow-icon']";
	public static String ResumeApplication_PersonalIncome_xpath="//div[@class='item-text'][contains(text(),'Personal income')]";
	public static String ResumeApplication_VehicleInstalment_xpath="//div[@class='item-text'][contains(text(),'Vehicle instalment')]";
	public static String ResumeApplication_YourVehicle_xpath="//div[@class='item-text'][contains(text(),'Your Vehicle')]";
	public static String ResumeApplication_PersonalDocuments_xpath="//div[@class='item-text'][contains(text(),'Personal documents')]";
	public static String ResumeApplication_FinancialDocuments_xpath="//div[@class='item-text'][contains(text(),'Financial documents')]";
	public static String ApproveIt_close_btn_xpath="//div[@class='close-icon']";
	public static String ApproveIt_timeout_cancel_btn_xpath="//button[@class='gd-secondary-btn']";
	public static String Approveit_timeout_resend_btn_xpath="//button[@class='gd-primary-btn'][contains(text(),'Resend')]";
			//"//BUTTON[@_ngcontent-c0=''][text()='Resend']";
	public static String Approveit_reject_Ok_btn_xpath="//button[@class='gd-primary-btn'][contains(text(),'Ok')]";
	public static String Approveit_rejected_page_xpath="//div[@class='approvit-msg'][contains(text(),'You have rejected the Approve-it� message')]";
	public static String Approveit_otp_input_xpath="//*[@id='approveItOtp'][@name='approveItOtp']";
	public static String Approveit_otp_submit_btn_xpath="//button[@class='gd-primary-btn'][contains(text(),'Submit')]";
	public static String Approveit_otp_page_xpath="//div[@class='approvit-msg'][contains(text(),'A one-time password(OTP) was sent to')]]";
	public static String Approveit_otp_err_xpath="//div[@class='error-message']";
	public static String Approveit_3times_incorrect_otp_page_xpath="//div[@class='approvit-msg'][contains(text(),'Your one-time password (OTP) has been entered incorrectly 3 times')]";
	public static String Approveit_incorrect_otp_cancel_btn_xpath="//button[@class='gd-primary-btn'][contains(text(),'Cancel')]";
	

}
