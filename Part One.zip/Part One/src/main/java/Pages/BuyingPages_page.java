package main.java.Pages;

public class BuyingPages_page {
	
	public static String buying_dealer_class_xpath= "//div[@class='step-heading'][contains(text(),'I’m buying from a dealership.')]";
	public static String buying_dealer_Nxt_Btn_xpath="//button[@id='dealerflow']";
	public static String buying_P2P_class_xpath= "//div[@class='step-heading'][contains(text(),'I’m buying from a private seller.')]";
	public static String buying_P2P_Nxt_Btn_xpath="//button[@id='privatetoprivateflow']";
	public static String buying_dealer_ViewDetails_Btn_xpath="//div[@id='showDealerDetails']/span[contains(text(),'View details')]";
	public static String buying_P2P_ViewDetails_Btn_xpath="//div[@id='showPrivateSellerDetails']/span[contains(text(),'View details')]";
	public static String buying_page_title_xpath="//p[@class='buying-heading']";
	public static String buying_dealer_viewdetails_title_xpath="//div[@class='heading'][contains(text(),'Buying from a dealership')]";
	public static String buying_dealer_viewDetails_startAppl_xpath="//button[@class='gd-primary-btn'][contains(text(),'Start Application')]";
	public static String buying_dealer_viewDetails_BackBtn_xpath="//div[@class='arrow']";
	public static String buying_P2P_title_xpath= "//div[@class='heading'][text()='Buying from a private seller']";

}
