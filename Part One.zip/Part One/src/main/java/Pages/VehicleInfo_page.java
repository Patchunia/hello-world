package main.java.Pages;

public class VehicleInfo_page {
	
	public static String vehicleInfo_pageContents = "//div[@class='vehicle-heading'][contains(text(),'About your vehicle')]";
	public static String vehicleInfo_NewVehicle_NoToggle = "//div[@class='fieldSet yes-no-toggler']//div[@class='toggle-btn-wrapper']//div[@class='no toggle-btn active']//span";
	public static String vehicleInfo_NewVehicle_YesToggle= "//div[@class='fieldSet yes-no-toggler']//div[@class='toggle-btn-wrapper']//div[@class='yes toggle-btn']";
	public static String vehicleInfo_dealerName="//input[@autocomplete='off']"; 
	public static String vehicleInfo_VehicleType="(//SELECT[@_ngcontent-c8=''])[1]";
	public static String vehicleInfo_next_btn_xpath="(//BUTTON[@_ngcontent-c8=''][text()='Next'][text()='Next'])[1]";
	public static String vehicleInfo_VehicleYearModel="(//SELECT[@_ngcontent-c8=''])[2]";
	public static String vehicleInfo_MakeVehicle="(//SELECT[@_ngcontent-c8=''])[3]";
	public static String vehicleInfo_VehicleModel="(//SELECT[@_ngcontent-c8=''])[4]";
	public static String vehicleInfoInstalment_pageContents ="//div[@class='vehicle-heading'][contains(text(),'Your vehicle instalments')]";
	public static String vehicleInfoInstalment_PurchasePrice_xpath="//input[@id='dealerVehiclePrice']";
	public static String vehicleInfoInstalment_errMsg_xpath="//div[@class='error-message']/div[1]";
	public static String vehicleInfoInstalment_nxt_btn_xpath="(//BUTTON[@_ngcontent-c8=''][text()='Next'][text()='Next'])[2]";
	public static String vehicleInfoInstalment_deposit_Notoggle_xpath="(//DIV[@_ngcontent-c8=''])[27]";
	public static String vehicleInfoInstalment_deposit_Yestoggle_xpath="(//DIV[@_ngcontent-c8=''])[22]";
	public static String vehicleInfoInstalment_depositAmount_xpath="//input[@id='depositAmount']";
	public static String vehicleInfoInstalment_balloon_Notoggle_xpath="(//DIV[@_ngcontent-c8=''])[28]";
	public static String vehicleInfoInstalment_balloon_Yestoggle_xpath="//div[@class='feildSet yes-no-toggler']//div[@class='toggle-btn-wrapper']//div[@class='yes toggle-btn']";
	public static String vehicleInfoInstalment_percentageLabel_xpath="//span[@class='feildTitle'][contains(text(),'Please select the percentage')]";
	public static String vehicleInfoInstalment_percentageBalloon_xpath="(//DIV[@class='noUi-handle noUi-handle-lower'])[1]";
	public static String vehicleInfoInstalment_instalmentBegin_xpath="//input[@class='dp-picker-input ng-untouched ng-pristine ng-valid']";
	public static String vehicleInfoInstalment_datepicker_xpath="//div[@class='dp-calendar-wrapper']";
	public static String vehicleInfoInstalment_monthlyInstalment_xpath="//input[@id='monthlyDealerInst']";
	public static String vehicleInfoInstalment_NextBtn_xpath="(//BUTTON[@_ngcontent-c8=''][text()='Next'][text()='Next'])[2]";
	public static String vehicleInfo_P2P_pageContents = "//div[@class='about-vehicle-heading'][contains(text(),'About your vehicle')]";
	public static String vehicleInfo_P2P_VehicleType ="//select[@formcontrolname='vehicletype']";
	public static String vehicleInfoInstalment_P2P_PurchasePrice_xpath="//input[@id='vehiclePrice']";
	public static String vehicleInfoInstalment_P2P_pageContents ="//div[@class='your-vehicle-instalments-heading']";
	public static String vehicleInfoInstalment_P2P_ballon_NoToggle_xpath ="(//DIV[@_ngcontent-c8=''])[19]";
	public static String vehicleInfoInstalment_P2P_ballon_YesToggle_xpath ="(//DIV[@_ngcontent-c8=''])[18]";
	public static String vehicleInfoInstalment_P2P_percentageLabel_xpath="//SPAN[@_ngcontent-c8=''][text()='Please select the percentage']";
	public static String vehicleInfoInstalment_datepicker_P2P_xpath="//INPUT[@class='dp-picker-input ng-untouched ng-pristine ng-valid']";
	public static String vehicleInfoInstalment_P2P_monthlyInstalment_xpath="//input[@id='monthlyP2PInstalments']";
	public static String vehicleInfoInstalment_P2P_Percentage_balloon_xpath="//div[@class='noUi-handle noUi-handle-lower']";
	public static String vehicleInfoInstalment_P2P_SellerDetailsxpath="//div[@class='sd-form-heading']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_next_btn_xpath="(//BUTTON[@_ngcontent-c8=''][text()='Next'][text()='Next'])[3]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_fName_xpath="//input[@id='seller-details-firstName']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_Surname_xpath="//input[@id='seller-details-surName']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_cellNumber_xpath="//input[@id='seller-details-cellphone']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_email_xpath="//input[@id='seller-details-cellphemailAddressone']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_fName_xpath="//nav[@ng-reflect-title='Seller details']/div//div[1]/div[1]/div[1]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_Surname_xpath="//nav[@ng-reflect-title='Seller details']//div[2]/div[1]/div[1]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_cellphone_xpath="(//DIV[@_ngcontent-c8=''][text()='This is a required field.'][text()='This is a required field.'])[3]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_email_xpath="(//DIV[@_ngcontent-c8=''][text()='This is a required field.'][text()='This is a required field.'])[4]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_spl_fName_xpath="//nav[@ng-reflect-title='Seller details']//div[1]/div[1]/div[4]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_max_fName_xpath="(//DIV[@_ngcontent-c8=''][text()='Maximum 55 characters allowed'][text()='Maximum 55 characters allowed'])[1]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_spl_Surname_xpath="(//DIV[@_ngcontent-c8=''][text()='Please enter only numbers and characters.'][text()='Please enter only numbers and characters.'])[2]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_max_Surname_xpath="(//DIV[@_ngcontent-c8=''][text()='Maximum 55 characters allowed'][text()='Maximum 55 characters allowed'])[2]";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_invalid_cellphone_xpath="//DIV[@_ngcontent-c8=''][text()='Please enter a valid cellphone number.']";
	public static String vehicleInfoInstalment_P2P_SellerDetails_errMsg_invalid_email_xpath="//DIV[@_ngcontent-c8=''][text()='Please enter a valid email address.']";
	public static String VehicleInstalment_monthCount_slider_xpath="(//DIV[@class='noUi-base'])[2]";
	public static String VehicleInstalment_percentage_slider_xpath="(//DIV[@class='noUi-base'])[1]";
	
}
