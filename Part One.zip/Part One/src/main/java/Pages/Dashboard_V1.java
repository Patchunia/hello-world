package main.java.Pages;

public class Dashboard_V1 {

	public static String dashboard_apply_btn_xpath="//button[@class='gd-primary-btn btn-apply'][text()='Apply']";
	public static String dashboard_accept_btn_xpath="//*[@id='acceptCriteria']";
	public static String dashboard_consent_Yes_btn1_xpath="(.//*[@class='yes toggle-btn'])[1]"; 
	public static String dashboard_consent_No_btn1_xpath="(//div[@class='no toggle-btn active'])[1]";
	public static String dashboard_consent_Yes_btn2_xpath="(//*[@class='yes toggle-btn'])[2]";
	public static String dashboard_consent_No_btn2_xpath="(//div[@class='no toggle-btn active'])[2]";
	public static String dashboard_consent_No_btn3_xpath="(//div[@class='no toggle-btn active'])[3]";
	public static String dashboard_consent_Yes_btn3_xpath="(//*[@class='yes toggle-btn'])[3]";
	public static String dashboard_consent_StartAppl_xpath="//button[contains(@class,'gd-primary-btn btn-submit')][contains(text(),'Start application')]";
	public static String dashboard_qualifyingCriteria_page_xpath="//div[@class='title'][contains(text(),'Qualifying criteria')]";
	public static String dashboard_approveit_close_btn_xpath="//span[@id='headerCloseIcon']";
	public static String dashboard_YourConsent_page_xpath="//div[@class='title'][contains(text(),'Your consent')]";
	public static String dashboard_YourConsent_StartApp_Btn_xpath=".//button[@class='gd-primary-btn'][contains(text(),'Start application')]";
	public static String dashboard_SaveResume_page_contents_xpath="//div[contains(text(),'Your applications')]";
	public static String dashboard_SaveResume_inProgress_Count_xpath="//*[text()='In progress']";
	public static String dashboard_SaveResume_inProgress_TotalCount_xpath="(//div[@class='count'])[1]";
	public static String dashboard_SaveResume_BeingAccessed_Count_xpath="//*[text()='Being assessed']";
	public static String dashboard_SaveResume_BeingAccessed_TotalCount_xpath="(//div[@class='count'])[3]";
	public static String dashboard_SaveResume_Pending_Count_xpath="//*[text()='Pending']";
	public static String dashboard_SaveResume_Pending_TotalCount_xpath="(//div[@class='count'])[2]";
	public static String dashboard_SaveResume_Approved_Count_xpath="//*[text()='Approved']";
	public static String dashboard_SaveResume_Approved_TotalCount_xpath="(//div[@class='count'])[4]";
	public static String dashboard_SaveResume_Declined_Count_xpath="//*[text()='Declined']";
	public static String dashboard_SaveResume_Declined_TotalCount_xpath="(//div[@class='count'])[5]";
	public static String dashboard_link_xpath="(//label[@id='Your dashboard4'])[1]";
	public static String dashboard_Resume_btn_xpath="//span[@id='In progress1']";
	public static String dashboard_SearchDealership_province_xpath="//div[@class='dropdpownContainer']";
	public static String dashboard_SearchDealership_province_SelItem_xpath="//*[@id='dealerProvinces']//div//div//div[1]";
	public static String dashboard_SearchDealership_region_xpath="//app-custom-dropdown[@id='dealerReigons']//div[@class='dropdpownContainer']";
	public static String dashboard_SearchDealership_region_selItem_xpath="//html//app-custom-dropdown[@id='dealerReigons']//div[2]/label[1]";
	public static String dashboard_SearchDealership_Search_btn_xpath="//button[@class='gd-primary-btn']";
}
