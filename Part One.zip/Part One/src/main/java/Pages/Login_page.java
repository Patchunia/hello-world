package main.java.Pages;

public class Login_page {
	
	
	public static String login_Title__xpath = "//div[@class='title']"; //  Capture your ID and cellphone number to get started 
	public static String login_SAID_text_xpath = "//input[@name='identityNo']";
	public static String Login_mbNumber_xpath = "//*[@name='cellphoneNo']";
	public static String Login_btn_xpath = "//*[@class='gd-primary-btn']"; 
	public static String Login_CheckBox1_xpath= "//label[@class='checkbox-wrapper1']//span[@class='checkmark']";
	public static String Login_CheckBox2_xpath= "//label[@class='checkbox-wrapper2']//span[@class='checkmark']";
	public static String Login_SAID_errMsg_linkText = "//*[@class=\"errorMessage\"][contains(text(),\"Please check that the ID Number is correct; contains numbers only and is 13 digits long\")]";
	public static String Login_MbNo_errMsg_linkText = "//*[@class='errorMessage'][contains(text(),'Please ensure the number and format are correct, e.g. 083 123 3469')]";
	public static String Login_allFields_errMsg_LinkText = "//*[@class=\"errorMessage\"][contains(text(),'This is a required field.')]";
	public static String Login_blankSAID_errMsg_xpath ="//*[contains(text(),'        This is a required field.')]";
	public static String Login_MbNo_errMsg_xpath ="//*[contains(text(),'This is a required field.')]";
	public static String Login_chbox1_errMsg_xpath ="//*[@class=\"errorMessage\"]";
			//"//div[contains(text(),'This is a required field.')]";
	public static String Login_chbox2_errMsg_linkText = "//div[@class=\"errorMessage\"][contains(text(),'This is a required field.')]";
	public static String Login_ReadMore_link = "//div[@class='read-more-text']";
	public static String Login_ReadMore_page = "//div[@class='heading'][contains(text(),'About your application')]";
	public static String Login_ReadMore_Close_xpath = "//span[@class='close-icon']";
	public static String Login_Approveit_Close_xpath = "//span[@class='close'][1]";
	public static String Login_approveit_page = "//div[@class='notification']";
	//An Approve-it� message
}
