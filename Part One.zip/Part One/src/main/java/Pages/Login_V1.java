package main.java.Pages;

public class Login_V1 {
	public static String idNumber_id="identityNo";
	public static String cellNumb_id="cellphoneNo";
	public static String checkBox_xpath="//span[@class='checkmark']";
	//public static String Nxt_btn_xpath="//button[@class='gd-primary-btn'][text()='Next']";
	public static String Nxt_btn_xpath="//button[@id='loginFormSubmitBtn']";
	public static String idNumber_errMsg_xpath="//*[@class='error-message'][contains(text(),'Only numbers allowed.')";
	public static String idNumber_BlankerrMsg_xpath="(//*[@class='error-message'])[1][contains(text(),'This is a required field.')]";
	public static String idNumber_OtherMsg_xpath="//div[@class='error-message'][contains(text(),'Please check that the ID Number is correct; contai')]";
	public static String CelldNumber_BlankerrMsg_xpath="//div[@class='field']//div[@class='error-message']";
	public static String CellNumber_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please ensure the number and format are correct, e.g. 083 123 3469')]";
	public static String ID_BlankerrMsg_all_xpath="(//div[@class='error-message'][text()='This is a required field.'])[1]";
	public static String CellNum_BlankerrMsg_all_xpath="(//div[@class='error-message'][text()='This is a required field.'])[2]";
	public static String Checkbox_BlankerrMsg_all_xpath="(//div[@class='error-message'][text()='This is a required field.'])[3]";
	public static String approveit_accept_msg_xpath="//div[@class='modal-text'][contains(text(),'Please accept the Approve-it� message to continue.')]";
	public static String approveit_timeout_resend_xpath="//button[@class='gd-primary-btn']";
	public static String approveit_close_btn_xpath="//span[@class='close-icon']";
	public static String approveit_otp_id="approveItOtp";
	public static String reject_Ok_btn_xpath="//button[@class=\"gd-primary-btn\"][text()='Ok']";
	public static String Login_approveit_timeout_page = "//div[@class='notification']";
}
