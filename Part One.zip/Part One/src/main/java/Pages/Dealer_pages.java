package main.java.Pages;

public class Dealer_pages {

	public static String dealer_personalInfo_nxt_btn_xpath="(//button[@class='gd-primary-btn'][text()='Next'])[1]";
	public static String dealer_personalInfo_err_fname_xpath="(//div[@class='error-message']/div[text()='This is a required field.'])[1]";
	public static String PersonalDetails_title_xpath="(.//*[@class='dropdpownContainer'])[1]";
	public static String PersonalDetails_title_option_xpath="//div[contains(@class,'option-wrapper show-scroll')]/div[1]";
	public static String PersonalDetails_title_blankField_xpath="//div[@class='error-message'][contains(text(),'Please select title')]";
	public static String PersonalDetails_maritalStatus_xpath="//app-custom-dropdown[@id='maritalStatusDropdown']//div[@class='dropdpownContainer']";
	public static String PersonalDetails_MaritalStatus_option_xpath="//*[@id='maritalStatusDropdown']/div/div/div[2]/label";
			//"//div[contains(@class,'option-wrapper show-scroll')]/div[1]";
	public static String dealer_personalInfo_err_Splfname_xpath="(//div[@class='error-message']/div[contains(text(),' Special characters not allowed.')])[1]";
	public static String dealer_personalInfo_born_cntry_xpath="//div[@class='auto-search-container']//input[@type='textbox']";
	public static String dealer_personalInfo_born_cntry_AllSelItem_xpath="//div[@class='search-options-wrapper']/div[1]"; 
	public static String dealer_personalInfo_born_cntry_SelItem_xpath="(//div[@class='item'])[1]";
	public static String dealer_personalInfo_born_cntry_blankErr_xpath="//div[@class='error-message'][contains(text(),'This is a required field.')]";
	public static String dealer_personalInfo_multiNat_Yes_toggle_xpath="//div[@id='multipleNationalitiesYes']";
	public static String dealer_personalInfo_MultiNationality_xpath="//div[@class='vertical-form']//div//div[@class='field']//app-auto-complete[@ng-reflect-search-list='[object Object],[object Object']//div[@class='auto-search-container']";
	public static String PersonalDetails_birthPlace_NoToggle_xpath="//div[@id='foreignTaxObligationNo']";
	public static String PersonalDetails_birthPlace_YesToggle_xpath="//div[@id='foreignTaxObligationYes']";
	public static String dealer_personalInfo_AddNationality_link_xpath="//span[@class='plus-icon']";
	public static String dealer_personalInfo_AdditionalCountry_link_xpath="(//div[@class='auto-search-container']//input[1])[3]";
	public static String dealer_personalInfo_AdditionalCountry_AllSelItem_xpath="//div[@class='search-options'][1]";
	public static String dealer_personalInfo_Additionalcntry_SelItem_xpath="//div[@class='search-options-wrapper show-scroll']/div[1]";
	public static String dealer_personalInfo_close_btn_xpath="//div[@id='closeAppForms']";
	public static String dealer_personalInfo_closeExit_btn_xpath="//div[@id='alertButton']";
	public static String PersonalDetails_EthnicGroup_xpath="//app-custom-dropdown[@id='ethnicGroupDropdown']//div[@class='dropdpownContainer']//input[@type='textbox']";
	public static String PersonalDetails_EthnicGroup_selItem_xpath="//*[@id='ethnicGroupDropdown']/div/div/div[2]";
	public static String PersonalDetails_EthnicGroup_BlankGrp_xpath="//div[@class='error-message'][contains(text(),'Please select ethnic group')]";
	public static String PersonalDetails_EthnicGroup_options_xpath="//div[@class='option-wrapper']//div[1]";
	
	public static String dealer_residentialPageContents_xpath="//div[@class='title'][contains(text(),'Your address')]";
	public static String dealer_residential_physicalAddress_xpath="//input[@id='physicalAddress']";
	public static String dealer_residential_physicalAddress2_xpath="//input[@id='physicalAddress2']";
	public static String dealer_residential_physicalAddress_Max_err_xpath="//form[@id='residential-address-form']//div[@class='vertical-form']//div[@class='field']//div[@class='error-message']//div";
	public static String dealer_residential_physicalAddress_Spl_err_xpath="(//div[@class='error-message']//div[1])[1]";
	public static String dealer_residential_physicalAddress_Blank_err_xpath="(//div[@class='error-message']//div[1])[1]";
	public static String dealer_residential_residentialStatus_xpath="//app-custom-dropdown[@id='residentialStatusDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_residential_residentialStatus_SelItem_xpath="//app-custom-dropdown[@id='residentialStatusDropdown']//div//div//div[2]";
	public static String dealer_residential_residentialStatus_BlankErr_xpath="//div[@class='error-message'][contains(text(),'Please select residential status')]";
	public static String dealer_residential_DatePicker_moveHere_xpath="//*[@id='datePicker']/div[1]/div/input";
	public static String dealer_residential_DatePicker_moveHere_blankErr_xpath="(//validation-error-msg[@errormsg='Please select valid date']//div/div[1])[1]";
	public static String dealer_residential_Mail_yesToggle_xpath="//div[@id='yesMail']";
	public static String dealer_residential_Mail_noToggle_xpath="//div[@id='noMail']";
	public static String dealer_residential_postalAddress1_xpath="//input[@id='postalAddressFirst']";
	public static String dealer_residential_postalAddress1_Blank_err_xpath="(//div[@class='error-message']//div)[1]";
	public static String dealer_residential_postalAddress2_xpath="//input[@id='postalAddressSecond']";
	public static String dealer_residential_suburb_xpath="//app-auto-complete[@formcontrolname='suburb']//div[@class='auto-search-container']";
	public static String dealer_residential_Physicalsuburb_xpath="//app-auto-complete[@formcontrolname='physicalSuburb']//div[@class='auto-search-container']";
	public static String dealer_residential_Physicalsuburb_selItem_xpath="//div[@class='search-options-wrapper']/div[1]";
	public static String dealer_residential_datepicker_movehere_BlankErr_xpath="(//div[@class='vertical-form']//div[@class='field']//validation-error-msg[@errormsg='Please select valid date']//div//div[@class='error-message'])[1]";
	public static String dealer_residential_suburb_Blank_Err_xpath="//div[@class='error-message'][contains(text(),'Please select suburb')]";
	public static String dealer_residential_suburb_invalid_Err_xpath="//div[@class='error-message'][contains(text(),'No records found')]";
	public static String dealer_residential_suburb_AllItem_xpath="//div[@class='search-options-wrapper show-scroll']/div[1]";
	public static String dealer_residential_PhysicalCity_xpath="//input[@id='physicalCity']";
	public static String dealer_residential_PhysicalPostalCode_xpath="//input[@id='physicalPostCode']";
	public static String dealer_residential_city_xpath="//input[@id='city']";
	public static String dealer_residential_postalcode_xpath="//input[@id='postCode']";
	public static String dealer_residential_next_btn_xpath="//button[@id='residentialInfoSubmitBtn']";
	
	public static String dealer_employmentPageContents_xpath="//div[@class='title'][text()='Your employment details']";
	public static String dealer_employmentdetails_type_xpath="//app-custom-dropdown[@id='employementTypeDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_employmentdetails_SelItem_type_xpath="//app-custom-dropdown[@id='employementTypeDropdown']//div//div//div[2]";
	public static String dealer_employmentdetails_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select employment type')]";
	public static String dealer_employmentdetails_occupation_xpath="//app-custom-dropdown[@id='occupationDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_employmentdetails_occupation_selItem_xpath="//app-custom-dropdown[@id='occupationDropdown']//div//div//div[2]";
	public static String dealer_employmentdetails_occupation_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select occupation')]";
	public static String dealer_employmentdetails_employer_xpath="//input[@id='currentEmployer']";
	public static String dealer_employmentdetails_employer_blank_err_xpath_xpath="(//div[@class='error-message']//div[contains(text(),'This is a required field.')])[1]";
	public static String dealer_employmentdetails_employer_max_err_xpath_xpath="(//div[@class='error-message']//div)[1]";
	public static String dealer_employmentdetails_industry_xpath="//app-custom-dropdown[@id='industryTypeDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_employmentdetails_industry_SelItem_xpath="//app-custom-dropdown[@id='industryTypeDropdown']//div//div//div[2]";
	public static String dealer_employmentdetails_industry_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select industry type')]";
	public static String dealer_employmentdetails_datepicker_startWorking_xpath="//app-custom-date-picker[@class='currentEmployerWorkingDate']//div[@id='daytimeDirective']//dp-date-picker[@id='datePicker']";
	public static String dealer_employmentdetails_date_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select valid date')]";
	public static String dealer_employmentdetails_next_btn_xpath="//button[@id='employementDetailSubmitBtn']";
	public static String dealer_bankingPageContents_xpath="//div[@class='title'][contains(text(),'Your banking details')]";
	public static String dealer_bankingdetails_bankName_xpath="//app-custom-dropdown[@id='bankNameDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_bankingdetails_bankName_SelItem_xpath="//app-custom-dropdown[@id='bankNameDropdown']//div//div/div[2]";
	public static String dealer_bankingdetails_bankName_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select bank name')]";
	public static String dealer_bankingdetails_AcNumber_xpath="//input[@id='accountNumber']";
	//Maximum 11 character account number allowed.
	public static String dealer_bankingdetails_AcNumber_blank_err_xpath="(//div[@class='field']//div[@class='error-message']//div)[1]";
	public static String dealer_bankingdetails_AccountType_xpath="//app-custom-dropdown[@id='accountTypeDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_bankingdetails_AccountType_SelItem_xpath="//app-custom-dropdown[@id='accountTypeDropdown']//div//div/div[1]";
	public static String dealer_bankingdetails_AccountType_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select account type')]";
	public static String dealer_bankingdetails_BranchName_xpath="//input[@id='branchCode']";
	public static String dealer_bankingdetails_next_btn_xpath="//button[@id='bankingDetailsSubmitBtn']";
	public static String dealer_PersonalIncomePageContents_xpath="//div[@class='title'][contains(text(),'Your personal income')]";
	public static String dealer_PersonalIncome_BeforeDed_xpath="//input[@id='earnBeforeDeductions']";
	public static String dealer_PersonalIncome_BeforeDed_BlankErr_xpath="//div[@class='vertical-form']/div[1]/div[2]/div[1]";
	public static String dealer_PersonalIncome_AfterDed_xpath="//input[@id='earnAfterDeductions']";
	public static String dealer_PersonalIncome_AfterDed_BlankErr_xpath="(//div[@class='error-message']//div[contains(text(),'This is a required field')])[1]";
	public static String dealer_PersonalIncome_monthlyExpense_xpath="//input[@id='monthlyExpenses']";
	public static String dealer_PersonalIncome_monthlyExpense_BlankErr_xpath="//div[@class='error-message']//div";
	public static String dealer_PersonalIncome_aDedu_Greater_errMsg_xpath="//div[@class='error-message'][contains(text(),'Gross Salary cannot be less than NET salary.')]";
	public static String dealer_PersonalIncome_mExp_Greater_errMsg_xpath="//div[@class='error-message'][contains(text(),'Unable to assist with finance due to your expenses')]";
	public static String dealer_PersonalIncome_next_btn_xpath="//button[@id='personalIncomeSubmitBtn']";
	
//##########################################Vehicle Details#############################################################
	public static String dealer_abtVehicle_pageContents_xpath="//div[@class='title'][contains(text(),'About your vehicle')]";
	public static String dealer_abtVehicle_NewVehicle_noToggle_xpath="//div[@id='oldVehicle']";
	public static String dealer_abtVehicle_NewVehicle_yesToggle_xpath="//div[@id='newVehicle']";
	public static String dealer_abtVehicle_dealer_xpath="//app-auto-complete[@formcontrolname='dealer']";
	public static String dealer_abtVehicle_dealer_SelItem_xpath="//div[@class='search-options-wrapper show-scroll']/div[1]";
	public static String dealer_abtVehicle_vehicleType_xpath="//select[@id='vehicleType']";
	public static String dealer_abtVehicle_vehicleType_errMsg_xpath="//*[@class='error-message'][contains(text(),'Please select vehicle type')]";
	public static String dealer_abtVehicle_vehicleYear_xpath="//app-custom-dropdown[@id='vehicleYearDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_abtVehicle_vehicleYear_SelItem_xpath="//*[@id='vehicleYearDropdown']//div//div//div[1]";
	public static String dealer_abtVehicle_vehicleYear_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select year')]";
	public static String dealer_abtVehicle_vehicleMake_xpath="//app-custom-dropdown[@id='vehicleMakeDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_abtVehicle_vehicleMake_selItem_xpath="//app-custom-dropdown[@id='vehicleMakeDropdown']//div//div/div[1]";
	public static String dealer_abtVehicle_vehicleMake_errMsg_xpath="//div[@class='error-message'][contains(text(),'Please select make')]";
	public static String dealer_abtVehicle_vehicleModel_xpath="//app-custom-dropdown[@id='vehicleModelDropdown']//div[@class='dropdpownContainer']";
	public static String dealer_abtVehicle_vehicleModel_selItem_xpath="//app-custom-dropdown[@id='vehicleModelDropdown']//div//div/div[1]";
	public static String dealer_abtVehicle_vehicleModel_errMsg_xpath="//div[@class='error-message']";
	public static String dealer_abtVehicle_nxt_btn_xpath="//button[@id='aboutVehicleSubmitBtn']";	
	public static String dealer_VehicleInstalment_pageContents_xpath="//div[@class='title'][contains(text(),'Your vehicle instalments')]";
	public static String dealer_VehicleInstalment_submit_btn_xpath="//button[@id='vehicleInstalmentSubmitBtn']";
	public static String dealer_VehicleInstalment_purchasePrice_Blankerr_xpath="//div[@class='error-message']/div[1]";
	public static String dealer_VehicleInstalment_purchasePrice_xpath="//input[@id='purchasePrice']";
	public static String dealer_VehicleInstalment_purchasePrice_Err_xpath="//div[@class='error-message'][contains(text(),'Purchase Price cannot be less than 50000 amount')]";
	public static String dealer_VehicleInstalment_purchasePrice_CharsErr_xpath="//div[@class='error-message']/div[2]";
	public static String dealer_VehicleInstalment_deposit_noToggle_xpath="//div[@id='noDeposit']";
	public static String dealer_VehicleInstalment_deposit_yesToggle_xpath="//div[@id='yesDeposit']";
	public static String dealer_VehicleInstalment_deposit_xpath="//input[@id='deposit']";
	public static String dealer_VehicleInstalment_deposit_MaxValue_xpath="//div[@class='error-message'][contains(text(),'Deposit Price cannot be greater than')]";
	public static String dealer_VehicleInstalment_balloon_yesToggle_xpath="//div[@id='balloonRequired']";
	public static String dealer_VehicleInstalment_balloon_percentage_label_xpath="//html//div[5]/span[1]";
	public static String dealer_VehicleInstalment_balloon_percentage_slider_xpath="//*[@class='p2pPerSlider']//div[@id='slider-cntnr']//nouislider[@class='ng2-nouislider ng-untouched ng-pristine ng-valid']//div[@class='noUi-target noUi-ltr noUi-horizontal']//div[@class='noUi-base']";
	public static String dealer_VehicleInstalment_dateInstalment__err_xpath="//div[@class='error-message']";
	public static String dealer_VehicleInstalment_dateInstalment_xpath="//span[@class='icon calendar']";
	public static String dealer_VehicleInstalment_paying_slider_xpath="//nouislider[@class='ng2-nouislider ng-untouched ng-pristine ng-valid']//div[@class='noUi-target noUi-ltr noUi-horizontal']//div[@class='noUi-base']";
	public static String dealer_VehicleInstalment_dateInstalment_month_xpath="//button[@class='dp-calendar-nav-right']";
	public static String dealer_VehicleInstalment_monthlyExpense_xpath="//input[@id='estimatedMonthlyInstalment']";
	
	////////////////////////////////////////Application State////////////////////////////////////////
	public static String dealer_ApplicationState_heading_xpath="//span[@class='emphasis'][contains(text(),'Congratulations,')]";
	public static String dealer_ApplicationState_ReferenceNo_xpath="//DIV[@_ngcontent-c27=''][contains (text(),'Ref: ')]";
	public static String dealer_ApplicationState_Continue_xpath="//button[@class='gd-primary-btn']";
	
	////////////////////////////Monthly Expenses/////////////////////////////////////////////
	public static String dealer_monthlyExpenses_aDeduction_xpath="//input[@id='netSalary']";
	
	
	////////////////////////////////Timeout///////////////////////////////////////
	public static String timeout_page_details_xpath="//div[@class='col-12 info']";
	
}
