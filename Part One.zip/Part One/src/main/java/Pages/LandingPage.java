package main.java.Pages;

public class LandingPage {
	
	public static String landingpage_whatYouCanAfford_link_xpath="(//label[@id='What can you afford1'])[1]";
	public static String landingpage_SearchForDealership_link_xpath="(//label[@id='Search for a dealership3'])[3]";
	public static String landingpage_MonthlyExpenses_link_xpath="(//label[@id='Instalment calculator2'])[2]";
	public static String landingpage_back_btn_xpath="(//div[@id='backBtn'])[2]";
	public static String landingpage_dashboard_xpath="(//label[@id='Your dashboard4'])[4]";
	public static String landingpage_dashboard_page_xpath="//div[contains(@class,'title sub-title')]";
	public static String landingpage_howdoesthiswork_dealership_xpath="(//label[@id='Dealership2'])[4]";
	public static String landingpage_howdoesthiswork_PrivateSeller_xpath="(//label[@id='Private seller3'])[4]";
	public static String landingpage_howdoesthiswork_FAQ_xpath="(//label[@id='FAQ4'])[2]";
	public static String landingpage_howdoesthiswork_FAQ_page_xpath="//div[@class='title'][contains(text(),'General Questions')]";
	public static String landingpage_login_icon_xpath="//span[@id='loginToProfile']";
	public static String landingpage_buyingFromDealershipViewDetails_xpath="//div[@id='gotoDealerGuide']";
	public static String landingpage_buyingFromPrivateViewDetails_xpath="//div[@id='gotoPrivateGuide']";
	public static String Landingpage_FindoutMore_xpath="//div[@id='gotoFinanceLink']";
	public static String Landingpage_BuyingFromPrivateSeller_xpath="//div[@class='heading'][contains(text(),'Buying from a private seller')]";
	public static String landingpage_ContactUS_icon_xpath="//span[@id='contactUs']";
	public static String landingpage_ContactUS_header_xpath="//div[@class='header']";
	public static String landingpage_ContactUS_MobNum_xpath="//mfc-header[@class='ng-tns-c1-0']//div[3]";
	public static String landingpage_ContactUS_Email_finance_xpath="//mfc-header[@class='ng-tns-c1-0']//div[4]";
	public static String landingpage_ContactUS_Email_Technical_xpath="//mfc-header[@class='ng-tns-c1-0']//div[5]";
	public static String landingpage_ContactUS_Close_xpath="//span[@class='close-icon']";
}
