package main.java.Pages;

public class P2P_pages {
	public static String PersonalDetails_page_xpath="//div[@class='title'][text()='Your personal details']";
	public static String PersonalDetails_said_display_xpath="//div[@class='identity-number-text']";
	public static String PersonalDetails_Cellnumber_display_xpath="//div[@class='identity-number-text  cellphone-info-text']";
	public static String PersonalDetails_title_xpath=".//select[@name='title']";
	public static String PersonalDetails_title_blankField_xpath="//div[@class='error-message'][contains(text(),'Please select title')]";
	//public static String PersonalDetails_title1_xpath="(//div[@class='error-msg']/div)[1]";
	public static String PersonalDetails_blank_xpath="(//div[@_ngcontent-c3=''][text()='This is a required field'][text()='This is a required field'])[1]";
	public static String PersonalDetails_MaxChar_FirstName = "(//div[@class='error-message']/div)[1]";
	public static String PersonalDetails_FirstName_xpath = "//input[@id='firstName']";
	public static String PersonalDetails_surname_xpath="//input[@id='surName']";
	public static String PersonalDetails_surname_MaxChar_xpath="//DIV[@_ngcontent-c3=''][text()='Maximum 55 characters allowed.']";
	public static String PersonalDetails_tooltip_xpath="//form[@id='personal-information-form']//div[@class='feildSet']//span[@class='feildTitle']//label[@class='question-icon']";
			//"(//LABEL[@_ngcontent-c3=''][text()=' '][text()=' '])[1]";
	public static String PersonalDetails_tooltip_contents_xpath="//div[@class='tooltip-heading']";
	public static String PersonalDetails_maritalStatus_xpath="(//*[@class='dropdpownContainer'])[2]";
	public static String PersonalDetails_maritalStatus_BlankErr_xpath="//div[@class='error-message'][contains(text(),'Please select marital status')]";
	public static String PersonalDetails_blank_WorkHomeTeleNumber="//div[@class='error-message'][contains(text(),'Must have home or work number')]";
	public static String PersonalDetails_WorkTelNumber_xpath="//input[@id='workPhone']";
	public static String PersonalDetails_WorkTelNumber_MaxDigit_xpath="//div[@class='error-message']/div[contains(text(),' Please enter valid work telephone number.')]";
	public static String PersonalDetails_HomeTelNumber_MaxDigit_xpath="(//div[@class='error-message']/div)[1]";
	public static String PersonalDetails_HomeTelNumber_xpath="//input[@id='homePhone']";
	public static String PersonalDetails_email_blank_xpath="(//*[@class='error-message']/div[contains(text(),'This is a required field')])[1]";
	public static String PersonalDetails_email_id="emailAddress";
	public static String PersonalDetails_invalid_email_xpath="(//div[@class='error-message']//div)[1]";
	public static String PersonalDetails_Nationality_YesToggle_xpath="//div[@id='multipleNationalitiesYes']";
			//"//div[@class='toggle-btn-wrapper']//div[@class='yes toggle-btn']";
	public static String PersonalDetails_Nationality_NoToggle_xpath="//div[@id='multipleNationalitiesNo']";
	public static String PersonalDetails_Nationality_Add_country="(//INPUT[@_ngcontent-c6=''])[2]";
	public static String PersonalDetails_AddNationality_xpath="//span[@class='plus-icon']";
	public static String PersonalDetails_Nationality_Add_country2="(//INPUT[@_ngcontent-c6=''])[3]";
	public static String PersonalDetails_foreignBirthPlace_No_xpath="//div[@id='foreignBirthplaceNo']";
	public static String PersonalDetails_foreignBirthPlace_Yes_xpath="//div[@id='foreignBirthplaceYes']";
	
	public static String PersonalDetails_close_btn_xpath="//div[@class='close-icon']";
	public static String ResidentialAddress_pagecontents_class="ra-heading";
	public static String ResidentialAddress_PhysicalAddr_id="physicalAddress";
	public static String ResidentialAddress_physicalAddr_max_xpath="//div[@class='error-msg']/div[contains(text(),'Maximum 50 characters allowed')]";
	public static String ResidentialAddress_physicalAddr_spl_xpath="//div[@class='feildSet']//div[3]";
	public static String ResidentialAddress_datepicker_xpath="(//INPUT[@_ngcontent-c7=''])[1]";
			//"//div[@class='ngx-bootstrap-datepicker datepicker-wrapper error']//input[@placeholder='Select date']";
	public static String ResidentialAddress_datepicker_container_xpath="//div[@class='bs-datepicker-container']";
	public static String ResidentialAddress_mail_no_xpath="(//DIV[@_ngcontent-c3=''])[39]";
			//"//div[@class='no toggle-btn']";
	public static String ResidentialAddress_mail_yes_xpath="//div[@class='yes toggle-btn active']";
	public static String ResidentialAddress_PostalLine1_id="postalAddressFirst";
	public static String ResidentialAddress_PostalLine2_id="postalAddressSecond";
	public static String ResidentialAddress_status_id="residentialStatus";
	public static String ResidentialAddress_Suburb_id="suburb";
	public static String ResidentialAddress_City_id="city";
	public static String ResidentialAddress_PostalCode_id="postCode";
	public static String ResidentialAddress_Postaladdr1_spl_xpath="//div[@class='error-msg']//div";
	public static String Employmentdetails_page_class="ed-heading";
	public static String ResidentialAddress_Next_xpath="(//BUTTON[@_ngcontent-c3=''][text()='Next'][text()='Next'])[2]";
	public static String EmploymentDetails_EmployType_id="employmentType";
	public static String EmploymentDetails_occupation_id="occupation";
	public static String EmploymentDetails_CurrentEmp_id="currentEmployer";
	public static String EmploymentDetails_Industry_id="industryType";
	public static String EmploymentDetails_datepicker_xpath="(//INPUT[@_ngcontent-c7=''])[2]";
	public static String EmploymentDetails_next_btn_xpath="(//BUTTON[@_ngcontent-c3=''][text()='Next'][text()='Next'])[3]";
	public static String EmploymentDetails_CurrentEmployer_spl_xpath="//DIV[@_ngcontent-c3=''][text()='Please enter only numbers and characters.']";
	public static String BankingDetails_pageContents_xpath="bd-heading";
	public static String BankingDetails_bankName_id="bankName";
	public static String BankingDetails_accountNumber_id="accountNumber";
	public static String BankingDetails_AccountType_id="accountType";
	public static String BankingDetails_BranchCode_id="branchCode";
	public static String BankingDetails_next_btn_xpath="(//BUTTON[@_ngcontent-c3=''][text()='Next'][text()='Next'])[4]";
			//"//form[@id='banking-details-form']//div[@class='btn-next']//button[@class='gd-primary-btn next-btn']";
			
	public static String BankingDetails_chars_account_number_xpath="//DIV[@_ngcontent-c3=''][text()='Please enter valid amount. ']";
	public static String PersonalIncome_PageContents_class="pincome-heading";
	public static String Personalincome_BeoreDeduction_id="earnBeforeDeductions";
	public static String PersonalIncome_afterDeduction_id="earnAfterDeductions";
	public static String PersonalIncome_MonthlyExpense_id="monthlyExpenses";
	public static String PersonalIncome_Next_btn_xpath="//form[@id='personal-income-form']//div[@class='btn-next']//button[@class='gd-primary-btn next-btn'][contains(text(),'Next')]";
	public static String PersonalIncome_bDeduction_error_xpath="(//DIV[@_ngcontent-c3=''][text()='Please enter valid amount. '][text()='Please enter valid amount. '])[1]";
	
	///////////////////////////////////////////////////Vehicle Details/////////////////////////////////////////
	public static String P2P_Vehicle_year_xpath="//app-custom-dropdown[@id='vehicleYearDropdown']//div[@class='dropdpownContainer']";
	public static String P2P_Vehicle_year_SelItem_xpath="//div[@class='option-wrapper show-scroll']/div[1]";
	public static String P2P_Vehicle_year_Blank_Err_xpath="//div[@class='error-message'][contains(text(),'Please select year')]";
	public static String P2P_Vehicle_Model_Blank_Err_xpath="//div[@class='error-message']";
	public static String P2P_VehicleInstalment_Nxt_btn_xpath="//button[@id='vehicleInstalmentNextBtn']";
	public static String P2P_SellerDetails_page_xpath="//div[@class='title'][contains(text(),'Seller details')]";
	public static String P2P_SellerDetails_fName_xpath="//input[@id='sellerFirstName']";
	public static String P2P_SellerDetails_fName_Blank_err_xpath="//div[@class='error-message']/div[1]";
	public static String P2P_SellerDetails_fName_err_xpath="(//div[@class='field']//div[4])[1]";
	public static String P2P_SellerDetails_sName_xpath="//input[@id='sellerSurName']";
	public static String P2P_SellerDetails_sName_Err_xpath="//div[@class='error-message']/div[4]";
	public static String P2P_SellerDetails_Nxt_btn_xpath="//button[@id='sellerDetialSubmitBtn']";	
	public static String P2P_SellerDetails_CellNo_xpath="//input[@id='sellerCellphone']";
	public static String P2P_SellerDetails_CellNo_Err_xpath="(//div[@class='field']//div[2])[14]";
	public static String P2P_SellerDetails_email_xpath="//input[@id='sellerEmailAddress']";
	public static String P2P_SellerDetails_email_Err_xpath="(//div[@class='field']//div[2])[14]";
	
	
}