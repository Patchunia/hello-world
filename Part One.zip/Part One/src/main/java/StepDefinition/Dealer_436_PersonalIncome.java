package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import main.java.Pages.Dealer_pages;
import cucumber.api.java.en.When;

public class Dealer_436_PersonalIncome extends CommonSteps{

	@When("^Fill form of Banking details page and click on Next button \"([^\"]*)\"$")
	public void Fill_form_of_Banking_details_page_and_click_on_Next_button(String AccNum) throws Throwable {
		//Select Bank name
		WebElement bank = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_bankName_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", bank);
	    Thread.sleep(2000);
		WebElement optionbank = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_bankName_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionbank);
		
		System.out.println("Bank name selected");
		Thread.sleep(1000);
		
		//Enter Account number
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AcNumber_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(AccNum);
			System.out.println("Account number is entered");
		}
		else
			System.out.println("Account number is not displayed");
		
		//Select Bank type
		WebElement acctType = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AccountType_xpath));
		Thread.sleep(1000);
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", acctType);
	    Thread.sleep(2000);
		WebElement optionAcct = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AccountType_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionAcct);
		System.out.println("Account type selected");
		Thread.sleep(1000);		
		//Next button
		Thread.sleep(1000);
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_next_btn_xpath));
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", element);
	    Thread.sleep(3000);
	}
	
	@When("^check for Personal Income page$")
	public void check_for_Personal_Income_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncomePageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncomePageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("Your personal income"))
				System.out.println("Your personal income page is displayed");
		}
		else
			System.out.println("Your personal income page is NOT displayed");			
	}
	
	@When("^i can click on Next button of Personal Income page$")
	public void i_can_click_on_Next_button_of_Personal_Income_page() throws Throwable {
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_next_btn_xpath));	
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
		//scrollToElement("Login_btn_xpath");
	}
	
	@When("^check blank error message for before deduction field$")
	public void check_blank_error_message_for_before_deduction_field() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_BeforeDed_BlankErr_xpath)).getText();
		if(errMsg.contains("This is a required field"))
			System.out.println("Error message for before deduction is displayed");
		else
			System.out.println("Error message for before deduction is NOT displayed");
	}
	
	@When("^check blank error message of after deduction$")
	public void check_blank_error_message_of_after_deduction() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_AfterDed_BlankErr_xpath)).getText();
		if(errMsg.contains("This is a required field"))
			System.out.println("Error message for after deduction is displayed");
		else
			System.out.println("Error message for after deduction is NOT displayed");
	}
	
	@When("^check blank error message of monthly expense$")
	public void check_blank_error_message_of_monthly_expense() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_monthlyExpense_BlankErr_xpath)).getText();
		if(errMsg.contains("This is a required field"))
			System.out.println("Error message for monthly expense is displayed");
		else
			System.out.println("Error message for monthly expense is NOT displayed");
	}
	
	@When("^i can enter Before deduction \"([^\"]*)\"$")
	public void i_can_enter_Before_deduction(String bDeduction) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_BeforeDed_xpath));
//		if(validate.isDisplayed()) {
			validate.sendKeys(bDeduction);
			Thread.sleep(2000);
//			System.out.println("Before deduction is entered");
//		}
//		else
//			System.out.println("Before deduction is not displayed");
	}
	
	@When("^i can enter After deduction \"([^\"]*)\"$")
	public void i_can_enter_After_deduction(String aDeduction) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_AfterDed_xpath));
//		Actions action = new Actions(wdriver);
//		action.moveToElement(validate).sendKeys(aDeduction).build().perform();
//		if(validate.isDisplayed()) {
			validate.sendKeys(aDeduction);
			Thread.sleep(2000);
//			System.out.println("After deduction is entered");
//		}
//		else
//			System.out.println("After deduction is not displayed");
	}
	
	@When("^i can enter monthly expense \"([^\"]*)\"$")
	public void i_can_enter_monthly_expense(String mExp) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_monthlyExpense_xpath));
		Thread.sleep(1000);
		validate.sendKeys(mExp);
		
			Thread.sleep(1000);
			System.out.println("Monthly expenses is entered");
	}
	
	@When("^check error message if monthly expenses is greater than after deduction$")
	public void check_error_message_if_monthly_expenses_is_greater_than_after_deduction() throws Throwable {
		String msg = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_mExp_Greater_errMsg_xpath)).getText();
		if(msg.contains("Unable to assist with finance due to your expenses"))
			System.out.println("Monthly expenses cannot be greater than After deduction");
		else
			System.out.println("Monthly expenses cannot be greater than After deduction is NOT displayed");
	}
	
	@When("^check error message if after deduction is greater than before deduction$")
	public void check_error_message_if_after_deduction_is_greater_than_before_deduction() throws Throwable {
		String msg = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_aDedu_Greater_errMsg_xpath)).getText();
		if(msg.equalsIgnoreCase("Gross Salary cannot be less than NET salary."))
			System.out.println("After deduction cannot be greater than Before deduction");
		else
			System.out.println("After deduction cannot be greater than Before deduction is NOT displayed");
	}
}
