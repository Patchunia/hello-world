package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class StepByStep_KnowWhatUAffort_695 extends CommonSteps {

	@When("^check for Know what you can afford icon$")
	public void check_for_Know_what_you_can_afford_icon() throws Throwable {
		Thread.sleep(1000);
		String know_what_you_can_afford = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_link_xpath)).getText();
		
		if (know_what_you_can_afford.contains("What can you afford"))
			System.out.println("What can you afford icon is displayed");
		else
			System.out.println("What can you afford icon is NOT displayed");
	}
	
	@When("^i can click on Know what you can afford icon$")
	public void i_can_click_on_Know_what_you_can_afford_icon() throws Throwable {
		String know_what_you_can_afford = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_link_xpath)).getText();
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_link_xpath));
		//Actions actions = new Actions(wdriver); 
		if (know_what_you_can_afford.contains("What can you afford")) {
			System.out.println("What can you afford icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("Clicked on What can you afford icon");
			Thread.sleep(1000);
		}
		else
			System.out.println("What can you afford icon is NOT displayed");
	}
	
	@When("^check for page contents of Know what you can afford icon$")
	public void check_for_page_contents_of_Know_what_you_can_afford_icon() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_heading_xpath)).getText();
		if (heading.equalsIgnoreCase("Know what you can afford"))
			System.out.println("Know what you can afford page id displayed");
		else
			System.out.println("Know what you can afford page id NOT displayed");
		
	}
	
	@When("^i can click on Budget calculator$")
	public void i_can_click_on_Budget_calculator() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_budgetCalculator_link_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Budget calculator link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Budget calculator link");
		}
		else
			System.out.println("Budget calculator link is NOT displayed");
		
	}
	
	@When("^budget calculator page is displayed$")
	public void budget_calculator_page_is_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_heading_xpath)).getText();
		if (heading.equalsIgnoreCase("Budget calculator"))
			System.out.println("Budget Calculator page id displayed");
		else
			System.out.println("Budget calculator page id NOT displayed");
	}
	
	@When("^i can click on Instalment calculator$")
	public void i_can_click_on_Instalment_calculator() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_instalmentCalculator_link_xpath));
		
			System.out.println("Instalment calculator link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on instalment calculator link");
			
	}
	
	@When("^instalment calculator page is displayed$")
	public void instalment_calculator_page_is_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_budgetCalculator_link_xpath)).getText();
		if (heading.equalsIgnoreCase("Instalment calculator"))
			System.out.println("Instalment calculator page id displayed");
		else
			System.out.println("Instalment calculator page id NOT displayed");
	}
	
	@When("^i can click on Start application button$")
	public void i_can_click_on_Start_application_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_StartApp_Btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Start Application button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Start application button");
		}
		else
			System.out.println("Start Application button is NOT displayed");
	}
	
	@When("^Qualifying page is displayed$")
	public void Qualifying_page_is_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Qualifying criteria"))
			System.out.println("Qualifying criteria page id displayed");
		else
			System.out.println("Qualifying criteria page id NOT displayed");
	}
	@When("^i can click on apply button$")
	public void i_can_click_on_apply_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_Apply_btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Apply button button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Apply button button");
		    Thread.sleep(1000);
		}
		else
			System.out.println("Apply button is NOT displayed");
	}
}
