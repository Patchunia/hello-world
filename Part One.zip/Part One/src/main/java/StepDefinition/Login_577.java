package main.java.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import main.java.Pages.Login_V1;
import main.java.Pages.StepByStep_pages;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.When;

public class Login_577 extends CommonSteps {
	
	//Actions actions = new Actions(wdriver);

	@When("^I can type ID number \"([^\"]*)\"$")
	public void i_can_type_ID_number(String idNum) throws Throwable {
		Thread.sleep(2000);
	    WebElement validate = wdriver.findElement(By.id(Login_V1.idNumber_id));
	    if (validate.isDisplayed()) {
	    	System.out.println("ID number field is displayed");
	    	validate.sendKeys(idNum);
	    	System.out.println("ID number entered");
	    }
	    else
	    	System.out.println("ID number field is NOT displayed");
	}
	
	@When("^I am presented with a login page$")
	public void i_am_presented_with_a_login_page() throws Throwable
	{
		Thread.sleep(2000);
//		test.log(LogStatus.INFO, " Starting test - For login page");
		System.out.println(" Starting test - For login page");

		String heading = wdriver.findElement(By.xpath(Login_page.login_Title__xpath)).getText();
		if (heading.equalsIgnoreCase("Let’s get started"))
		{

			System.out.println("Log-in page successfully displayed");
		
			
		}
		else
		{
			System.out.println("Log-in page is NOT displayed");
		
		}
	}
	
	@When("^I can enter Cellphone number for login page \"([^\"]*)\"$")
	public void i_can_enter_Cellphone_number_for_login_page(String mbNum) throws Throwable {
		WebElement validate = wdriver.findElement(By.id(Login_V1.cellNumb_id));
	    if (validate.isDisplayed()) {
	    	System.out.println("Cellphone number field is displayed");
	    	validate.sendKeys(mbNum);
	    	System.out.println("Cellphone number entered");
	    }
	    else
	    	System.out.println("Cellphone number field is NOT displayed");
	    Thread.sleep(1000);
	}
	
	
	@When("^I can click on check box$")
	public void i_can_click_on_check_box() throws Throwable {
		Thread.sleep(1000);
		 WebElement validate = wdriver.findElement(By.xpath(Login_V1.checkBox_xpath));
		 if(validate.isSelected())
			{
				System.out.println("Already selected First Check box");
			}
			
			else {
				WebElement element = wdriver.findElement(By.xpath(Login_V1.checkBox_xpath));	   
			    JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", element);
			   
			//wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).click();
			System.out.println("Clicked on Check box");
			}
	}
	
	@When("^Check for ApproveIT page displayed$")
	public void check_for_ApproveIT_page_displayed() throws Throwable{
		
		System.out.println("Approve it");
		WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		if (validate.isDisplayed())
			System.out.println("Approveit message displayed");
			//Thread.sleep(60000);
		else
			System.out.println("Approveit message is not displayed");
		WebDriverWait wait = new WebDriverWait(wdriver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)));
				//.presenceOfElementLocated(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)));
	}
	
	@When("^i can click on apply button of home page$")
	public void i_can_click_on_apply_button_of_home_page() throws Throwable{
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(StepByStep_pages.Step_Home_ApplyBtn_xpath)));

		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Home_ApplyBtn_xpath));
		
		Thread.sleep(2000);
		
//		Actions actions = new Actions(wdriver);
		if (validate.isEnabled()) {
			System.out.println("Apply button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
//			actions.moveToElement(validate).sendKeys(Keys.ENTER);
//			actions.build().perform();
			Thread.sleep(1000);

			System.out.println("Clicked on Apply button");
		    Thread.sleep(2000);
		}
		else
			System.out.println("Apply button is NOT displayed");
	}
	
	
	@When("^Click Next button of login page$")
	public void click_Next_button_of_login_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Login_V1.Nxt_btn_xpath));
		
	    if (validate.isDisplayed()) {
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		scrollToElement("Nxt_btn_xpath");
			wdriver.findElement(By.xpath(Login_V1.Nxt_btn_xpath)).sendKeys(Keys.ENTER);
			scrollToElement("Nxt_btn_xpath");
	    }
	    else
	    	System.out.println("Next btn is NOT displayed");	

	    Thread.sleep(5000);
	}
	
	@When("^I can check error message for less numbers in ID$")
	public void i_can_check_error_message_for_less_numbers_in_ID() throws Throwable
	{
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		String otherMsg = wdriver.findElement(By.xpath(Login_V1.idNumber_OtherMsg_xpath)).getText();
		
		if  (otherMsg.contains("Please check that the ID Number is correct; contai"))
			System.out.println("Error message has been displayed for blank SAID");
		else
			System.out.println("SAID is not showing any error message");
	}
	
	@When("^I can check error message for ID Number$")
	public void i_can_check_error_message_for_ID_Number() throws Throwable{
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		String blankMsg = wdriver.findElement(By.xpath(Login_V1.idNumber_BlankerrMsg_xpath)).getText();

		if  (blankMsg.contains("This is a required field."))
			System.out.println("Error message for blank SAID is displayed");
		else
			System.out.println("SAID is not showing any error message");
	}
	
	
	
	
	@When("^i can check error message is displayed for invalid Cellnumber$")
	public void i_can_check_error_message_is_displayed_for_invalid_Cellnumber() throws Throwable
	{
//		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		Thread.sleep(3000);
		String otherMsg = wdriver.findElement(By.xpath(Login_V1.CellNumber_errMsg_xpath)).getText();
		
		if (otherMsg.contains("Please ensure the number and format are correct, e.g. 083 123 3469')]"))
			System.out.println("Error message has been displayed for invalid Cellphone number");
		else
			System.out.println("Cellphone number is not showing any error message");
	}
	
	@When("^i can check error message is displayed for blank Cellnumber$")
	public void i_can_check_error_message_is_displayed_for_blank_Cellnumber() throws Throwable
	{
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		String blankMsg = wdriver.findElement(By.xpath(Login_V1.CelldNumber_BlankerrMsg_xpath)).getText();
				
		if  (blankMsg.contains("This is a required field."))
			System.out.println("Error message has been displayed for blank Cellphone number");
		else
			System.out.println("Cellphone number is not showing any error message");
	}
	
	@When("^Check error messages displayed for all fields$")
	public void check_error_messages_displayed_for_all_fields() throws Throwable
	{
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		String idMsg = wdriver.findElement(By.xpath(Login_V1.ID_BlankerrMsg_all_xpath)).getText();
		String CellMsg = wdriver.findElement(By.xpath(Login_V1.CellNum_BlankerrMsg_all_xpath)).getText();
		String CheckMsg = wdriver.findElement(By.xpath(Login_V1.Checkbox_BlankerrMsg_all_xpath)).getText();
				
		if  (idMsg.contains("This is a required field."))
			System.out.println("SAID is blank");
		 if  (CellMsg.contains("This is a required field."))
			System.out.println("Cellphone number is blank");
		if  (CheckMsg.contains("This is a required field."))
			System.out.println("SAID is blank");
	}
	
	
	@After
 	public void tearDown(Scenario scenario) {
		
	    if (scenario.isFailed()) {
	      // Take a screenshot...
	      final byte[] screenshot = ((TakesScreenshot) wdriver).getScreenshotAs(OutputType.BYTES);
	      scenario.embed(screenshot, "image/png"); // ... and embed it in the report.
    	captureScreenshot(wdriver, "MFC");
	    }
	    wdriver.close();
	}
}
