package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import cucumber.api.java.en.When;

public class EnterOTP_V1_379 extends CommonSteps{

	@When("^check for OTP page of approveit$")
	public void check_for_OTP_page_of_approveit() throws Throwable,InterruptedException {
		
		String otpMsg = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		if (otpMsg.contains("A one-time password(OTP) was sent to")) {
			System.out.println("OTP page is displayed");
		}
		else
			System.out.println("OTP page is NOT displayed");
	}
	@When("^Otp page displayed correct with last four digit cellnumber with \"([^\"]*)\"$")
	public void otp_page_displayed_correct_with_last_four_digit_cellnumber_with(String mbNumber) throws Throwable {
		Thread.sleep(1000);
		   String msg = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		   
		   int size = wdriver.findElements(By.xpath("Login_approveit_page")).size();
		   String firstPart = msg.substring(0, size);
		   if (msg.contains(firstPart)) 
			   System.out.println("Cellnumber displayed correct");
			   else
				  System.out.println("Cellnumber is NOT displayed correct");
	}
	
	@When("^I can click on close button of OTP page$")
	public void i_can_click_on_close_button_of_OTP_page() throws Throwable,InterruptedException {
		
		WebElement validate = wdriver.findElement(By.id(Login_V1.approveit_close_btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Close button of OTP page field displayed");
			validate.sendKeys(Keys.ENTER);
		}
		else
			System.out.println("Close button of OTP page is NOT displayed");
		
	}
	
	@When("^Check for enter OTP field visibility$")
	public void check_for_enter_OTP_field_visibility() throws Throwable,InterruptedException {
		WebElement validate = wdriver.findElement(By.id(Login_V1.approveit_otp_id));
		if(validate.isDisplayed())
			System.out.println("OTP field displayed");
		else
			System.out.println("OTP field is NOT displayed");
	}
	
	@When("^i can type OTP \"([^\"]*)\" in Enter OTP field$")
	public void i_can_type_OTP_in_Enter_OTP_field(String otp) throws Throwable {
		wdriver.findElement(By.xpath(Login_V1.approveit_otp_id)).sendKeys(otp);
		System.out.println("OTP entered");
	}
	
	@When("^i can click on submit button of otp page$")
	public void i_can_click_on_submit_button_of_otp_page() throws Throwable {
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_submit_btn_xpath)).click();
		System.out.println("Submit button clicked");
	}
	
}
