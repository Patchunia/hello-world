package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class QualifyingCriteria_581 extends CommonSteps{

	@When("^Check for Qualifying Criteria page contents$")
	public void check_for_Qualifying_Criteria_page_contents() throws Throwable {
		String title = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)).getText();
		if(title.contains("Qualifying criteria"))
			System.out.println("Qualifying criteria page is displayed");
		else
			System.out.println("Qualifying criteria page is NOT displayed");
	}
	
	@When("^i can click on Apply button of qualifying criteria page$")
	public void i_can_click_on_Apply_button_of_qualifying_criteria_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_accept_btn_xpath));
		scrollToElement(Dashboard_V1.dashboard_accept_btn_xpath);
		if (validate.isDisplayed()) {
			System.out.println("Accept button displayed");
			validate.sendKeys(Keys.ENTER);
			System.out.println("Accept button clicked");
		}
		else
			System.out.println("Accept button is NOT displayed");	
		Thread.sleep(1000);
	}
	
	
}
