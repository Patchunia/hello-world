package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import main.java.Pages.Login_V1;
import cucumber.api.java.en.When;

public class Approveit_timeout_V1_377 extends CommonSteps {

	WebDriverWait wait = new WebDriverWait(wdriver, 20);
//	@When("^wait till given time for response$")
//	public void wait_till_given_time_for_response() throws Throwable {
//		Thread.sleep(60000);
//	}
	
	@When("^wait till timeout page display$")
	public void wait_till_timeout_page_display() throws Throwable {
		String timeout = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		if(timeout.contains("timed out")) {
			System.out.println("Timeout page displayed");
				 wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Login_V1.Login_approveit_timeout_page)));
	}
		else 
			System.out.println("Timed out page is NOT displayed");
	}
	
	@When("^Timeout page displayed with proper message$")
	public void Timeout_page_displayed_with_proper_message() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Login_V1.Login_approveit_timeout_page)));
		String msg =  wdriver.findElement(By.xpath(Login_V1.Login_approveit_timeout_page)).getText();
		if(msg.contains("timed out")) 
			System.out.println("Timeout page displayed");
		else
			System.out.println("Timeout page is NOT displayed");
		}
	
	@When("^check approve it msg is displayed$")
	public void check_approve_it_msg_is_displayed() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Login_V1.Login_approveit_timeout_page)));
		String msg =  wdriver.findElement(By.xpath(Login_V1.Login_approveit_timeout_page)).getText();
		if(msg.contains("approve it")) 
			System.out.println("Approve it page displayed");
		else
			System.out.println("Approve it page is NOT displayed");
		Thread.sleep(40000);
		}
		
	@When("^i can click on Resend button$")
	public void i_can_click_on_Resend_button() throws Throwable {
		WebElement validate =  wdriver.findElement(By.xpath(Login_V1.approveit_timeout_resend_xpath));
		Thread.sleep(1000);
		if(validate.isDisplayed()) {
			System.out.println("Resend button displayed");
			validate.sendKeys(Keys.ENTER);
		}
		else
			System.out.println("Resend button is NOT displayed");
	}
	
	@When("^check for OTP page displayed$")
	public void check_for_OTP_page_displayed() throws Throwable {
		String msg =  wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		Thread.sleep(1000);
		if(msg.contains("A one-time password(OTP) was sent to")) 
			System.out.println("OTP page displayed");
		else
			System.out.println("OTP page is NOT displayed");
	}
	

	
}
