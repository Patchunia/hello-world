package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepByStep_BudgetCalculator_399 extends CommonSteps{

	@And("^i can enter after deduction amount \"([^\"]*)\"$")
	public void i_can_enter_after_deduction_amount(String afterDedu) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("After Deduction field is displayed");
	    	afterDeduction.sendKeys(afterDedu);
		    System.out.println("Value entered in After Deduction field");
	    }
	    else
	    	System.out.println("After Deduction field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
	}
	
	@When("^check error message of After deduction of Budget calculator$")
	public void check_error_message_of_After_deduction_of_Budget_calculator() throws Throwable {
		
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for After Deduction field is displayed");
		    else
		    	System.out.println("Error message for After Deduction field is NOT displayed");
	}
	
	@When("^i can enter home loan amount \"([^\"]*)\"$")
	public void i_can_enter_home_loan_amount(String homeloan) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_homeloan_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Home loan field is displayed");
	    	afterDeduction.sendKeys(homeloan);
		    System.out.println("Value entered in home loan field");
	    }
	    else
	    	System.out.println("Home loan field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
		
	}
	
	@When("^check error message of home loan of Budget calculator$")
	public void check_error_message_of_home_loan_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Home loan field is displayed");
		    else
		    	System.out.println("Error message for Home loan field is NOT displayed");
	}
	
	@When("^i can enter utilities amount \"([^\"]*)\"$")
	public void i_can_enter_utilities_amount(String utilities) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_utilities_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("utilities field is displayed");
	    	afterDeduction.sendKeys(utilities);
		    System.out.println("Value entered in utilities field");
	    }
	    else
	    	System.out.println("utilities field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
	}
	
	@When("^check error message of utilities of Budget calculator$")
	public void check_error_message_of_utilities_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for utilities field is displayed");
		    else
		    	System.out.println("Error message for utilities field is NOT displayed");
	}
		
	@When("^i can enter household expenses amount \"([^\"]*)\"$")
	public void i_can_enter_household_expenses_amount(String household) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_household_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("household expenses field is displayed");
	    	afterDeduction.sendKeys(household);
		    System.out.println("Value entered in household expenses field");
	    }
	    else
	    	System.out.println("household expenses field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
	}
	
	@When("^check error message of householdexpenses of Budget calculator$")
	public void check_error_message_of_householdexpenses_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for household expenses field is displayed");
		    else
		    	System.out.println("Error message for household expenses field is NOT displayed");
	}
	
	@When("^i can enter Transportation amount \"([^\"]*)\"$")
	public void i_can_enter_Transportation_amount(String transportation) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_transpotartion_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Transportation field is displayed");
	    	afterDeduction.sendKeys(transportation);
		    System.out.println("Value entered in Transportation field");
	    }
	    else
	    	System.out.println("Transportation field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
	}
	
	@When("^check error message of Transportation of Budget calculator$")
	public void check_error_message_of_Transportation_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Transportation field is displayed");
		    else
		    	System.out.println("Error message for Transportation field is NOT displayed");
	}
	
	@When("^i can enter Policies amount \"([^\"]*)\"$")
	public void i_can_enter_Policies_amount(String Policies) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_PolicyNInsurance_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Policies field is displayed");
	    	afterDeduction.sendKeys(Policies);
		    System.out.println("Value entered in Policies field");
	    }
	    else
	    	System.out.println("Policies field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);
	}
	
	@When("^check error message of Policies of Budget calculator$")
	public void check_error_message_of_Policies_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Policies field is displayed");
		    else
		    	System.out.println("Error message for Policies field is NOT displayed");
	}
	
	@When("^i can enter Clothing amount \"([^\"]*)\"$")
	public void i_can_enter_Clothing_amount(String Clothing) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Clothing_xpath));
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Clothing field is displayed");
	    	afterDeduction.sendKeys(Clothing);
		    System.out.println("Value entered in Clothing field");
	    }
	    else
	    	System.out.println("Clothing field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
		
	}
	
	@When("^check error message of Clothing of Budget calculator$")
	public void check_error_message_of_Clothing_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Clothing field is displayed");
		    else
		    	System.out.println("Error message for Clothing field is NOT displayed");
	}
	
	@When("^i can enter Entertainment amount \"([^\"]*)\"$")
	public void i_can_enter_Entertainment_amount(String Entertainment) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Entertainment_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Entertainment field is displayed");
	    	afterDeduction.sendKeys(Entertainment);
		    System.out.println("Value entered in Entertainment field");
	    }
	    else
	    	System.out.println("Entertainment field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
		
	}
	
	@When("^check error message of Entertainment of Budget calculator$")
	public void check_error_message_of_Entertainment_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Entertainment field is displayed");
		    else
		    	System.out.println("Error message for Entertainment field is NOT displayed");
	}
	
	@When("^i can enter Education amount \"([^\"]*)\"$")
	public void i_can_enter_Education_amount(String Education) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Education_xpath));
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Education field is displayed");
	    	afterDeduction.sendKeys(Education);
		    System.out.println("Value entered in Education field");
	    }
	    else
	    	System.out.println("Education field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);
		
	}
	
	@When("^check error message of Education of Budget calculator$")
	public void check_error_message_of_Education_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Education field is displayed");
		    else
		    	System.out.println("Error message for Education field is NOT displayed");
	}
	@When("^i can enter Savings amount \"([^\"]*)\"$")
	public void i_can_enter_Savings_amount(String Savings) throws Throwable {
		Thread.sleep(1000);
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Savings_xpath));
	    Thread.sleep(1000);
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Savings field is displayed");
	    	afterDeduction.sendKeys(Savings);
		    System.out.println("Value entered in Savings field");
	    }
	    else
	    	System.out.println("Savings field is NOT displayed");
	    Thread.sleep(1000);
	    afterDeduction.sendKeys(Keys.TAB);		
	}
	
	@When("^check error message of Savings of Budget calculator$")
	public void check_error_message_of_Savings_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Savings field is displayed");
		    else
		    	System.out.println("Error message for Savings field is NOT displayed");
	}
	
	@When("^i can enter Phone amount \"([^\"]*)\"$")
	public void i_can_enter_Phone_amount(String Savings) throws Throwable {
	    WebElement afterDeduction = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Phone_xpath));
	    if(afterDeduction.isDisplayed()) {
	    	System.out.println("Phone field is displayed");
	    	afterDeduction.sendKeys(Savings);
		    System.out.println("Phone entered in Savings field");
	    }
	    else
	    	System.out.println("Phone field is NOT displayed");
	    	afterDeduction.sendKeys(Keys.TAB);		
	}
	
	@When("^check error message of Phone of Budget calculator$")
	public void check_error_message_of_Phone_of_Budget_calculator() throws Throwable {
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_afterDed_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Phone field is displayed");
		    else
		    	System.out.println("Error message for Phone field is NOT displayed");
	}
	
	@When("^Check for default selection of Credit card payments$")
	public void check_for_default_selection_of_Credit_card_payments() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_CreditCardPayment_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of Credit card payment is selected");
		else
			System.out.println("No Toggle of Credit card payment is NOT selected");
	}
	
	@When("^i can click on Yes toggle button of Credit card payment$")
	public void i_can_click_on_Yes_toggle_button_of_Credit_card_payment() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_CreditCardPayment_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of Credit card payment is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", yesToggle);
		}
		else
			System.out.println("Yes Toggle of Credit card payment is NOT selected");
	}
	@When("^check amount field is displayed of Credit card payment$")
	public void check_amount_field_is_displayed_of_Credit_card_payment() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_CreditCardPayment_amount_xpath));
		if(amount.isDisplayed()) {
			System.out.println("Amount of Credit card payment is selected");
		}
		else
			System.out.println("Amount of Credit card payment is NOT selected");
	}
	
	@When("^i can enter amount of credit card payment \"([^\"]*)\"$")
	public void i_can_enter_amount_of_credit_card_payment(String amount1) throws Throwable {
	    WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_CreditCardPayment_amount_xpath));
	    if(amount.isDisplayed()) {
	    	System.out.println("Amount of credit card payment field is displayed");
	    	amount.sendKeys(amount1);
		    System.out.println("Amount of credit card payment entered");
	    }
	    else
	    	System.out.println("Amount of credit card payment field is NOT displayed");
	    amount.sendKeys(Keys.TAB);		
	}
	
	@When("^Check for default selection of Account payments$")
	public void Check_for_default_selection_of_Account_payments() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_AccountPayment_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of account payment is selected");
		else
			System.out.println("No Toggle of account payment is NOT selected");
	}
	
	@When("^i can click on Yes toggle button of account payment$")
	public void i_can_click_on_Yes_toggle_button_of_account_payment() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_AccountPayment_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of Account payment is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", yesToggle);

		}
		else
			System.out.println("Yes Toggle of account payment is NOT selected");
	}
	@When("^check amount field is displayed of Account payment$")
	public void check_amount_field_is_displayed_of_Account_payment() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_AccountPayment_amount_xpath));
		if(amount.isDisplayed()) {
			System.out.println("Amount of account payment is selected");
		}
		else
			System.out.println("Amount of account payment is NOT selected");
	}
	
	@When("^i can enter amount of Account payment \"([^\"]*)\"$")
	public void i_can_enter_amount_of_Account_payment(String amount1) throws Throwable {
	    WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_AccountPayment_amount_xpath));
	    if(amount.isDisplayed()) {
	    	System.out.println("Amount of account payment field is displayed");
	    	amount.sendKeys(amount1);
		    System.out.println("Amount of account payment entered in Savings field");
	    }
	    else
	    	System.out.println("Amount of account payment field is NOT displayed");
	    amount.sendKeys(Keys.TAB);		
	}
	
	@When("^Check for default selection of Loan payments$")
	public void Check_for_default_selection_of_Loan_payments() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_LoanPayment_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of Loan payment is selected");
		else
			System.out.println("No Toggle of Loan payment is NOT selected");
	}
	
	@When("^i can click on Yes toggle button of loan payment$")
	public void i_can_click_on_Yes_toggle_button_of_loan_payment() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_LoanPayment_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of Loan payment is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", yesToggle);
		}
		else
			System.out.println("Yes Toggle of Loan payment is NOT selected");
	}
	@When("^check amount field is displayed of Loan payment$")
	public void check_amount_field_is_displayed_of_Loan_payment() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_LoanPayment_amount_xpath));
		if(amount.isDisplayed()) {
			System.out.println("Amount of Loan payment is selected");
		}
		else
			System.out.println("Amount of Loan payment is NOT selected");
	}
	
	@When("^i can enter amount of loan payment \"([^\"]*)\"$")
	public void i_can_enter_amount_of_loan_payment(String amount1) throws Throwable {
	    WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_LoanPayment_amount_xpath));
	    if(amount.isDisplayed()) {
	    	System.out.println("Amount of Loan payment field is displayed");
	    	amount.sendKeys(amount1);
		    System.out.println("Amount of Loan payment entered in Savings field");
	    }
	    else
	    	System.out.println("Amount of Loan payment field is NOT displayed");
	    amount.sendKeys(Keys.TAB);		
	}
	
	@When("^Check for default selection of Other payments$")
	public void check_for_default_selection_of_Other_payments() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_OtherPayment_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of Other payment is selected");
		else
			System.out.println("No Toggle of Other payment is NOT selected");
	}
	
	@When("^i can click on Yes toggle button of Other payment$")
	public void i_can_click_on_Yes_toggle_button_of_Other_payment() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_OtherPayment_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of Other payment is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", yesToggle);
		}
		else
			System.out.println("Yes Toggle of Other payment is NOT selected");
	}
	@When("^check amount field is displayed of Other payment$")
	public void check_amount_field_is_displayed_of_Other_payment() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_OtherPayment_amount_xpath));
		if(amount.isDisplayed()) {
			System.out.println("Amount of Other payment is selected");
		}
		else
			System.out.println("Amount of Other payment is NOT selected");
	}
	
	@When("^i can enter amount of other payment \"([^\"]*)\"$")
	public void i_can_enter_amount_of_other_payment(String amount1) throws Throwable {
	    WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_OtherPayment_amount_xpath));
	    if(amount.isDisplayed()) {
	    	System.out.println("Amount of Other payment field is displayed");
	    	amount.sendKeys(amount1);
		    System.out.println("Amount of Other payment entered in Savings field");
	    }
	    else
	    	System.out.println("Amount of Other payment field is NOT displayed");
	    amount.sendKeys(Keys.TAB);		
	}
	
	@Then("^check for calculations \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_for_calculations(String totalExp, String Surplus, String motorPayment, String cashprice) throws Throwable {
	  String totalExpenses = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_TotalExp_xpath)).getText();
	  if (totalExpenses.equals(totalExp))
		  System.out.println("It is calculated correct total expenses" + totalExpenses);
	  else
		  System.out.println("It is calculated incorrect total expenses");	  
	  String SurplusExpenses = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Surplus_xpath)).getText();
	  if (SurplusExpenses.equals(Surplus))
		  System.out.println("It is calculated correct surplus balance" + SurplusExpenses);
	  else
		  System.out.println("It is calculated incorrect surplus balance");	
	  
	  String MaxMotorPayment = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_MotorPayment_xpath)).getText();
	  if (MaxMotorPayment.equals(motorPayment))
		  System.out.println("It is calculated correct Motor payment" + MaxMotorPayment);
	  else
		  System.out.println("It is calculated incorrect motor payment");	
	  
	  String CashPrice = wdriver.findElement(By.xpath(StepByStep_pages.Step_BudgetCal_Cashprice_xpath)).getText();
	  if (CashPrice.equals(cashprice))
		  System.out.println("It is calculated correct Cash price" + CashPrice);
	  else
		  System.out.println("It is calculated incorrect Cash price");	
	}
}
