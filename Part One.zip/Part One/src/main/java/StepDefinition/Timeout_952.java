package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.LandingPage;
import cucumber.api.java.en.When;

public class Timeout_952 extends CommonSteps {

	@When("^User remains idle on any screen$")
	public void User_remains_idle_on_any_screen() throws Throwable {
		
		WebDriverWait wait = new WebDriverWait(wdriver, 5000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.timeout_page_details_xpath))); 
	}
	
	@When("^Timeout page will appear asking for logging out from website$")
	public void Timeout_page_will_appear_asking_for_logging_out_from_website() throws Throwable {
		String timeOut = wdriver.findElement(By.xpath(Dealer_pages.timeout_page_details_xpath)).getText();
		if(timeOut.equalsIgnoreCase("To keep you safe, your session will timeout in:"))
			System.out.println("Time out page is displayed");
		else
			System.out.println("Time out page is NOT displayed");
	}
	
	@When("^User can select the continue button to remain logged-in into the app$")
	public void user_can_select_the_continue_button_to_remain_loggedin_into_the_app() throws Throwable {
		WebElement continueBtn = wdriver.findElement(By.xpath(Dealer_pages.dealer_ApplicationState_Continue_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", continueBtn);
	    System.out.println("clicked on Continue button");
		
	}
	@When("^wait till home page displayed$")
	public void wait_till_home_page_displayed() throws Throwable {
		String timeOut = wdriver.findElement(By.xpath(Dealer_pages.timeout_page_details_xpath)).getText();
		if(timeOut.equalsIgnoreCase("To keep you safe, your session will timeout in:")) {
			System.out.println("Time out page is displayed");
			WebDriverWait wait = new WebDriverWait(wdriver, 60);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(LandingPage.landingpage_login_icon_xpath)));
			System.out.println("Home page displayed");
		}
		else
			System.out.println("Time out page is NOT displayed");
	}
}
