package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import main.java.Pages.Dealer_pages;
import main.java.Pages.P2P_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class Dealer_435_BankingDetails extends CommonSteps {

	@When("^Fill form of Employment details page and click on Next button \"([^\"]*)\"$")
	public void Fill_form_of_Employment_details_page_and_click_on_Next_button(String CurrEmpl) throws Throwable {
		//Employment Type
		
		WebElement empType = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_type_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", empType);
	    Thread.sleep(2000);
		WebElement optionEmp = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_SelItem_type_xpath));
		js.executeScript("arguments[0].click()", optionEmp);
		
		System.out.println("Employment type selected");
		Thread.sleep(1000);
		
		//  	Occupation type
		WebElement occupation = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_occupation_xpath));
		Thread.sleep(1000);
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", occupation);
	    Thread.sleep(2000);
		WebElement optionOccupation = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_occupation_selItem_xpath));
		js.executeScript("arguments[0].click()", optionOccupation);
		
		System.out.println("Occupation type selected");
		Thread.sleep(1000);
		
		//Enter Current Employer
		
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_employer_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(CurrEmpl);
			System.out.println("Current Employer is entered");
		}
		else
			System.out.println("Current employer is not displayed");		
		
		//Select industry
		WebElement indus = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_industry_xpath));
		Thread.sleep(2000);
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", indus);
	    Thread.sleep(2000);
		WebElement optionIndus = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_industry_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionIndus);
		
		System.out.println("Industry selected");
		Thread.sleep(2000);
		
		//Select Date
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_datepicker_startWorking_xpath));
		if (validate1.isDisplayed()) {
			//JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate1);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
//			cal.add(Calendar.DATE, -3);
//			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(date1);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month dp-current-day'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			System.out.println("Date before 3 days is selected");
			
		}
		else 
			System.out.println("Date before 3 days is NOT selected");
		
		//click on next
		Thread.sleep(2000);
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_next_btn_xpath));	
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
	    Thread.sleep(3000);
	}
	
	@When("^check for banking form page contents$")
	public void check_for_banking_form_page_contents() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingPageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingPageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("Your banking details"))
				System.out.println("Your banking details page is displayed");
		}
		else
			System.out.println("Your banking details page is NOT displayed");			
	}
	
	@When("^i can click on Next button of banking details$")
	public void i_can_click_on_Next_button_of_banking_details() throws Throwable {
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_next_btn_xpath));	
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
		//scrollToElement("Login_btn_xpath");
	}
	
	@When("^check blank error message of which bank field$")
	public void check_blank_error_message_of_which_bank_field() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_bankName_errMsg_xpath)).getText();
		if(errMsg.contains("Please select bank name"))
			System.out.println("Error message for bank name is displayed");
		else
			System.out.println("Error message for bank name is NOT displayed");
	}
	
	@When("^check blank error message of account number$")
	public void check_blank_error_message_of_account_number() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AcNumber_blank_err_xpath)).getText();
		if(errMsg.contains("This is a required field."))
			System.out.println("Error message for account number is displayed");
		else
			System.out.println("Error message for account number is NOT displayed");
	}
	
	@When("^check error message of account number for max chars$")
	public void check_error_message_of_account_number_for_max_chars() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AcNumber_blank_err_xpath)).getText();
		if(errMsg.contains("Maximum 11 character account number allowed."))
			System.out.println("Error message for account number is displayed");
		else
			System.out.println("Error message for account number is NOT displayed");
	}
	
	@When("^i can select which bank from list$")
	public void i_can_select_which_bank_from_list() throws Throwable {
		WebElement bank = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_bankName_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", bank);
	    Thread.sleep(2000);
		WebElement optionbank = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_bankName_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionbank);
		
		System.out.println("Bank name selected");
		Thread.sleep(1000);
	}
	
	@When("^i can enter account number \"([^\"]*)\"$")
	public void i_can_enter_account_number(String AcNo) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AcNumber_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(AcNo);
			System.out.println("Account number is entered");
		}
		else
			System.out.println("Account number is not displayed");
	}
	
	@When("^check error message of account type$")
	public void check_error_message_of_account_type() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AccountType_errMsg_xpath)).getText();
		if(errMsg.contains("Please select account type"))
			System.out.println("Error message for Account type is displayed");
		else
			System.out.println("Error message for Account type is NOT displayed");
	}
	
	@When("^i can select type of account$")
	public void i_can_select_type_of_account() throws Throwable {
		WebElement acctType = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AccountType_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", acctType);
	    Thread.sleep(2000);
		WebElement optionAcct = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_AccountType_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionAcct);
		System.out.println("Account type selected");
		Thread.sleep(1000);
	}
	
	@When("^i check branch code is autopopulated$")
	public void i_check_branch_code_is_autopopulated() throws Throwable {
		String branchCode = wdriver.findElement(By.xpath(Dealer_pages.dealer_bankingdetails_BranchName_xpath)).getAttribute("value");
		if(branchCode.isEmpty())
			System.out.println("Branch code is not populated");
		else
			System.out.println("Branch code is populated");
	}
}
