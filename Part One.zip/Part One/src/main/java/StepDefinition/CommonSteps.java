package main.java.StepDefinition;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.SkipException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;



import main.java.Library.WebDriverUtilities;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import main.java.Pages.Login_V1;
import cucumber.api.java.en.When;
//import io.appium.java_client.MobileElement;
//import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.ios.IOSDriver;
//import io.appium.java_client.service.local.AppiumDriverLocalService;

public abstract class CommonSteps
{
//	AppiumDriverLocalService service;
	public static WebDriver wdriver;
	public static String strCapAppPackage = "";
	public static String strCapPlatformName = "";
	public static String strBuildBatFilePath = "";
	public static String Browser = "";
	static Properties prop = new Properties();
	public ExtentReports rep = main.java.Library.ExtentManager.getInstance(); 
	public ExtentTest test;
	private static ExtentReports extent;
	
	
	/**
	 * Description: Constructor for CommonSteps
	 * Creates properties file object for use in the class
	 */
	public CommonSteps()
	{
		InputStream input = null;

		try
		{
			input = new FileInputStream("global.properties");

			// load a properties file
			prop.load(input);

		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	
	/**
	 * Description: Common step for I_Open_Web_MFC_Application_In_Browser step definition steps
	 * @throws Throwable
	 */
	
	public void i_Open_MFC_link_in_Browser() throws Throwable, MalformedURLException
	{
		String strCapAppPathName="";
		String chromeDriverPath="";

		Browser = prop.getProperty("browser.name");
		strCapAppPathName = prop.getProperty("cap.App");
		chromeDriverPath= prop.getProperty("cap.chromePath");
		System.out.println(" Starting test - Opening browser");

		Thread.sleep(1000);
		
		
		//PropertyConfigurator.configure("log4j.properties");
		
		if(Browser.equals("FF"))
		{
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\cc307706\\git\\mfc-non-dealer-direct-fe\\Libs\\BrowserDrivers\\geckodriver.exe");
			wdriver = new FirefoxDriver();
			WebDriverUtilities util = new WebDriverUtilities(wdriver);
			wdriver.get(strCapAppPathName);
			
			wdriver.manage().window().maximize();
//			logger.info("User Access Fire fox");
//			Assert.assertTrue(true);
		}
		
		// ********************************************this code is for Google chrome*******************************************
		if (Browser.equals("GC"))
		{
//			
			System.out.println(" Chrome browser opened");
	 		//String Node = "http://172.16.250.53:4444/wd/hub";
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\cc307706\\git\\mfc-non-dealer-direct-fe\\Libs\\BrowserDrivers\\chromedriver.exe");
			wdriver = new ChromeDriver(cap);	
			WebDriverUtilities util = new WebDriverUtilities(wdriver);
//			wdriver = new RemoteWebDriver(new URL("http://172.16.250.53:5555/wd/hub"),cap);
			wdriver.get(strCapAppPathName);			
//			wdriver = new RemoteWebDriver(new URL("http://172.16.250.53:5555/wd/hub"),cap);
			Thread.sleep(3000);
			wdriver.manage().window().maximize();
			Thread.sleep(5000);
	 		
//			Robot robot = new Robot();
//            robot.keyPress(KeyEvent.VK_CONTROL);
//            robot.keyPress(KeyEvent.VK_MINUS);
//            robot.keyRelease(KeyEvent.VK_CONTROL);
//            robot.keyRelease(KeyEvent.VK_MINUS);
      
//            robot.keyPress(KeyEvent.VK_CONTROL);
//            robot.keyPress(KeyEvent.VK_MINUS);
//            robot.keyRelease(KeyEvent.VK_CONTROL);
//            robot.keyRelease(KeyEvent.VK_MINUS);

//			logger.info("User Access Google Chrome");
//			Assert.assertTrue(true);
//			wait(10);
            Thread.sleep(2000);
		}
		
		// ********************************************IE*******************************************
		if (Browser.equals("IE"))
		{

			DesiredCapabilities  cap = DesiredCapabilities.internetExplorer();
			cap.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			cap.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setCapability("allow-blocked-content", true);
			cap.setCapability("allowBlockedContent", true);
			System.setProperty("webdriver.ie.driver", "C:\\Users\\cc307706\\git\\mfc-non-dealer-direct-fe\\Libs\\BrowserDrivers\\IEDriverServer.exe");
			wdriver = new InternetExplorerDriver(cap);
			
			
			WebDriverUtilities util = new WebDriverUtilities(wdriver);
			wdriver.get(strCapAppPathName);
			wdriver.manage().window().maximize();
		}
		
		
	}

	public static String captureScreenshot (WebDriver driver,String screenshotname)
	{

		if(driver.equals(wdriver))
		{
			String logFilename = new SimpleDateFormat("YYYYMMddHHmmsss").format(new Date());
			try
			{
				//Browser = prop.getProperty("browser.name");
				strBuildBatFilePath = prop.getProperty("npm.BuildFetchBatchFilePath");
				TakesScreenshot ts =(TakesScreenshot)wdriver;
				File  source = ts.getScreenshotAs(OutputType.FILE);
				String dest = strBuildBatFilePath + "/ScreenShots/screenshot"+"_"+screenshotname+"_"+logFilename+".png";
				File destination = new File(dest);
				FileUtils.copyFile(source, destination);
				System.out.println("Screenshot taken: " + screenshotname );
				return dest;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return e.getMessage();
			}   
		}
		else
		{
			String logFilename = new SimpleDateFormat("YYYYMMddHHmmsss").format(new Date());
			try
			{
				TakesScreenshot ts =(TakesScreenshot)driver;
				File  source = ts.getScreenshotAs(OutputType.FILE);
				String dest = strBuildBatFilePath + "/ScreenShots/screenshot"+"_"+screenshotname+"_"+logFilename+".png";
				File destination = new File(dest);
				FileUtils.copyFile(source, destination);
				System.out.println("screen shot taken" + screenshotname );
				return dest;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				return e.getMessage();
			}   
		}
	}
	public void scrollToElement(String locatorKey) {

		try {
			Actions action = new Actions(wdriver);
			System.out.println("ScrollElement");
			action.moveToElement(getElement(locatorKey)).build().perform();
		} catch (Exception e) {
			
		}

	}

	public WebElement getElement(String locatorKey) {

	WebElement element = null;
		try {
			
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
			for (int iCnt = 0; iCnt < 3; iCnt++) {
				// Execute javascript
				js.executeScript("arguments[0].style.border='2px groove red'", element);
				Thread.sleep(40);
				js.executeScript("arguments[0].style.border=''", element);
			}

		} catch (Exception e) {
			// FAIL THE TEST AND REPORT THE ERROR
			
			System.out.println(e.getMessage());
			// Assert.fail("Failed the Test " + e.getMessage());
		}
		
		return element;

	}
	public void i_close_MFC_Browser() throws Throwable{
		wdriver.close();
	}
	
	public void next_btn_click() throws InterruptedException {
		
		scrollToElement("Login_btn_xpath");
			//wdriver.findElement(By.xpath(Login_page.Login_btn_xpath)).click();
		WebElement element = wdriver.findElement(By.xpath(Login_page.Login_btn_xpath));	   
	    JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", element);
	    System.out.println("clicked on next button");
	   
			scrollToElement("Login_btn_xpath");
			Thread.sleep(2000);
	}
	
	public void enter_SAID(String SAid) {
		System.out.println("Enter SAID");
		wdriver.findElement(By.id(Login_V1.idNumber_id)).sendKeys(SAid);
		System.out.println("SAID entered");
		
	}
	
	public void enter_Cellnumber(String mbNumber) {
		wdriver.findElement(By.id(Login_V1.cellNumb_id)).sendKeys(mbNumber);

		System.out.println("Cellnumber entered");
		
	}
	
	public void approveit_page() {
		System.out.println("Approve it");
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		if (validate.isDisplayed())
			System.out.println("Approveit message displayed");
		
		else
			System.out.println("Approveit message is not displayed");
	}

	
		public void click_on_first_and_second_check_box() throws Throwable {
			
			if(wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).isSelected())
			{
				System.out.println("Already selected First Check box");
			}
			
			else {
				WebElement element = wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath));	   
			    JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", element);
			   
			//wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).click();
			System.out.println("Clicked on First Check box");
			}
		    
			if(wdriver.findElement(By.xpath(Login_page.Login_CheckBox2_xpath)).isSelected())
			{
				System.out.println("Already selected First Check box");
			}
			else {
				Thread.sleep(1000);
			//wdriver.findElement(By.xpath(Login_page.Login_CheckBox2_xpath)).click();
				WebElement element = wdriver.findElement(By.xpath(Login_page.Login_CheckBox2_xpath));	   
			    JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", element);
			   
			System.out.println("Clicked on Second Check box");
			}
	}
		public void nxt_btn_click(String locatorKey) {
			
			try {
				Actions action = new Actions(wdriver);
				action.moveToElement(getElement(locatorKey));
				action.click().build().perform();
			} catch (Exception e) {}

			
		}

}
