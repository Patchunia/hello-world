package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class StepByStepGuide_405 extends CommonSteps{

	
	@Given("^I open MFC web application in browser$")
	public void i_open_MFC_web_application_in_browser() throws Throwable {
		i_Open_MFC_link_in_Browser();
		
	}
	
	
	
	@When("^i can click on how does this work link$")
	public void i_can_click_on_how_does_this_work_link() throws Throwable {
		Thread.sleep(2000);
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_how_does_this_work_link_xpath));
		Actions action = new Actions(wdriver);
		if (validate.isDisplayed()) {
			System.out.println("How does this work link is displayed");
			action.moveToElement(validate).click();
			action.build().perform();
		}
		else
			System.out.println("How does this work link is NOT displayed");
	}
	
	@When("^I can see step by step guide page$")
	public void I_can_see_step_by_step_guide_page() throws Throwable {
		String title = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		
		if (title.contains("Step-by-step guide"))
			System.out.println("Step-by-step guide page is displayed");
		else
			System.out.println("Step-by-step guide page is NOT displayed");
		Thread.sleep(3000);
	}
	

	
	@When("^check all five icons are displayed$")
	public void check_all_five_icons_are_displayed() throws Throwable {
		String know_what_you_can_afford = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_link_xpath)).getText();
		
		if (know_what_you_can_afford.contains("Know what you can afford"))
			System.out.println("Know what you can afford icon is displayed");
		else
			System.out.println("Know what you can afford icon is NOT displayed");
		
		String find_vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Find_vehicle_link_xpath)).getText();
		
		if (find_vehicle.contains("Find a vehicle"))
			System.out.println("Find a vehicle icon is displayed");
		else
			System.out.println("Find a vehicle icon is NOT displayed");
		
		String Apply_for_finance = wdriver.findElement(By.xpath(StepByStep_pages.Step_Apply_for_finance_link_xpath)).getText();
		
		if (Apply_for_finance.contains("Apply for finance"))
			System.out.println("Apply for finance icon is displayed");
		else
			System.out.println("Apply for finance icon is NOT displayed");
		
		String Get_insurance = wdriver.findElement(By.xpath(StepByStep_pages.Step_Get_insurance_link_xpath)).getText();
		
		if (Get_insurance.contains("Get insurance"))
			System.out.println("Get insurance icon is displayed");
		else
			System.out.println("Get insurance icon is NOT displayed");
		
		String Sign_the_contract = wdriver.findElement(By.xpath(StepByStep_pages.Step_sign_the_contract_link_xpath)).getText();
		
		if (Sign_the_contract.contains("Sign the contract"))
			System.out.println("Sign the contract icon is displayed");
		else
			System.out.println("Sign the contract icon is NOT displayed");
		
	}
	
	
}
