package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class StepByStep_FindVehicle_696 extends CommonSteps {

	@When("^check for Find a Vehicle icon$")
	public void check_for_Find_a_Vehicle_icon() throws Throwable {
		String find_Vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Find_vehicle_link_xpath)).getText();
		
		if (find_Vehicle.contains("Find a vehicle"))
			System.out.println("Find a vehicle icon is displayed");
		else
			System.out.println("Find a vehicle icon is NOT displayed");
	}
	
	@When("^i can click on Find a vehicle icon$")
	public void i_can_click_on_Find_a_vehicle_icon() throws Throwable {
		String find_vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Find_vehicle_link_xpath)).getText();
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Find_vehicle_link_xpath));
		//Actions actions = new Actions(wdriver); 
		if (find_vehicle.contains("Find a vehicle")) {
			System.out.println("Find a vehicle icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("Clicked on Find a vehicle icon");
			Thread.sleep(1000);
		}
	}
	
	@When("^check for page contents of Find a Vehicle icon$")
	public void check_for_page_contents_of_Find_a_Vehicle_icon() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_heading_xpath)).getText();
		if (heading.equalsIgnoreCase("Find a vehicle"))
			System.out.println("Find a vehicle page id displayed");
		else
			System.out.println("Find a vehicle page id NOT displayed");
		
	}
	
	@When("^i can click on search for dealership$")
	public void i_can_click_on_search_for_dealership() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_SearchForDealership_Btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Search for a dealership link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Search for a dealership");
		}
		else
			System.out.println("Search for a dealership link is NOT displayed");
		
	}
	
		
}
