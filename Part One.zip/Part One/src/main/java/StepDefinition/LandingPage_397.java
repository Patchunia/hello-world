package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.LandingPage;
import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class LandingPage_397 extends CommonSteps {

	@When("^i can see What can you afford link$")
	public void i_can_see_What_can_you_afford_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Know_What_You_can_affort_link_xpath));
		if (validate.isDisplayed())
			System.out.println("What can you afford link is displayed");
		else
			System.out.println("What can you afford link is NOT displayed");
	}
	
	@When("^i can click on What can you afford link$")
	public void i_can_click_on_What_can_you_afford_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_whatYouCanAfford_link_xpath));
		if (validate.isDisplayed()) {
			System.out.println("What can you afford link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("What can you afford link is NOT displayed");
	}
	
	@When("^check for budget calculator page is displayed$")
	public void check_for_budget_calculator_page_is_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Budget calculator"))
			System.out.println("Budget Calculator page is displayed");
		else
			System.out.println("Budget Calculator page is NOT displayed");
	}
	
	@When("^i can click on Monthly instalment link$")
	public void i_can_click_on_Monthly_instalment_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_MonthlyExpenses_link_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Monthly instalment link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Monthly instalment link is NOT displayed");
	}
	
	@When("^i can click on back button of monthly expenses$")
	public void i_can_click_on_back_button_of_monthly_expenses() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_back_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Back button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Back button is NOT displayed");
	}
	
	
	@When("^check for monthly instalment page is displayed$")
	public void check_for_monthly_instalment_page_is_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Instalment calculator"))
			System.out.println("Instalment calculator page is displayed");
		else
			System.out.println("Instalment calculator page is NOT displayed");
	}
	
	@When("^i can see how does this work link$")
	public void i_can_see_how_does_this_work_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_how_does_this_work_link_xpath));
		if (validate.isDisplayed())
			System.out.println("how does this work link is displayed");
		else
			System.out.println("how does this work link is NOT displayed");
	}
	
	@When("^i can see search for dealership link$")
	public void i_can_see_search_for_dealership_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_SearchForDealership_link_xpath));
		if (validate.isDisplayed())
			System.out.println("Search for dealership link is displayed");
		else
			System.out.println("Search for dealership link is NOT displayed");
	}
	
	@When("^I can see Dealership link of how does this work$")
	public void i_can_see_Dealership_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_dealership_xpath));
		if (validate.isDisplayed())
			System.out.println("Dealership link is displayed");
		else
			System.out.println("Dealership link is NOT displayed");
	}
	
	@When("^I can see Private seller link of how does this work$")
	public void i_can_see_Private_seller_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_PrivateSeller_xpath));
		if (validate.isDisplayed())
			System.out.println("Private seller link is displayed");
		else
			System.out.println("Private sellers link is NOT displayed");
	}
	
	@When("^i can click on search for dealership link$")
	public void i_can_click_on_search_for_dealership_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_SearchForDealership_link_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Search for dealership link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Search for dealership link is NOT displayed");
	}
	
	@When("^i can click on Dealership link of how does this work$")
	public void i_can_click_on_Dealership_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_dealership_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Search for dealership link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Search for dealership link is NOT displayed");
	}
	
	@When("^i can click on Private Seller link of how does this work$")
	public void i_can_click_on_Private_Seller_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_PrivateSeller_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Private seller is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Private seller link is NOT displayed");
	}
	
	@When("^i can see Private Seller page of how does this work$")
	public void i_can_see_Private_Seller_page_of_how_does_this_work() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Buying from a private seller"))
			System.out.println("Private seller page is displayed");
		else
			System.out.println("Private seller page is NOT displayed");
	}
	
	@When("^I can see dealership page$")
	public void i_can_see_dealership_page() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Search for a dealership"))
			System.out.println("Search for a dealership page is displayed");
		else
			System.out.println("Search for a dealership page is NOT displayed");
	}
	
	@When("^I can see dashboard page$")
	public void i_can_see_dashboard_page() throws Throwable {
		String heading = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_page_contents_xpath)).getText();
		if (heading.equalsIgnoreCase("Your applications"))
			System.out.println("Your applications page is displayed");
		else
			System.out.println("Your applications page is NOT displayed");
	}
	

	@When("^i can click on FAQ link of how does this work$")
	public void i_can_click_on_FAQ_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_FAQ_xpath));
		if (validate.isDisplayed()) {
			System.out.println("FAQ is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("FAQ link is NOT displayed");
	}
	
	@When("^i can see Dashboard link$")
	public void i_can_see_Dashboard_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_dashboard_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Dashboard is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Dashboard link is NOT displayed");
	}
	
	
	@When("^I can see FAQ link of how does this work$")
	public void i_can_see_FAQ_link_of_how_does_this_work() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_FAQ_xpath));
		if (validate.isDisplayed()) 
			System.out.println("FAQ is displayed");
		else
			System.out.println("FAQ page is NOT displayed");
	}

	
	@When("^i can see FAQ page of how does this work$")
	public void i_can_see_FAQ_page_of_how_does_this_work() throws Throwable {
		String heading = wdriver.findElement(By.xpath(LandingPage.landingpage_howdoesthiswork_FAQ_page_xpath)).getText();
		if (heading.equalsIgnoreCase("General Questions"))
			System.out.println("FAQ page is displayed");
		else
			System.out.println("FAQ page is NOT displayed");
	}

	@When("^i can see dealership page of how does this work$")
	public void i_can_see_dealership_page_of_how_does_this_work() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Buying from a dealership"))
			System.out.println("Buying from a dealership page is displayed");
		else
			System.out.println("Buying from a dealership page is NOT displayed");
	}
	
	@When("^i can see login icon$")
	public void i_can_see_login_icon() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_login_icon_xpath));
		if (validate.isDisplayed())
			System.out.println("Login icon is displayed");
		else
			System.out.println("Login icon is NOT displayed");
	}
	
	@When("^i can click on login icon link$")
	public void i_can_click_on_login_icon_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_login_icon_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Login icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Login icon is NOT displayed");
	}

	@When("^check for login page displayed$")
	public void check_for_login_page_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Let’s get started"))
			System.out.println("Login page is displayed");
		else
			System.out.println("Login page is NOT displayed");
	}
	
	@When("^i can see view details of buying from dealership$")
	public void i_can_see_view_details_of_buying_from_dealership() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_buyingFromDealershipViewDetails_xpath));
		if (validate.isDisplayed())
			System.out.println("View details of Buying from Dealership is displayed");
		else
			System.out.println("View details of Buying from Dealership is NOT displayed");
	}
	
	@When("^i can click on view details of buying from dealership link$")
	public void i_can_click_on_view_details_of_buying_from_dealership_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_buyingFromDealershipViewDetails_xpath));
		if (validate.isDisplayed()) {
			System.out.println("View details of Buying from Dealership is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("View details of Buying from Dealership is NOT displayed");
	}
	
	@When("^check for view details of buying from dealership page displayed$")
	public void check_for_view_details_of_buying_from_dealership_page_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Buying from a dealership"))
			System.out.println("Buying from a dealership is displayed");
		else
			System.out.println("Buying from a dealership is NOT displayed");
	}
	
	@When("^i can see view details of buying from Private Seller$")
	public void i_can_see_view_details_of_buying_from_Private_Seller() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_buyingFromPrivateViewDetails_xpath));
		if (validate.isDisplayed())
			System.out.println("View details of Buying from Private Seller is displayed");
		else
			System.out.println("View details of Buying from Private Seller is NOT displayed");
	}
	
	@When("^i can click on view details of buying from Private Seller link$")
	public void i_can_click_on_view_details_of_buying_from_Private_Seller_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_buyingFromPrivateViewDetails_xpath));
		if (validate.isDisplayed()) {
			System.out.println("View details of Buying from Private seller is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("View details of Buying from Private seller is NOT displayed");
	}
	
	@When("^check for view details of buying from Private Seller page displayed$")
	public void check_for_view_details_of_buying_from_Private_Seller_page_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Buying from a private seller"))
			System.out.println("Buying from a private seller is displayed");
		else
			System.out.println("Buying from a private seller is NOT displayed");
	}
	
	@When("^i can see Find out more of Finance$")
	public void i_can_see_Find_out_more_of_Finance() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.Landingpage_FindoutMore_xpath));
		if (validate.isDisplayed())
			System.out.println("Find out more of Finance is displayed");
		else
			System.out.println("Find out more of Finance is NOT displayed");
	}
	
	@When("^i can click on Find out more of Finance link$")
	public void i_can_click_on_Find_out_more_of_Finance_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.Landingpage_FindoutMore_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Find out more of Finance is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Find out more of Finance is NOT displayed");
	}
	
	@When("^check for Find out more of Finance page displayed$")
	public void check_for_Find_out_more_of_Finance_page_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Apply for finance"))
			System.out.println("Find out more of Finance is displayed");
		else
			System.out.println("Find out more of Finance is NOT displayed");
	}
	
	@When("^i can see Contact us icon$")
	public void i_can_see_Contact_us_icon() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_icon_xpath));
		if (validate.isDisplayed())
			System.out.println("Contact us icon is displayed");
		else
			System.out.println("Contact us icon is NOT displayed");
	}
	
	@When("^i can click on Contact us icon link$")
	public void i_can_click_on_Contact_us_icon_link() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_icon_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Contact us icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Contact us icon is NOT displayed");
	}

	@When("^check for Contact us displayed$")
	public void check_for_Contact_us_displayed() throws Throwable {
		String heading = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_header_xpath)).getText();
		if (heading.equalsIgnoreCase("Contact Us"))
			System.out.println("Contact us is displayed");
		else
			System.out.println("Contact Us is NOT displayed");
	}
	
}
