package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class IncorrectOTPAttempt_410 extends CommonSteps{

	@When("^Check for Incorrect otp third attempt page$")
	public void check_for_Incorrect_otp_third_attempt_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_3times_incorrect_otp_page_xpath));
		if(validate.isDisplayed())
			System.out.println("Incorrect OTP for 3 times displayed");
		else
			System.out.println("Incorrect OTP for 3 times is not displayed");
	}
	
	@When("^i can click on submit button again$")
	public void i_can_click_on_submit_button_again() throws Throwable {
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_submit_btn_xpath)).click();
		System.out.println("Submit button clicked");
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.TermsNCondtion_page_xpath));
		if (validate.isDisplayed())
			System.out.println("Valid otp entered");
		else
			System.out.println("Invalid otp entered");
		
		
	}
	
	@When("^i can type valid OTP \"([^\"]*)\" in Enter OTP field again$")
	public void i_can_type_valid_OTP_in_Enter_OTP_field_again(String otp1) throws Throwable {
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_input_xpath)).clear();
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_input_xpath)).sendKeys(otp1);
		System.out.println("OTP1 entered");
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_submit_btn_xpath)).click();
		
	}
	
	@When("^i can enter otp for last time \"([^\"]*)\"$")
	public void i_can_enter_otp_for_last_time(String otp2) throws Throwable {
		
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_input_xpath)).clear();
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_input_xpath)).sendKeys(otp2);
		System.out.println("OTP2 entered");
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_otp_submit_btn_xpath)).click();
	}
	
	@When("^i can click on Cancel button$")
	public void i_can_click_on_Cancel_button() throws Throwable {
		wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_incorrect_otp_cancel_btn_xpath)).click();
	}
}
