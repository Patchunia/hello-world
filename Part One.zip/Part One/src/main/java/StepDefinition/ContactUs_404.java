package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.LandingPage;
import cucumber.api.java.en.When;

public class ContactUs_404 extends CommonSteps {

	@When("^check for mobile number$")
	public void check_for_mobile_number() throws Throwable {
		String heading = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_MobNum_xpath)).getText();
		if (heading.contains("0860 111 159"))
			System.out.println("Correct Mobile number 0860 111 159 is displayed");
		else
			System.out.println("Mobile Number 0860 111 159 is NOT displayed");
	}
	
	@When("^check for Finance Email$")
	public void check_for_Finance_Email() throws Throwable {
		String heading = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_Email_finance_xpath)).getText();
		if (heading.contains("directnewbus@mfc.co.za"))
			System.out.println("Finance email directnewbus@mfc.co.za is displayed");
		else
			System.out.println("Finance email directnewbus@mfc.co.za is NOT displayed");
	}
	
	@When("^check for Technical Email$")
	public void check_for_Technical_Email() throws Throwable {
		String heading = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_Email_Technical_xpath)).getText();
		if (heading.contains("mymfc@mfc.co.za"))
			System.out.println("Technical Email mymfc@mfc.co.za is displayed");
		else
			System.out.println("Technical Email mymfc@mfc.co.za is NOT displayed");
	}
	
	@When("^check for close button$")
	public void check_for_close_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_Close_xpath));
		if (validate.isDisplayed()) 
			System.out.println("Close button is displayed");
			
		else
			System.out.println("Close button is NOT displayed");
	}
	
	@When("^i can click on close button of contact us$")
	public void i_can_click_on_close_button_of_contact_us() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(LandingPage.landingpage_ContactUS_Close_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Close button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		}
		
		else
			System.out.println("Close button is NOT displayed");
	}
	
}
