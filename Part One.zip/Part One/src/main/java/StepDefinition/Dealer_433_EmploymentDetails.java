package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class Dealer_433_EmploymentDetails extends CommonSteps{
	
	@When("^Fill form of Residential page and click on Next button \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void Fill_form_of_Residential_page_and_click_on_Next_button(String addr, String addrLine2, String suburb) throws Throwable {
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
		//Physical Address
		Thread.sleep(2000);
		Actions action = new Actions(wdriver);
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_physicalAddress_xpath)));
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress_xpath));
//	    
		action.moveToElement(validate1);
		action.click();
//		js.executeScript("arguments[0].value="+validate1+";", addr);
		action.sendKeys(addr).build().perform();
		System.out.println("Physical Address is entered");
		
		// Line 2
		
		//WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_physicalAddress2_xpath)));
	
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress2_xpath));
		Thread.sleep(1000);
		action.moveToElement(validate).click();
		action.sendKeys(addrLine2).build().perform();
			System.out.println("Physical Address Line 2 is entered");
			
			
		//physical suburb
			scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
			System.out.println("Additional Born country field");
			//scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
			Thread.sleep(1000);
			WebElement validate3 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_xpath));
			
			if(validate1.isDisplayed()) {
				System.out.println("Physical Suburb field is displayed");
				validate1.sendKeys(Keys.TAB);
				action.moveToElement(validate3).click();
				action.sendKeys(suburb).build().perform();
				Thread.sleep(1000);
				
				
				//action.moveToElement(validate3).sendKeys(suburb).build().perform();
				System.out.println("Physical Suburb is enterred");
			}
			else
				System.out.println("Physical Suburb is NOT displayed");
			
			
			int size =  wdriver.findElements(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_selItem_xpath)).size();
			
			Thread.sleep(5000);
			if(size>0) {
				WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_selItem_xpath));
				if(item.isDisplayed()) {
					System.out.println("abled to search item");
					
					
				    js.executeScript("arguments[0].click()", item);
					System.out.println("item selected");
				}
				else
					System.out.println("item not found");
			}
//			else {
//				String item1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_invalid_Err_xpath)).getText();
//				if(item1.contains("No records found")) {
//					System.out.println("Search result of suburb is not found");
//					
//				}
	//	
				else
					System.out.println("Search result of physical suburb is found");
//			}
				Thread.sleep(5000);
				
				
			
		//Select Residential status
		WebElement status = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_residentialStatus_xpath));
		
		Thread.sleep(1000);
		//JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", status);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_residentialStatus_SelItem_xpath));
		action.moveToElement(option).click().build().perform();
		
		System.out.println("Residential status selected");
		Thread.sleep(1000);
		
		//Select move from here
		WebElement validate2 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_DatePicker_moveHere_xpath));
		Thread.sleep(2000);
		if (validate1.isDisplayed()) {
			//JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate2);
			System.out.println("clicked on Date picker");
			Thread.sleep(3000);
			scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			
//			cal.add(Calendar.DATE, -3);
//			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(date1);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month dp-current-day'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			
			System.out.println("Date before 3 days is selected");
			
		}
		else 
			System.out.println("Date before 3 days is NOT selected");
		
		//Click on Next button
		Thread.sleep(2000);
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_next_btn_xpath));	
		js.executeScript("arguments[0].click()", element);
		Thread.sleep(3000);
//		int alert = wdriver.findElements(By.xpath("//*[@id='closeAlert']")).size();
//		if(alert>0) {
//			WebElement btn = wdriver.findElement(By.xpath("//*[@id='closeAlert']"));
//			js.executeScript("arguments[0].click()", btn);
//			action.moveToElement(validate).click();
//			action.sendKeys(addrLine2).build().perform();
//			js.executeScript("arguments[0].click()", element);
//		}
//		else
//			System.out.println("Server side alert displayed");
	}

	
	@When("^check Employment details page contents$")
	public void check_Employment_details_page_contents() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentPageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentPageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("Your employment details"))
				System.out.println("Your employment details page is displayed");
		}
		else
			System.out.println("Your employment details page is NOT displayed");
			
	}
	
	@When("^i can click on Next button of employment details page$")
	public void i_can_click_on_Next_button_of_employment_details_page() throws Throwable {
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_next_btn_xpath));	
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
		//scrollToElement("Login_btn_xpath");
	}
	@When("^check blank error message of employment details$")
	public void check_blank_error_message_of_employment_details() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_errMsg_xpath)).getText();
		if(errMsg.contains("Please select employment type"))
			System.out.println("Error message for Employment type is displayed");
		else
			System.out.println("Error message for Employment type is NOT displayed");
	}
	
	@When("^i can select employment type$")
	public void i_can_select_employment_type() throws Throwable {
		WebElement empType = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_type_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", empType);
	    Thread.sleep(2000);
		WebElement optionEmp = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_SelItem_type_xpath));
		js.executeScript("arguments[0].click()", optionEmp);
		
		System.out.println("Employment type selected");
		Thread.sleep(1000);
	}
	
	@When("^check blank error message for occupation type$")
	public void check_blank_error_message_for_occupation_type() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_occupation_errMsg_xpath)).getText();
		if(errMsg.contains("Please select occupation"))
			System.out.println("Error message for occupation type is displayed");
		else
			System.out.println("Error message for occupation type is NOT displayed");
	}
	
	@When("^i can select Occupation type$")
	public void i_can_select_Occupation_type() throws Throwable {
		WebElement occupation = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_occupation_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", occupation);
	    Thread.sleep(2000);
		WebElement optionOccupation = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_occupation_selItem_xpath));
		js.executeScript("arguments[0].click()", optionOccupation);
		
		System.out.println("Occupation type selected");
		Thread.sleep(1000);
	}
	
	@When("^check blank error message for Current Employer$")
	public void check_blank_error_message_for_Current_Employer() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_employer_blank_err_xpath_xpath)).getText();
		if(errMsg.contains("This is a required field"))
			System.out.println("Error message for Employer is displayed");
		else
			System.out.println("Error message for Employer is NOT displayed");
	}
	
	@When("^check error message of Current Employer for Max chars$")
	public void check_error_message_of_Current_Employer_for_Max_chars() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_employer_max_err_xpath_xpath)).getText();
		if(errMsg.contains("Maximum 55 characters allowed."))
			System.out.println("Error message for Employer is displayed");
		else
			System.out.println("Error message for Employer is NOT displayed");
	}
	
	@When("^check error message of Current Employer for special chars$")
	public void check_error_message_of_Current_Employer_for_special_chars() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_employer_max_err_xpath_xpath)).getText();
		if(errMsg.contains("Please enter only characters."))
			System.out.println("Error message for Employer is displayed");
		else
			System.out.println("Error message for Employer is NOT displayed");
	}
	
	@When("^i can enter Current Employer of Employment details \"([^\"]*)\"$")
	public void i_can_enter_Current_Employer_of_Employment_details(String CurrEmpl) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_employer_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(CurrEmpl);
			System.out.println("Current Employer is entered");
		}
		else
			System.out.println("Current employer is not displayed");
	}
	
	@When("^Check blank error message of industry$")
	public void Check_blank_error_message_of_industry() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_industry_errMsg_xpath)).getText();
		if(errMsg.contains("Please select industry type"))
			System.out.println("Error message for industry is displayed");
		else
			System.out.println("Error message for industry is NOT displayed");
	}
	@When("^i can select Industry$")
	public void i_can_select_Industry() throws Throwable {
		WebElement indus = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_industry_xpath));
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", indus);
	    Thread.sleep(2000);
		WebElement optionIndus = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_industry_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionIndus);
		
		System.out.println("Industry selected");
		Thread.sleep(2000);
	}
	
	@When("^check blank error message for Start Current Employer$")
	public void check_blank_error_message_for_Start_Current_Employer() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_date_errMsg_xpath)).getText();
		if(errMsg.contains("Please select valid date"))
			System.out.println("Error message for date is displayed");
		else
			System.out.println("Error message for date is NOT displayed");
	}
	
	@When("^i can select date from calendar for current employer$")
	public void i_can_select_date_from_calendar_for_current_employer() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_employmentdetails_datepicker_startWorking_xpath));
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
//			cal.add(Calendar.DATE, -3);
//			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(date1);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month dp-current-day'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			System.out.println("Date before 3 days is selected");
			
		}
		else 
			System.out.println("Date before 3 days is NOT selected");
	}
}

