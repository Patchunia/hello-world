package main.java.StepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.Dealer_pages;
import cucumber.api.java.en.When;

public class SearchForDealerShip_409 extends CommonSteps {
	
	@When("^i can select Province drop down$")
	public void i_can_select_Province_drop_down() throws Throwable {
		
		WebElement province = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SearchDealership_province_xpath));
		Actions action = new Actions(wdriver);
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", province);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SearchDealership_province_SelItem_xpath));
		action.moveToElement(option).click().build().perform();
		
		System.out.println("Province is selected");
		Thread.sleep(1000);
		
	}
	
	@When("^i can select Suburb drop down$")
	public void i_can_select_Suburb_drop_down() throws Throwable {
		
		WebElement region = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SearchDealership_region_xpath));
		Actions action = new Actions(wdriver);
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", region);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SearchDealership_province_SelItem_xpath));
		action.moveToElement(option).click().build().perform();
		
		System.out.println("Region is selected");
		Thread.sleep(1000);
		
	}
	
	@When("^i can click on Search button$")
	public void i_can_click_on_Search_button() throws Throwable {
		
		WebElement search = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SearchDealership_Search_btn_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", search);
	    Thread.sleep(2000);
	}

	@When("^check for search result$")
	public void check_for_search_result() throws Throwable {
		// Grab the table
		WebElement table = wdriver.findElement(By.xpath("//table[contains(@class,'table table-responsive')]"));
		
		// Now get all the TR elements from the table
		List<WebElement> allRows = table.findElements(By.tagName("tr"));
		// And iterate over them, getting the cells
		for (WebElement row : allRows) {
		    List<WebElement> cells = row.findElements(By.tagName("td"));
		    for (WebElement cell : cells) {
		        System.out.println("content >>   " + cell.getText());
		    }
		}
	
	}
}
