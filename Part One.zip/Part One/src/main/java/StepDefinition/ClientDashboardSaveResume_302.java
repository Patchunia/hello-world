package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class ClientDashboardSaveResume_302 extends CommonSteps{

	@When("^i can click on your dashboard$")
	public void i_can_click_on_your_dashboard() throws Throwable {
		WebElement dashboard=wdriver.findElement(By.xpath(Dashboard_V1.dashboard_link_xpath));
		if(dashboard.isDisplayed()) {
			System.out.println("Dashboard link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", dashboard);
		    System.out.println("Clicked on Dashboard link");
		}
		else
			System.out.println("Dashboard link is NOT displayed");
		Thread.sleep(2000);
	}
	
	@When("^check page contents of client dashboard$")
	public void check_page_contents_of_client_dashboard() throws Throwable {
		String title = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_page_contents_xpath)).getText();
		if (title.contains("Your applications")) 
			System.out.println("Save and Resume dashboard is displayed");
		else
			System.out.println("Save and Resume dashboard is NOT displayed");
	}
	
	
	@When("^check for in progress count$")
	public void check_for_in_progress_count() throws Throwable {
		
		int a = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_SaveResume_inProgress_Count_xpath)).size();
		System.out.println("a = "+a);
		int count=0;
		
		for (int i = 0; i< a;i++) {
			count = count+1;
			System.out.println(count);
			
		}
		System.out.println("count = "+count);
		
		String value = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_inProgress_TotalCount_xpath)).getText();
		System.out.println("value = "+value);
		//if (value.equals(count))
		if((count-1)==Integer.parseInt(value))
			System.out.println("In progress count is matching");
		else
			System.out.println("In progress count is NOT matching");		
	}
	
	@When("^check for being accessed count$")
	public void check_for_being_accessed_count() throws Throwable {
		
		int a = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_SaveResume_BeingAccessed_Count_xpath)).size();
		System.out.println("a = "+a);
		int count=0;
		
		for (int i = 0; i< a;i++) {
			count = count+1;
			System.out.println(count);
			
		}
		System.out.println("count = "+count);
		String value = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_BeingAccessed_TotalCount_xpath)).getText();
		System.out.println("value = "+value);
		//if (value.equals(count))
		if(count==Integer.parseInt(value))
			System.out.println("Being Accessed count is matching");
		else
			System.out.println("Being Accessed count is NOT matching");		
	}
	
	@When("^check for pending count$")
	public void check_for_pending_count() throws Throwable {
		
		int a = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_SaveResume_Pending_Count_xpath)).size();
		System.out.println("a = "+a);
		int count=0;
		
		for (int i = 0; i< a;i++) {
			count = count+1;
			System.out.println(count);
			
		}
		System.out.println("count = "+count);
		String value = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_Pending_TotalCount_xpath)).getText();
		System.out.println("value = "+value);
		//if (value.equals(count))
		if((count-1)==Integer.parseInt(value))
			System.out.println("Pending count is matching");
		else
			System.out.println("Pending count is NOT matching");		
	}
	
	@When("^check for approved count$")
	public void check_for_approved_count() throws Throwable {
		
		int a = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_SaveResume_Approved_Count_xpath)).size();
		System.out.println("a = "+a);
		int count=0;
		
		for (int i = 0; i< a;i++) {
			count = count+1;
			System.out.println(count);
			
		}
		System.out.println("count = "+count);
		String value = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_Approved_TotalCount_xpath)).getText();
		System.out.println("value = "+value);
		//if (value.equals(count))
		if((count-1)==Integer.parseInt(value))
			System.out.println("Approved count is matching");
		else
			System.out.println("Approved count is NOT matching");		
	}
	
	@When("^check for declined count$")
	public void check_for_declined_count() throws Throwable {
		
		int a = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_SaveResume_Declined_Count_xpath)).size();
		System.out.println("a = "+a);
		int count=0;
		
		for (int i = 0; i< a;i++) {
			count = count+1;
			System.out.println(count);
			
		}
		System.out.println("count = "+count);
		String value = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_SaveResume_Declined_TotalCount_xpath)).getText();
		System.out.println("value = "+value);
		//if (value.equals(count))
		if((count-1)==Integer.parseInt(value))
			System.out.println("Declined count is matching");
		else
			System.out.println("Declined count is NOT matching");		
	}
	
	@When("^check resume button of first in progress item$")
	public void check_resume_button_of_first_in_progress_item() throws Throwable {
		WebElement resumeBtn=wdriver.findElement(By.xpath(Dashboard_V1.dashboard_Resume_btn_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", resumeBtn);
	    System.out.println("clicked on Resume button");
	}
}
