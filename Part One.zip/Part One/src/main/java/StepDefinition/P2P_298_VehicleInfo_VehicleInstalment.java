package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.P2P_pages;
import cucumber.api.java.en.When;

public class P2P_298_VehicleInfo_VehicleInstalment extends CommonSteps{
	
	@When("^Fill form of About your Vehicle of Private seller and click on Next button$")
	public void Fill_form_of_About_your_Vehicle_of_Private_seller_and_click_on_Next_button() throws Throwable {
		//Vehicle Year
		
		WebElement vehicleYear = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleYear_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", vehicleYear);
	    Thread.sleep(2000);
		WebElement optionYear = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleYear_SelItem_xpath));
		js.executeScript("arguments[0].click()", optionYear);
		System.out.println("Vehicle make selected");
		Thread.sleep(4000);
		
		// Vehicle Make
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_xpath)));
		WebElement vehicleMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_xpath));
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", vehicleMake);
	    Thread.sleep(3000);
		WebElement optionMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_selItem_xpath));
		js.executeScript("arguments[0].click()", optionMake);
		System.out.println("Vehicle make selected");
		Thread.sleep(2000);
		
		//vehicle Model
		
		Thread.sleep(2000);
		WebElement vehicleModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_xpath));
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", vehicleModel);
	    scrollToElement(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath);
	    Thread.sleep(2000);
		WebElement optionModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_selItem_xpath));
		js.executeScript("arguments[0].click()", optionModel);
		System.out.println("Vehicle model selected");
		Thread.sleep(2000);
		// Next button
		scrollToElement(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Next button is displayed");		
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button is clicked");
			Thread.sleep(1000);
		}
		else
			System.out.println("Next button is NOT displayed");
		Thread.sleep(2000);
	}

	@When("^click on next button of Private seller Vehicle Instalment page$")
	public void click_on_next_button_of_Private_seller_Vehicle_Instalment_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_VehicleInstalment_Nxt_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Next button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button is clicked");
		}
		else
			System.out.println("Next button is NOT displayed");
		Thread.sleep(3000);
	}
}
