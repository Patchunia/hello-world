package main.java.StepDefinition;

import org.openqa.selenium.By;

import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class Approveit_reject_378 extends CommonSteps{
	
	@When("^check for reject page$")
	public void check_for_reject_page() throws Throwable{
		String reject = wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_rejected_page_xpath)).getText();
		if (reject.equalsIgnoreCase("You have rejected the Approve-it� message"))
			System.out.println("Reject page displayed");
		else
			System.out.println("Reject page is NOT displayed");
	}
	


}
