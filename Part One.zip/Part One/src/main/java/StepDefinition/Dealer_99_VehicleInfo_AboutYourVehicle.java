package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class Dealer_99_VehicleInfo_AboutYourVehicle extends CommonSteps {
	
	@When("^Fill form of Personal Income page and click on Next button \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void fill_form_of_Personal_Income_page_and_click_on_Next_button(String bDeduction, String aDeduction, String mExp) throws Throwable {
	   //Before Deduction
		
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_PersonalIncome_BeforeDed_xpath)));
		scrollToElement(Dealer_pages.dealer_PersonalIncome_next_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_BeforeDed_xpath));
		Actions action = new Actions(wdriver);
		action.moveToElement(validate).click();
		action.sendKeys(bDeduction).build().perform();
//			validate.sendKeys(bDeduction);
			Thread.sleep(1000);
		//After deduction
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_PersonalIncome_AfterDed_xpath)));
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_AfterDed_xpath));
		action.moveToElement(validate1).click();
		action.sendKeys(aDeduction).build().perform();	
				Thread.sleep(1000);
		
		//Monthly Expenses
		WebElement validate2 = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_monthlyExpense_xpath));
			validate2.sendKeys(mExp);
			Thread.sleep(1000);
			System.out.println("Monthly expenses is entered");
			validate2.sendKeys(Keys.TAB);
		
		//Next button
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_PersonalIncome_next_btn_xpath));	
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
	    Thread.sleep(3000);
	}

	@When("^click on next button of About vehicle page$")
	public void click_on_next_button_of_About_vehicle_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Next button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button is clicked");
		}
		else
			System.out.println("Next button is NOT displayed");
		
	}
	
	@When("^check Page contents of About your vehicle$")
	public void check_Page_contents_of_About_your_vehicle() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_pageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_pageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("About your vehicle"))
				System.out.println("About Your Vehicle page is displayed");
		}
		else
			System.out.println("About Your Vehicle page is NOT displayed");

	}

	@When("^Check defalut value of Is this a new vehicle toggle button$")
	public void Check_defalut_value_of_Is_this_a_new_vehicle_toggle_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_NewVehicle_noToggle_xpath));
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_NewVehicle_yesToggle_xpath));
		if(validate.isDisplayed()) {
			if(validate.isEnabled())
				System.out.println("No toggle of New vehicle is enabled");
			else
				System.out.println("No toggle of New vehicle is NOT enabled");
		}
		else
			System.out.println("No toggle of New vehicle is NOT displayed");
		
		if(validate1.isDisplayed()) {
			if(validate1.isEnabled())
				System.out.println("Yes toggle of New vehicle is NOT enabled");
			else
				System.out.println("No toggle of New vehicle is enabled");
		}
		else
			System.out.println("Yes toggle of New vehicle is NOT displayed");
		
	}
	
	@When("^i can click on No toggle button$")
	public void i_can_click_on_No_toggle_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_NewVehicle_noToggle_xpath));
		if (validate.isDisplayed()) {
			System.out.println("No toggle of New vehicle is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("No toggle button is clicked");
		}
		else
			System.out.println("No toggle of New vehicle is NOT displayed");
	}
	
	@When("^i can click on Next button of about vehicle of dealer$")
	public void i_can_click_on_Next_button_of_about_vehicle_of_dealer() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Next button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button is clicked");
		}
		else
			System.out.println("Next button is NOT displayed");
		
	}
	
	@When("^i can select dealer \"([^\"]*)\"$")
	public void i_can_select_dealer(String dealer) throws Throwable {
		//Select dealer
		Thread.sleep(1000);
		System.out.println("Dealer field");
		Actions action = new Actions(wdriver);
		Thread.sleep(2000);
		
		WebDriverWait wait = new WebDriverWait(wdriver, 30);
		WebElement deal = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//INPUT[@_ngcontent-c16='']")));
		Thread.sleep(2000);		
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
		int count = 0;
		boolean clicked = false;
		while (count < 4 || !clicked){
		    try {
		       WebElement yourSlipperyElement= wdriver.findElement(By.xpath("//INPUT[@_ngcontent-c16='']"));
		       	if(clicked==false) {
		       	action.moveToElement(yourSlipperyElement);
				 action.click();
				 action.sendKeys(dealer).build().perform();
		         clicked = true;
		         count=4;
		       	}
		     } catch (StaleElementReferenceException e){
		       e.toString();
		       System.out.println("Trying to recover from a stale element :" + e.getMessage());
		       count = count+1;
		     }
		
		Thread.sleep(2000);
		System.out.println("dealer entered");
		Thread.sleep(2000);
		int size =  wdriver.findElements(By.xpath(Dealer_pages.dealer_abtVehicle_dealer_SelItem_xpath)).size();
		Thread.sleep(3000);
	if(size>0) {
		WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_dealer_SelItem_xpath));
		if(item.isDisplayed()) {
			System.out.println("abled to search item");
		    js.executeScript("arguments[0].click()", item);
			System.out.println("item selected");
			
			
		}
		else
			System.out.println("item not found");
	}
		else
			System.out.println("Search result is found");
		}
		Thread.sleep(2000);
	}
	


	public boolean retryFindClick(WebElement locatorKey, String value) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 2) {
			try {
				locatorKey.sendKeys(value);
				result = true;
				break;
				}
			catch(StaleElementReferenceException e) {}
			attempts++;
		}
		return result;		
	}
	
	@When("^check for invalid dealer search$")
	public void check_for_invalid_dealer_search() throws Throwable {
		String item = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_blankErr_xpath)).getText();
		if(item.contains("No records found")) {
			System.out.println("Search result is not found");
			
		}
		else
			System.out.println("Search result is found");
	}
	
	
	
	@When("^check blank error message of make vehicle$")
	public void check_blank_error_message_of_make_vehicle() throws Throwable {
		String vehicleYear = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_errMsg_xpath)).getText();
		if (vehicleYear.contains("Please select make")) 
			System.out.println("Blank Year of Vehicle make is displayed");	
		else
			System.out.println("Blank Year of Vehicle make is NOT displayed");
	}
	
	@When("^i can select Vehicle make$")
	public void i_can_select_Vehicle_make() throws Throwable {
		WebElement vehicleMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", vehicleMake);
	    Thread.sleep(2000);
		WebElement optionMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_selItem_xpath));
		js.executeScript("arguments[0].click()", optionMake);
		System.out.println("Vehicle make selected");
		Thread.sleep(1000);
	}
	
	@When("^i can select vehicle model$")
	public void i_can_select_vehicle_model() throws Throwable {
		Thread.sleep(2000);
		WebElement vehicleModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_xpath));
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", vehicleModel);
	    scrollToElement(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath);
	    Thread.sleep(2000);
		WebElement optionModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_selItem_xpath));
		js.executeScript("arguments[0].click()", optionModel);
		System.out.println("Vehicle model selected");
		Thread.sleep(1000);
	}
	
	@When("^check blank error message of model vehicle$")
	public void check_blank_error_message_of_model_vehicle() throws Throwable {
		String vehicleYear = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_errMsg_xpath)).getText();
		if (vehicleYear.contains("Please select vehicle model")) 
			System.out.println("Blank Year of Vehicle make is displayed");	
		else
			System.out.println("Blank Year of Vehicle make is NOT displayed");
	}
}
