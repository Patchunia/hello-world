package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class StepByStep_ApplyFinance_301 extends CommonSteps{

	@When("^check for Apply for finance icon$")
	public void check_for_Apply_for_finance_icon() throws Throwable {
		String find_Vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Apply_for_finance_link_xpath)).getText();
		
		if (find_Vehicle.contains("Apply for finance"))
			System.out.println("Apply for finance icon is displayed");
		else
			System.out.println("Apply for finance icon is NOT displayed");
	}
	
	@When("^i can click on Apply for Finance icon$")
	public void i_can_click_on_Apply_for_Finance_icon() throws Throwable {
		String find_vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Apply_for_finance_link_xpath)).getText();
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Apply_for_finance_link_xpath));
		//Actions actions = new Actions(wdriver); 
		if (find_vehicle.contains("Apply for finance")) {
			System.out.println("Apply for finance icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("Clicked on Apply for finance icon");
			Thread.sleep(1000);
		}
		else
			System.out.println("Apply for finance icon is NOT displayed");
	}
	
	@When("^check for page contents of apply for finance icon$")
	public void check_for_page_contents_of_apply_for_finance_icon() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_ApplyFinance_heading_xpath)).getText();
		if (heading.equalsIgnoreCase("Apply for finance"))
			System.out.println("Apply for finance page id displayed");
		else
			System.out.println("Apply for finance page id NOT displayed");
		
	}
	
	@When("^I can click on View Finance options$")
	public void i_can_click_on_View_Finance_options() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_ViewFinanceOption_link_xpath));
		if(validate.isDisplayed()) {
			System.out.println("View Finance options link is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on View Finance options");
		}
		else
			System.out.println("View Finance options link is NOT displayed");
		
	}
	
	@When("^check for page contents of View finance option$")
	public void check_for_page_contents_of_View_finance_option() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_FinanceOption_heading_xpath)).getText();
		if (heading.equalsIgnoreCase("Finance options"))
			System.out.println("Finance options page id displayed");
		else
			System.out.println("Finance options page id NOT displayed");
		
	}
	
	@When("^i can click on Back button$")
	public void i_can_click_on_Back_button() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Back_Btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Back button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Back button");
		}
		else
			System.out.println("Back button is NOT displayed");
	}
	
	
	
	
}
