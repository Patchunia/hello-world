package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


import main.java.Pages.BuyingPages_page;
import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class BuyingOption_408 extends CommonSteps{

	
	@When("^check Buying option page contents$")
	public void check_Buying_option_page_contents() throws Throwable {
		String title= wdriver.findElement(By.xpath(BuyingPages_page.buying_page_title_xpath)).getText();
		if (title.contains("Whom are you buying from?")) {
			System.out.println("Buying option page displayed");
		}
		else
			System.out.println("Buying option page is NOT displayed");	
		
	}
	Actions actions = new Actions(wdriver);
	@When("^i can click on buying from a dealership$")
	public void i_can_click_on_buying_from_a_dealership() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_class_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("Dealer icon displayed");
			actions.moveToElement(validate);
	        actions.sendKeys(Keys.ENTER);
	        actions.build().perform();
	        System.out.println("Dealer icon clicked");
		}
		else
			System.out.println("Dealer icon is NOT displayed");	
		
	}
	
	@When("^i can click on Next button of dealer$")
	public void i_can_click_on_Next_button_of_dealer() throws Throwable {
WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_Nxt_Btn_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("Next button of Dealer displayed");
			actions.moveToElement(validate);
	        actions.sendKeys(Keys.ENTER);
	        actions.build().perform();
	        System.out.println("Next button of Dealer clicked");
		}
		else
			System.out.println("Next button of Dealer is NOT displayed");	
	}
	
	//P2P
	
	@When("^i can click on buying from a private seller$")
	public void i_can_click_on_buying_from_a_private_seller() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_P2P_class_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("P2P icon displayed");
			actions.moveToElement(validate);
	        actions.sendKeys(Keys.ENTER);
	        actions.build().perform();
	        System.out.println("P2p icon clicked");
		}
		else
			System.out.println("P2P icon is NOT displayed");	
		
	}
	
	@When("^i can select on buying from a private seller$")
	public void i_can_select_on_buying_from_a_private_seller() throws Throwable {
	
	Actions action = new Actions(wdriver);
	WebElement mousehover = wdriver.findElement(By.xpath(BuyingPages_page.buying_P2P_class_xpath));
	action.moveToElement(mousehover).perform();
	Thread.sleep(3000);
	WebElement nxt_btntest = wdriver.findElement(By.xpath(BuyingPages_page.buying_P2P_Nxt_Btn_xpath));
    JavascriptExecutor js = (JavascriptExecutor) wdriver;
	js.executeScript("arguments[0].click()", nxt_btntest);
	System.out.println("Clicked on Next button of dealer is displayed");
	Thread.sleep(1000);
		
	}
	public void i_can_click_on_Next_button_of_private_seller() throws Throwable {
		
WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_P2P_Nxt_Btn_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("Next button of P2P displayed");
			actions.moveToElement(validate);
	        actions.sendKeys(Keys.ENTER);
	        actions.build().perform();
	        System.out.println("Next button of P2P clicked");
		}
		else
			System.out.println("Next button of P2P is NOT displayed");	
	}
}
