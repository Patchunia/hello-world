package main.java.StepDefinition;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class StepByStep_GetInsurance_697 extends CommonSteps {

	@When("^check for Get Insurance icon$")
	public void check_for_Get_Insurance_icon() throws Throwable {
		String find_Vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Get_insurance_link_xpath)).getText();
		
		if (find_Vehicle.contains("Get insurance"))
			System.out.println("Get insurance icon is displayed");
		else
			System.out.println("Get insurance icon is NOT displayed");
	}
	
	@When("^i can click on Get Insurance icon$")
	public void i_can_click_on_Get_Insurance_icon() throws Throwable {
		String find_vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_Get_insurance_link_xpath)).getText();
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_Get_insurance_link_xpath));
		//Actions actions = new Actions(wdriver); 
		if (find_vehicle.contains("Get insurance")) {
			System.out.println("Get insurance icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("Clicked on Get insurance icon");
			Thread.sleep(1000);
		}
		else
			System.out.println("Get insurance icon is NOT displayed");
	}
	
	@When("^check for page contents of Get Insurance icon$")
	public void check_for_page_contents_of_Get_Insurance_icon() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Get insurance"))
			System.out.println("Get insurance page id displayed");
		else
			System.out.println("Get insurance page id NOT displayed");
		
	}
	
	@When("^i can click on Get quote button$")
	public void i_can_click_on_Get_quote_button() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_GetInsurance_GetQuote_Btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Get Quote button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Get Quote button");
		}
		else
			System.out.println("Get Quote button is NOT displayed");
		
	}
	
	@When("^i can click on Nedbank Insurance button$")
	public void i_can_click_on_Nedbank_Insurance_button() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_GetInsurance_NedbankInsurance_Btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Nedbabk insurance button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
		    System.out.println("Clicked on Nedbabk insurance button");
		}
		else
			System.out.println("Nedbabk insurance button is NOT displayed");
		
	}
	
	@When("^check for navigated window$")
	public void check_for_navigated_window() throws Throwable {
		String parentWindow= wdriver.getWindowHandle();
		 for (String Child_Window : wdriver.getWindowHandles()) {  
	     wdriver.switchTo().window(Child_Window); 
	     System.out.println("Current URL= "+ wdriver.getCurrentUrl());
	     
		 }
		 wdriver.switchTo().window(parentWindow);  
		}
}
