package main.java.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class TermsNCondition extends CommonSteps {

	@Given("^I Open MFC Application In Browser and hit login page$")
	public void i_Open_MFC_Application_In_Browser_and_hit_login_page() throws Throwable
	{
		i_Open_MFC_link_in_Browser();
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Login_page.login_Title__xpath));
		if (validate.isDisplayed())
		{
			System.out.println("Log-in page successfully displayed");
			
			
		}
		else
		{
			System.out.println("Log-in page NOT successfully displayed");
		}
	}
	
	
	@When("^I can type SA ID \"([^\"]*)\" and Cellphone number \"([^\"]*)\"$")
	public void i_can_type_SAID_N_CellNumber(String SAid, String mbNumber) throws Throwable {
		System.out.println("Enter SAID");
		wdriver.findElement(By.xpath(Login_page.login_SAID_text_xpath)).sendKeys(SAid);
		System.out.println("Entered SAID");
		
		wdriver.findElement(By.xpath(Login_page.Login_mbNumber_xpath)).sendKeys(mbNumber);
		System.out.println("Entered Cellnumber");
	    scrollToElement("Login_btn_xpath");

	}
	
	
	@When("^I can click on first and second check box$")
	public void i_can_click_on_first_and_second_check_box() throws Throwable {
		click_on_first_and_second_check_box();
		scrollToElement("Login_btn_xpath");
		Thread.sleep(1000);
	    wdriver.findElement(By.xpath(Login_page.Login_btn_xpath)).click();
	    System.out.println("clicked on Next button");
	}
	
	@When("^ApproveIT page displayed and wait till terms and condition page$")
	public void approveit_page_displayed_and_wait_till_terms_and_condition_page() throws Throwable {
		System.out.println("Approve it");
		wdriver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		if (validate.isDisplayed())
			System.out.println("Approveit message displayed");
		
		else
			System.out.println("Approveit message is not displayed");
		
		//Thread.sleep(60000);
	}
	
	@When("^Check for resume application page$")
	public void check_for_resume_application_page() throws Throwable {
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_page));
		if (validate.isDisplayed())
			System.out.println("Resume Application page is displayed");
		
		else
			System.out.println("Resume Application page is NOT displayed");
	}
	
	
	@When("^Check for five items present on resume application page1$")
	public void check_for_five_items_present_on_resume_application_page1() throws Throwable {
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_personalDetails_xpath));
		if (validate.isDisplayed())
			System.out.println("Personal details is displayed on resume application page");
		
		else
			System.out.println("Personal details is displayed on resume application page");
		
		WebElement validate1 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_ResidentialAddress_xpath));
		Thread.sleep(2000);
		if (validate1.isDisplayed())
			System.out.println("Residential Address is displayed on resume application page");
		
		else
			System.out.println("Residential Address is displayed on resume application page");
		
		Thread.sleep(2000);
		WebElement validate2 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_EmploymentDetails_xpath));
		Thread.sleep(2000);
		if (validate2.isDisplayed())
			System.out.println("Employment details is displayed on resume application page");
		
		else
			System.out.println("Employment details is displayed on resume application page");
		Thread.sleep(2000);
		WebElement validate3 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_FinanceAmount_xpath));
		Thread.sleep(2000);
		if (validate3.isDisplayed())
			System.out.println("Finance Amount is displayed on resume application page");
		
		else
			System.out.println("Finance Amount is displayed on resume application page");
		
		WebElement validate4 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_Bankingdetails_xpath));
		Thread.sleep(2000);
		if (validate4.isDisplayed())
			System.out.println("Banking details is displayed on resume application page");
		
		else
			System.out.println("Banking details is displayed on resume application page");
		
	}
	
	@When("^Check for next items$")
	public void check_for_next_items() throws Throwable {
		wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_NextArrow_xpath)).click();
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_PersonalIncome_xpath));
		if (validate.isDisplayed())
			System.out.println("Personal income image is displayed ");
		
		else
			System.out.println("Personal income image is NOT displayed");
		
		wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_NextArrow_xpath)).click();
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_VehicleInstalment_xpath));
		if (validate1.isDisplayed())
			System.out.println("Vehicle instalment image is displayed ");
		
		else
			System.out.println("Personal income image is NOT displayed");
		
		wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_NextArrow_xpath)).click();
		Thread.sleep(1000);
		WebElement validate2 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_YourVehicle_xpath));
		if (validate2.isDisplayed())
			System.out.println("Your vehicle image is displayed ");
		
		else
			System.out.println("Your vehicle image is NOT displayed");
		
		wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_NextArrow_xpath)).click();
		Thread.sleep(1000);
		WebElement validate3 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_PersonalDocuments_xpath));
		if (validate3.isDisplayed())
			System.out.println("Personal documents image is displayed ");
		
		else
			System.out.println("Personal documents image is NOT displayed");
		
		wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_NextArrow_xpath)).click();
		Thread.sleep(1000);
		WebElement validate4 = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_FinancialDocuments_xpath));
		if (validate4.isDisplayed())
			System.out.println("Financial documents image is displayed ");
		
		else
			System.out.println("Financial documents image is NOT displayed");	
		
		
	}

	@When("^Check for Terms and condition page$")
	public void check_for_Terms_and_condition_page() throws Throwable {
	    
		System.out.println("Terms and condition");
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.TermsNCondtion_page_xpath));
		if (validate.isDisplayed())
			System.out.println("Terms and condition page is displayed ");
		
		else
			System.out.println("Terms and condition page is NOT displayed");
		
	   
	}
	


	@When("^I can click on Accept$")
	public void i_can_click_on_Accept() throws Throwable {
		scrollToElement(Login_page.Login_btn_xpath);
		System.out.println("Accepting Terms and condition");
		 wdriver.findElement(By.xpath(Dashboard_Pages.TermsNCondition_accept_xpath)).click();
	    
	}
	
	@When("^I can click on Exit button$")
	public void i_can_click_on_Exit_button() throws Throwable {
		System.out.println("Clicking on Exit button");
		 wdriver.findElement(By.xpath(Dashboard_Pages.TermsNCondition_exit_xpath)).click();
	    }
	@When("^check for Resumepage1$")
	public void check_for_Resumepage1() {
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.ResumeApplication_page));
		if (validate.isDisplayed())
			System.out.println("Resume Application page is displayed");
		
		else
			System.out.println("Resume Application page is NOT displayed");
	}
	

}
