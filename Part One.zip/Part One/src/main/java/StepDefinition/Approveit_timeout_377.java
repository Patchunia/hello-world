package main.java.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Approveit_timeout_377 extends CommonSteps {

	
	@Given("^I Open MFC Application In Browser and hit login page2$")
	public void i_Open_MFC_Application_In_Browser_and_hit_login_page2() throws Throwable
	{
		i_Open_MFC_link_in_Browser();
		Thread.sleep(1000);
	//	validateLoginPage();
	}
	
	@When("^I can type SA ID \"([^\"]*)\" and Cellphone number2 \"([^\"]*)\"$")
	public void i_can_type_SAID_N_CellNumber2(String SAid, String mbNumber) throws Throwable {

		enter_SAID(SAid);
		enter_Cellnumber(mbNumber);
	    scrollToElement("Login_btn_xpath");

	}
	
	@When("^I can click on first and second check box2$")
	public void i_can_click_on_first_and_second_check_box1() throws Throwable {
		if(wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).isSelected())
		{
			System.out.println("Already selected First Check box");
		}
		else {
		wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).click();
		System.out.println("Clicked on First Check box");
		}
		Thread.sleep(1000);
		if(wdriver.findElement(By.xpath(Login_page.Login_CheckBox2_xpath)).isSelected())
		{
			System.out.println("Already selected First Check box");
		}
		else {
		wdriver.findElement(By.xpath(Login_page.Login_CheckBox2_xpath)).click();
		System.out.println("Clicked on Second Check box");
		}
	}
	

	@When("^I can click on Next button$")
	public void i_can_click_on_Next_button() throws Throwable {
		next_btn_click();
	}
	
	@When("^wait till reject page displayed$")
	public void wait_till_reject_page_displayed() throws Throwable
	{
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		if (validate.isDisplayed())
			System.out.println("Approveit message displayed");
		
		else
			System.out.println("Approveit message is not displayed");
		Thread.sleep(60000);

	}
	
	@When("^i can click on Cancel$")
	public void i_can_click_on_Cancel() throws Throwable
	{
		Thread.sleep(1000);
		wdriver.findElement(By.xpath(Dashboard_Pages.ApproveIt_close_btn_xpath)).click();
		System.out.println("clicked on Cancel button of Timeout page");
	}
	
	@When("^i can click on Resend$")
	public void i_can_click_on_Resend() throws Throwable{
		Thread.sleep(2000);
		resend_btn_click();
		
	}
	
	public void resend_btn_click() {
		
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_timeout_resend_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Resend button displayed");
			wdriver.findElement(By.xpath(Dashboard_Pages.Approveit_timeout_resend_btn_xpath)).click();
		}
		else
			System.out.println("Resend button is NOT displayed");
	}
	
	
	@When("^check for approveit page$")
	public void check_for_approveit_page() throws Throwable{
		Thread.sleep(2000);
		approveit_page();
		System.out.println("Approveit message is not displayed after resend button click");
	}

	@When("^ApproveIT page displayed with timeout message$")
	public void approveIT_page_displayed_with_timeout_message() throws Throwable
	{
		Thread.sleep(1000);
		WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		if (validate.isDisplayed())
			System.out.println("Approveit message displayed");
		
		else
			System.out.println("Approveit message is not displayed");
		String timeout_msg = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		if (timeout_msg.contains("The Approve-it� message timed out")) 
			System.out.println("Approveit Timeout page displayed");
		else
			System.out.println("Approveit Timeout page is NOT displayed");
		}
		
		
	
}
