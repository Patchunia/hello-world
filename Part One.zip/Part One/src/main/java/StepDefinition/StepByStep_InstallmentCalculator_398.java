package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.StepByStep_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepByStep_InstallmentCalculator_398 extends CommonSteps{

	@When("^I can enter purchase price amount \"([^\"]*)\"$")
	public void i_can_enter_purchase_price_amount(String purchaseprice) throws Throwable {
		WebElement pp = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_purchasePrice_xpath));
		Thread.sleep(1000);
	    if(pp.isDisplayed()) {
	    	System.out.println("purchase price field is displayed");
	    	pp.sendKeys(purchaseprice);
		    System.out.println("Value entered in purchase price field");
	    }
	    else
	    	System.out.println("Purchase price field is NOT displayed");
	    	pp.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);		
	}
	
	@When("^check error message of Purchase Price$")
	public void check_error_message_of_Purchase_Price() throws Throwable {
		
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_purchasePrice_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for Purchase Price field is displayed");
		    else
		    	System.out.println("Error message for Purchase Price field is NOT displayed");
	}
	
	@When("^check for default selection of deposit toggle of Instalment Calculator$")
	public void check_for_default_selection_of_deposit_toggle_of_Instalment_Calculator() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_deposit_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of deposit is selected");
		else
			System.out.println("No Toggle of deposit is NOT selected");
	}
	
	@When("^i can click on Yes button of deposit of Instalment Calculator$")
	public void i_can_click_on_Yes_button_of_deposit_of_Instalment_Calculator() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_deposit_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of deposit is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", yesToggle);
		}
		else
			System.out.println("Yes Toggle of deposit is NOT selected");
	}
	
	@When("^check deposit amount is displayed$")
	public void check_deposit_amount_is_displayed() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_deposit_amount_xpath));
		if(amount.isDisplayed()) {
			System.out.println("Amount of deposit is selected");
		}
		else
			System.out.println("Amount of deposit is NOT selected");
	}
	
	@When("^i can enter value in deposit Amount field \"([^\"]*)\"$")
	public void i_can_enter_value_in_deposit_Amount_field(String amount) throws Throwable {
		WebElement depositAmount = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_deposit_amount_xpath));
		Thread.sleep(1000);
	    if(depositAmount.isDisplayed()) {
	    	System.out.println("deposit amount field is displayed");
	    	depositAmount.sendKeys(amount);
		    System.out.println("Value entered in deposit amount field");
	    }
	    else
	    	System.out.println("deposit amount field is NOT displayed");
	    depositAmount.sendKeys(Keys.TAB);
	    	Thread.sleep(1000);		
	}
	
	@When("^check error message of deposit amount$")
	public void check_error_message_of_deposit_amount() throws Throwable {
		
		 String err = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_purchasePrice_Err_xpath)).getText();
		    if(err.equalsIgnoreCase("Please enter valid numbers only.")) 
		    	System.out.println("Error message for deposit amount field is displayed");
		    else
		    	System.out.println("Error message for deposit amount field is NOT displayed");
	}
	
	@When("^Check for default selection value of balloon toggle of Instalment Calculator$")
	public void Check_for_default_selection_value_of_balloon_toggle_of_Instalment_Calculator() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_balloon_NoToggle_xpath));
		if(noToggle.isDisplayed())
			System.out.println("No Toggle of balloon is selected");
		else
			System.out.println("No Toggle of balloon is NOT selected");
	}
	
	@When("^i can click on Yes toggle button of balloon$")
	public void i_can_click_on_Yes_toggle_button_of_balloon() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_balloon_YesToggle_xpath));
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes Toggle of balloon is selected");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", yesToggle);
		    Thread.sleep(2000);
		}
		else
			System.out.println("Yes Toggle of balloon is NOT selected");
		Thread.sleep(1000);
		scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
	}
	
	@When("^i can check calculated loan Amount \"([^\"]*)\"$")
	public void i_can_check_calculated_loan_Amount(String amount) throws Throwable {
		String loanAmount = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_LoanAmount_xpath)).getText();
		Thread.sleep(1000);
	    if(loanAmount.equals(amount)) 
	    	System.out.println("Calculated Loan amount is correct");
	    else
	    	System.out.println("Calculated Loan amount is incorrect");
	    Thread.sleep(1000);		
	}
	
	
	@When("^check Percentage field is displayed or not$")
	public void check_Percentage_field_is_displayed_or_not() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_percentage_label_xpath));
		if (validate.isDisplayed())
			System.out.println("Percentage field is displayed");
		else
			System.out.println("Percentage field is not displayed");
		Thread.sleep(1000);
		}
	
	@When("^select percentage to slide next step of Instalment Calculator$")
	public void select_percentage_to_slide_next_step_of_Instalment_Calculator() throws Throwable {
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_percentage_slider_xpath));
		scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
		int width=validate1.getSize().getWidth();
		Actions actions = new Actions(wdriver);
		actions.dragAndDropBy(validate1, ((width*25)/100), 0).click().build().perform();
		Thread.sleep(2000);
		System.out.println("shifted to next step");
		scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
		Thread.sleep(1000);
	}
	
	@When("^I can select date for Instlment to begin in Instalment Calculator$")
	public void i_can_select_date_for_Instlment_to_begin_in_Instalment_Calculator() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_datepicker_xpath));
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
			cal.add(Calendar.DATE, 3);
			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(after);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			System.out.println("Date after 3 days is selected");
			
		}
		else 
			System.out.println("Date after 3 days is NOT selected");
		
	}
	
	@When("^I can select date for Instlment to begin for more than sixty$")
	public void i_can_select_date_for_Instlment_to_begin_for_more_than_sixty() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_datepicker_xpath));
		WebElement nextMonth = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_datepicker_nextMonth_xpath));
		WebElement nextMonth1 = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_datepicker_nextMonth_xpath));
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			nextMonth.click();
			nextMonth1.click();
			scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
			cal.add(Calendar.DATE, 63);
			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(after);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
			//scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			Thread.sleep(2000);
			//wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
//			if (wdriver.findElement(By.xpath(statement)).isDisplayed())
//				System.out.println("Date is not enabled to select. Test case Passed");
//			else
//				System.out.println("Date is enabled to select. Test case Failed");
//			Thread.sleep(5000);
//			System.out.println("Date after 60 days is selected");
			
//			WebDriverWait wait = new WebDriverWait(wdriver, 10);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(statement)));
			
			try{
	            WebDriverWait wait = new WebDriverWait(wdriver, 6);
	            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(statement)));
	            System.out.println("Date is not enabled to select. Test case Passed");
	        }
	        catch (Exception e){
	        	System.out.println("Date is enabled to select. Test case Failed");
	        }

			Thread.sleep(2000);
			
		}
		else 
			System.out.println("Date after 60 days is NOT selected");
		
	}
	
	@When("^check paying vehicle field is displayed or not$")
	public void check_paying_vehicle_field_is_displayed_or_not() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath));
		if (validate.isDisplayed())
			System.out.println("Paying vehicle field is displayed");
		else
			System.out.println("Paying vehicle field is not displayed");
		Thread.sleep(1000);
		}
	
	@When("^select paying vehicle to slide next step of Instalment Calculator$")
	public void select_paying_vehicle_to_slide_next_step_of_Instalment_Calculator() throws Throwable {
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_payingVehicle_slider_xpath));
		scrollToElement(StepByStep_pages.Step_InstalmentCal_monthlyExpenses_xpath);
		int width=validate1.getSize().getWidth();
		Actions actions = new Actions(wdriver);
		actions.dragAndDropBy(validate1, ((width*25)/100), 0).click().build().perform();
		Thread.sleep(2000);
		System.out.println("shifted to next step");
		scrollToElement(StepByStep_pages.Step_InstalmentCal_monthlyExpenses_xpath);
		Thread.sleep(1000);
	}
	
	@Then("^check monthly instalment calculated correct value or not in Instalment Calculator \"([^\"]*)\"$")
	public void check_monthly_instalment_calculated_correct_value_or_not_in_Instalment_Calculator(String monthExp) throws Throwable {
		String monthlyExpenses = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_monthlyExpenses_xpath)).getText();
		  if (monthlyExpenses.equals(monthExp))
			  System.out.println("It is calculated correct monthly expense" + monthlyExpenses);
		  else
			  System.out.println("It is calculated incorrect monthly expenses");	  
	}
}
