package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import main.java.Pages.BuyingPages_page;
import cucumber.api.java.en.When;

public class DealershipViewDetails_401 extends CommonSteps {

	Actions actions = new Actions(wdriver);
	@When("^check for View details link$")
	public void check_for_View_details_link() throws Throwable {
		
		//Buying option page check
		String title= wdriver.findElement(By.xpath(BuyingPages_page.buying_page_title_xpath)).getText();
		if (title.contains("Whom are you buying from?")) {
			System.out.println("Buying option page displayed");
		}
		else
			System.out.println("Buying option page is NOT displayed");	
		
		// click on Dealership icon to check View details page
		WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_class_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("Dealer icon displayed");
			actions.moveToElement(validate);
	        actions.sendKeys(Keys.ENTER);
	        actions.build().perform();
	        System.out.println("Dealer icon clicked");
		}
		else
			System.out.println("Dealer icon is NOT displayed");	
		
		//Check View details button is displayed or not
		WebElement viewDetails = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_ViewDetails_Btn_xpath));
		
		if (viewDetails.isDisplayed())
			System.out.println("View details link of dealer ship is displayed ");
		else
			System.out.println("View details link of dealer ship is NOT displayed ");
	}
	
	@When("^i can click on view details button of dealer$")
	public void i_can_click_on_view_details_button_of_dealer() throws Throwable {
		//Check View details button is displayed or not
				WebElement viewDetails = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_ViewDetails_Btn_xpath));
				
				if (viewDetails.isDisplayed()) {
					System.out.println("View details link of dealer ship is displayed ");
					actions.moveToElement(viewDetails).click();
					actions.build().perform();
					System.out.println("Clicked on View details link of dealer ship");
				}
				else
					System.out.println("View details link of dealer ship is NOT displayed ");
			
			}
	
	@When("^check for view details page of dealership$")
	public void check_for_view_details_page_of_dealership() throws Throwable {
		String title = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_viewdetails_title_xpath)).getText();
		
		if (title.contains("Buying from a dealership"))
			System.out.println("View details page of dealership is displayed");
		else 
			System.out.println("View details page of dealership is NOT displayed");		
		
	}
	
	@When("^i can click on Start application and check for personal details page$")
	public void i_can_click_on_Start_application_and_check_for_personal_details_page() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_viewDetails_startAppl_xpath));
		
		if (validate.isDisplayed()) {
			System.out.println("Start application button of View details page of dealership is displayed");
			actions.moveToElement(validate).click();
			actions.build().perform();
		}
		else 
			System.out.println("View details page of dealership is NOT displayed");		
		
	}
	
	@When("^i can click on back button of dealership$")
	public void i_can_click_on_back_button_of_dealership() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_viewDetails_BackBtn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Back button of View details page of dealership is displayed");
			actions.moveToElement(validate).click();
			actions.build().perform();
			System.out.println("Clicked on Back button of View details page of dealership");
		}
		else 
			System.out.println("back button of dealership is NOT displayed");	
	}
	
}
