package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.P2P_pages;
import main.java.Pages.StepByStep_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class P2P_485_VehicleInfo_SellerDetails extends CommonSteps {

	@When("^Fill form of Vehicle Instalment of P2P and click on Next button \"([^\"]*)\"$")
	public void Fill_form_of_Vehicle_Instalment_of_P2P_and_click_on_Next_button(String Pprice) throws Throwable {
		//Purchase price
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_xpath)));
		WebElement price = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
		price.sendKeys(Pprice);
//	    js.executeScript("arguments[0].value="+Pprice+";", price);
			System.out.println("Purchase price entered");
			Thread.sleep(2000);
			
		//Yes toggle button of balloon
			WebElement yesToggle = wdriver.findElement(By.xpath(StepByStep_pages.Step_InstalmentCal_balloon_YesToggle_xpath));
			if(yesToggle.isDisplayed()) {
				System.out.println("Yes Toggle of balloon is selected");
				js.executeScript("arguments[0].click();", yesToggle);
			    Thread.sleep(2000);
			}
			else
				System.out.println("Yes Toggle of balloon is NOT selected");
			Thread.sleep(1000);
			scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
			Thread.sleep(1000);
		//Percentage slider
			
			Thread.sleep(2000);
			WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_balloon_percentage_slider_xpath));
			scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
			int width=validate1.getSize().getWidth();
			Actions actions = new Actions(wdriver);
			actions.dragAndDropBy(validate1, ((width*25)/100), 0).click().build().perform();
			Thread.sleep(2000);
			System.out.println("shifted to next step");
			//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
			Thread.sleep(1000);
		//Date select
			
			WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_xpath));
			if (validate.isDisplayed()) {
				//JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", validate);
				System.out.println("clicked on Date picker");
				Thread.sleep(1000);
				scrollToElement(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath);

				Date date1 = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				
				//cal.add(Calendar.DAY_OF_YEAR, 3);
				cal.add(Calendar.DATE, 3);
				Date after = cal.getTime();
				
				
				SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
				String str = df.format(after);

				System.out.println("the date today is " + str);
				System.out.println("the date today is " + str.substring(0,2));
				//validate.sendKeys(str);
				String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
				scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
				wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
				System.out.println("Date after 3 days is selected");
				
			}
			else 
				System.out.println("Date after 3 days is NOT selected");
			scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
			
			//Paying vehicle slider
			
			Thread.sleep(2000);
			WebElement slider = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath));
			scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
			int width1=slider.getSize().getWidth();
			Actions action = new Actions(wdriver);
			action.dragAndDropBy(slider, ((width1*25)/100), 0).click().build().perform();
			Thread.sleep(2000);
			System.out.println("shifted to next step");
			//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
			Thread.sleep(2000);
		//monthly expense check
			String monthlyExpenses = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_monthlyExpense_xpath)).getAttribute("value");
			  if (monthlyExpenses.isEmpty())
				  System.out.println("It is calculated incorrect monthly expense" + monthlyExpenses);
			  else
				  System.out.println("It is calculated incorrect monthly expenses");	  
		//Next click
			 
			  WebElement validate11 = wdriver.findElement(By.xpath(P2P_pages.P2P_VehicleInstalment_Nxt_btn_xpath));
				if (validate11.isDisplayed()) {
					System.out.println("Next button is displayed");
//				    js.executeScript("arguments[0].click();", validate11);
					action.moveToElement(validate11).click().build().perform();
					System.out.println("Next button is clicked");
				}
				else
					System.out.println("Next button is NOT displayed");
				Thread.sleep(3000);
	}
	
	@When("^Check page contents of Seller details$")
	public void check_page_contents_of_Seller_details() throws Throwable {
	    String msg = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_page_xpath)).getText();
	    if(msg.contains("Seller details")) 
	    	System.out.println("Seller details of P2P is displayed");
	    else
	    	System.out.println("Seller details of P2P is NOT displayed");
	}
	
	@When("^i can click on Next button of seller details$")
	public void i_can_click_on_Next_button_of_seller_details() throws Throwable {
		
		scrollToElement(VehicleInfo_page.vehicleInfoInstalment_P2P_SellerDetails_next_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_Nxt_btn_xpath));
		if(validate.isDisplayed()) {
			System.out.println("Next button of Seller is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
		    System.out.println("Next button of Vehicle Seller is clicked");
		}
		else
			System.out.println("Next button of Seller is NOT displayed");
		Thread.sleep(3000);
	}
	
	@When("^i can enter first name in seller details \"([^\"]*)\"$")
	public void i_can_enter_first_name_in_seller_details(String fname) throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(P2P_pages.P2P_SellerDetails_fName_xpath)));
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_fName_xpath));
		if (validate.isDisplayed()) {
			System.out.println("First name field is displayed");
			validate.sendKeys(fname);
			System.out.println("First name entered");
		}
		else
			System.out.println("First name field is NOT displayed");
		Thread.sleep(2000);
	}
	
	@When("^i can enter Surname in seller details \"([^\"]*)\"$")
	public void i_can_enter_Surname_in_seller_details(String surname) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_sName_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Surname field is displayed");
			validate.sendKeys(surname);
			System.out.println("Surname entered");
		}
		else
			System.out.println("Surname field is NOT displayed");
	
		Thread.sleep(2000);
	}
	
	@When("^i can enter cellphone in seller details \"([^\"]*)\"$")
	public void i_can_enter_cellphone_in_seller_details(String cellNum) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_CellNo_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Cellphone number field is displayed");
			validate.sendKeys(cellNum);
			System.out.println("Cellphone number entered");
		}
		else
			System.out.println("Cellphone number field is NOT displayed");
		Thread.sleep(2000);
	}
	
	@When("^i can enter email in seller details \"([^\"]*)\"$")
	public void i_can_enter_email_in_seller_details(String email) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.P2P_SellerDetails_email_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Email field is displayed");
			validate.sendKeys(email);
			System.out.println("Email entered");
		}
		else
			System.out.println("Email field is NOT displayed");
		Thread.sleep(2000);
	}
	@When("^i can check reference number is generated or not$")
	public void i_can_check_reference_number_is_generated_or_not() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_ApplicationState_ReferenceNo_xpath)));

		String ref = wdriver.findElement(By.xpath(Dealer_pages.dealer_ApplicationState_ReferenceNo_xpath)).getText();
		System.out.println(ref);
		String refNo= ref.substring(5, 14);
		System.out.println(refNo);
		if (refNo.isEmpty())
			System.out.println("Reference Number is NOT generated");
		else
			System.out.println("Reference Number is generated");
		
	}
	
	
}
