package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.P2P_pages;
import main.java.Pages.StepByStep_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class Dealer_ResidentialAddr_424 extends CommonSteps{

	@When("^Fill form of personal information page and click on Next button \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void fill_form_of_personal_information_page_and_click_on_Next_button(String fname, String surname, String phNumber, String email, String country) throws Throwable {

		//Select Title
		WebElement title = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_title_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", title);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_title_option_xpath));
		js.executeScript("arguments[0].click()", option);
		System.out.println("Title selected");
		Thread.sleep(1000);
		
		//First Name
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_FirstName_xpath));
		if (validate.isDisplayed()) {
			System.out.println("First Name field displayed");
			validate.sendKeys(fname);
		    Thread.sleep(1000);
		    System.out.println("First Name entered");
		}
		else
			System.out.println("First Name field is NOT displayed");
		
		//Surname
		WebElement validate1 = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_surname_xpath));
		if (validate1.isDisplayed()) {
			System.out.println("Surname field displayed");
			validate1.sendKeys(surname);
		}
		else
			System.out.println("Surname field is NOT displayed");
		Actions action = new Actions(wdriver);
		//Select marital status
		Thread.sleep(2000);
		WebElement marrital = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_maritalStatus_xpath));
		js.executeScript("arguments[0].click();", marrital);
	    Thread.sleep(2000);
	    
		WebElement option1 = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_MaritalStatus_option_xpath));
		action.moveToElement(option1).sendKeys(Keys.ARROW_DOWN);
		action.build().perform();
		action.click();
		js.executeScript("arguments[0].click();", option1);
		System.out.println("Marital status selected");
		Thread.sleep(1000);
		Thread.sleep(1000);
		
		//Work number
		
		WebElement validate2 = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_xpath));
		if(validate2.isDisplayed()) {
			wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_xpath)).sendKeys(phNumber);
			System.out.println("Work Telephone number entered");
			}
		else 
			System.out.println("Work Telephone number field not present");
		
		//Email
		
		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement validate3 = wdriver.findElement(By.id(P2P_pages.PersonalDetails_email_id));
		if(validate3.isDisplayed()) {
			wdriver.findElement(By.id(P2P_pages.PersonalDetails_email_id)).sendKeys(email);
			System.out.println("Email entered");
			}
		else 
			System.out.println("Email field is blank");
		validate.sendKeys(Keys.TAB);
		
		///Country
		
		System.out.println("Born country field");
		WebElement validate4 = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_xpath));
		Thread.sleep(2000);		
		if(validate4.isDisplayed()) {
			System.out.println("Born country field is displayed");
			Thread.sleep(1000);
			validate4.sendKeys(country);
			Thread.sleep(2000);
			System.out.println("Born country entered");
		}
		else
			System.out.println("Born country field is NOT displayed");
		Thread.sleep(3000);
	
	if( wdriver.findElements(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath)).size()> 0) {
		WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath));
		if(item.isDisplayed()) {
			System.out.println("abled to search item");
		//	JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", item);
			System.out.println("item selected");
		}
		else
			System.out.println("item not found");
	}
//	else {
//		String item1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_blankErr_xpath)).getText();
//		if(item1.contains("No records found")) {
//			System.out.println("Search result is not found");
//			
//		}
//		else
//			System.out.println("Search result is found");
	else
	System.out.println("Search result is found");
//	}
		Thread.sleep(5000);
		//Ethnic group

		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement ethnicGroup = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_EthnicGroup_xpath));
		action.moveToElement(ethnicGroup).click().build().perform();

	    //js.executeScript("arguments[0].click()", ethnicGroup);
	    Thread.sleep(2000);
	    scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement option2 = wdriver.findElement(By.xpath("//*[@id='ethnicGroupDropdown']/div/div/div[2]/label"));
		//js.executeScript("arguments[0].click()", option2);
		Thread.sleep(2000);
		 //js.executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight));");
		
		js.executeScript("arguments[0].click();", option2);
		
		System.out.println("Title selected");
		Thread.sleep(2000);
		
		System.out.println("Ethnic group selected");
		Thread.sleep(2000);
		
		//Next button click
		WebElement validate5 = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_nxt_btn_xpath));
		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		if (validate5.isDisplayed()) {
			System.out.println("Next button of Personal info is displayed");
			//JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate5);
			System.out.println("Next button of Personal info clicked");
			Thread.sleep(2000);
		}
		else
			System.out.println("Next button of Personal info is NOT displayed");
		Thread.sleep(2000);
	}
	
	@When("^check for Residential Address page contents on screen$")
	public void check_for_Residential_Address_page_contents_on_screen() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residentialPageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_residentialPageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("Your address"))
				System.out.println("Residential Address page is displayed");
		}
		else
			System.out.println("Residential Address page is NOT displayed");
			
	}
	
	@When("^click on next button of Residential address page$")
	public void click_on_next_button_of_Residential_address_page() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_next_btn_xpath)));
		WebElement element = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_next_btn_xpath));	
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", element);
		//scrollToElement("Login_btn_xpath");
	}
	
	@When("^check blank error message of physical address$")
	public void check_blank_error_message_of_physical_address() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress_Blank_err_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for physical address");
		}
		else
			System.out.println("Blank error message is NOT displayed for physical address");
	}
	
	@When("^i can enter physical address of residential address \"([^\"]*)\"$")
	public void i_can_enter_physical_address_of_residential_address(String addr) throws Throwable {
		Thread.sleep(2000);
		Actions action = new Actions(wdriver);
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_physicalAddress_xpath)));
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress_xpath));
		
		action.moveToElement(validate1);
		action.click();
		action.sendKeys(addr).build().perform();
			System.out.println("Physical Address is entered");
				
	}
	
	@When("^i can enter physical address Line two of residential address \"([^\"]*)\"$")
	public void i_can_enter_physical_address_Line_two_of_residential_address(String addrLine2) throws Throwable {
		
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_physicalAddress2_xpath)));
	
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress2_xpath));
		Thread.sleep(1000);
		Actions action = new Actions(wdriver);
		action.moveToElement(validate).click();
		action.sendKeys(addrLine2).build().perform();
			System.out.println("Physical Address Line 2 is entered");
				
	}
	
	@When("^check error message of physical address for max chars$")
	public void check_error_message_of_physical_address_for_max_chars() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_physicalAddress_Max_err_xpath)));
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress_Max_err_xpath)).getText();
		if (err.contains("Maximum 50 characters allowed.")) {
			System.out.println("Max chars error message is displayed for physical address");
		}
		else
			System.out.println("Max chars error message is NOT displayed for physical address");
	}
	
	@When("^check validation message of physical address for Special characters$")
	public void check_validation_message_of_physical_address_for_Special_characters() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_physicalAddress_Blank_err_xpath)).getText();
		if (err.contains("Please enter only characters.")) {
			System.out.println("Special chars error message is displayed for physical address");
		}
		else
			System.out.println("Special chars error message is NOT displayed for physical address");
	}
	
	@When("^check blank error message of Residential status$")
	public void check_blank_error_message_of_Residential_status() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_residentialStatus_BlankErr_xpath)).getText();
		if (err.contains("Please select residential status")) {
			System.out.println("Blank error message is displayed for Residential Status");
		}
		else
			System.out.println("Blank error message is NOT displayed for residential status");
	}
	
	@When("^i can enter and select physical suburb \"([^\"]*)\"$")
	public void i_can_enter_and_select_physical_suburb(String suburb) throws Throwable {
		scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
		System.out.println("Additional Born country field");
		//scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_xpath));
		Actions action = new Actions(wdriver); 
		if(validate1.isDisplayed()) {
			System.out.println("Physical Suburb field is displayed");
			Thread.sleep(1000);
			validate1.sendKeys(Keys.TAB);
			action.moveToElement(validate1).sendKeys(suburb).build().perform();
			System.out.println("Physical Suburb is enterred");
		}
		else
			System.out.println("Physical Suburb is NOT displayed");
		
		
		int size =  wdriver.findElements(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_selItem_xpath)).size();
		
		Thread.sleep(5000);
		if(size>0) {
			WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Physicalsuburb_selItem_xpath));
			if(item.isDisplayed()) {
				System.out.println("abled to search item");
				
				JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click()", item);
				System.out.println("item selected");
			}
			else
				System.out.println("item not found");
		}
//		else {
//			String item1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_invalid_Err_xpath)).getText();
//			if(item1.contains("No records found")) {
//				System.out.println("Search result of suburb is not found");
//				
//			}
//	
			else
				System.out.println("Search result of physical suburb is found");
//		}
			Thread.sleep(5000);
			
		
	}
	
	@When("^check Physical city and postal code is populated$")
	public void check_Physical_city_and_postal_code_is_populated() throws Throwable {
		String city = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_PhysicalCity_xpath)).getAttribute("value");
		String postalCode= wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_PhysicalPostalCode_xpath)).getAttribute("value");
		if(city.isEmpty())
			System.out.println("Physical City is not autopopulated");
		else
			System.out.println("Physical City is autopopulated");		
		
		if(postalCode.isEmpty())
			System.out.println("Physical Postal code is not autopopulated");
		else
			System.out.println("Physical Postal code is autopopulated");
	}
	
	@When("^i can select Residential status$")
	public void i_can_select_Residential_status() throws Throwable {
		scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_residentialStatus_xpath)));

		WebElement status = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_residentialStatus_xpath));

		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", status);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_residentialStatus_SelItem_xpath));
		js.executeScript("arguments[0].click()", option);
		Thread.sleep(1000);
		System.out.println("Residential status selected");
		Thread.sleep(1000);
	}
	
	@When("^check blank error message of when move here field$")
	public void check_blank_error_message_of_when_move_here_field() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_DatePicker_moveHere_blankErr_xpath)).getText();
		if (err.contains("Please select valid date")) {
			System.out.println("Blank error message is displayed for Move here date");
		}
		else
			System.out.println("Blank error message is NOT displayed for Move here date");
	}
	
	
	@When("^i can select date from calendar for move here field$")
	public void i_can_select_date_from_calendar_for_move_here_field() throws Throwable {
		scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_DatePicker_moveHere_xpath));
		Thread.sleep(2000);
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(3000);
			scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
//			cal.add(Calendar.DATE, -3);
//			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(date1);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month dp-current-day'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			System.out.println("Date before 3 days is selected");
			
		}
		else 
			System.out.println("Date before 3 days is NOT selected");
		
	}
	@When("check receive mail for default selection$")
	public void check_receive_mail_for_default_selection() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Mail_yesToggle_xpath));
		if (yesToggle.isDisplayed())
			System.out.println("By default Yes toggle button selected");
		else 
			System.out.println("By default No toggle button selected");
	}
	
	@When("^i can click on No toggle button of receieve mail$")
	public void i_can_click_on_No_toggle_button_of_receieve_mail() throws Throwable {
		
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_Mail_noToggle_xpath)));

		WebElement noToggle = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_Mail_noToggle_xpath));
		
		if(noToggle.isDisplayed()) {
			System.out.println("Yes toggle button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", noToggle);
			 System.out.println("clicked on no toggle button ");
		}
		else
			System.out.println("No toggle button cannot be selected");
		scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
	}
	
	@When("check for address fields are displayed$")
	public void check_for_address_fields_are_displayed() throws Throwable {
		WebElement postalAddr1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress1_xpath));
		WebElement postalAddr2 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress2_xpath));
		WebElement city = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_city_xpath));
		WebElement suburb = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_xpath));
		WebElement postalCode = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalcode_xpath));
		
		if(postalAddr1.isDisplayed())
			System.out.println("Postal address1 field is displayed");
		else 
			System.out.println("Postal address1 field is NOT displayed");
		if (postalAddr2.isDisplayed())
			System.out.println("Postal address2 field is displayed");
		else 
			System.out.println("Postal address2 field is NOT displayed");
		if (city.isDisplayed())
			System.out.println("city field is displayed");
		else
			System.out.println("City field is NOT displayed");
		if (suburb.isDisplayed())
			System.out.println("Suburb field is displayed");
		else
			System.out.println("Suburb field is NOT displayed");
		if(postalCode.isDisplayed())
			System.out.println("Postal code field is displayed");
		else
			System.out.println("Postal code field is NOT displayed");
			
	}
	
	@When("^check for blank error message of Postal address line one$")
	public void check_for_blank_error_message_of_Postal_address_line_one() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_postalAddress1_Blank_err_xpath)));

		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress1_Blank_err_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for postal line1");
		}
		else
			System.out.println("Blank error message is NOT displayed for postal line1");
	}
	
	@When("^check error message of postal address line one for Special characters$")
	public void check_error_message_of_postal_address_line_one_for_Special_characters() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress1_Blank_err_xpath)).getText();
		if (err.contains("please enter only characters.")) {
			System.out.println("Special characters error message is displayed for postal line1");
		}
		else
			System.out.println("Special characters error message is NOT displayed for postal line1");
	}
	
	@When("^check blank error message of Suburb$")
	public void check_blank_error_message_of_Suburb() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_Blank_Err_xpath)).getText();
		if (err.contains("Please select suburb")) {
			System.out.println("Blank error message is displayed for suburb");
		}
		else
			System.out.println("Blank error message is NOT displayed for suburb");
	}

	
	@When("check for Postal address line one field is displayed$")
	public void check_for_Postal_address_line_one_field_is_displayed() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_postalAddress1_xpath)));

		WebElement postalAddr1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress1_xpath));
		if(postalAddr1.isDisplayed())
			System.out.println("Postal address1 field is displayed");
		else 
			System.out.println("Postal address1 field is NOT displayed");
		
	}

	@When("^i can enter postal address line one \"([^\"]*)\"$")
	public void i_can_enter_postal_address_line_one(String addr) throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_postalAddress1_xpath)));

		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress1_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(addr);
			System.out.println("Postal Address1 is entered");
		}
		else
			System.out.println("Postal Address1 is not display");		
	}
	
	@When("^i can enter postal address two \"([^\"]*)\"$")
	public void i_can_enter_postal_address_two(String addr) throws Throwable {

		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_residential_postalAddress2_xpath)));

		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalAddress2_xpath));
		if(validate.isDisplayed()) {
			validate.sendKeys(addr);
			System.out.println("Postal Address2 is entered");
		}
		else
			System.out.println("Postal Address2 is not display");
		scrollToElement(Dealer_pages.dealer_residential_next_btn_xpath);
	}
	
	@When("^i can select Suburb \"([^\"]*)\"$")
	public void i_can_select_Suburb(String suburb) throws Throwable {
		System.out.println("Additional Born country field");
		//scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_xpath));
		Actions action = new Actions(wdriver); 
		if(validate1.isDisplayed()) {
			System.out.println("Suburb field is displayed");
			Thread.sleep(1000);
			validate1.sendKeys(Keys.TAB);
			action.moveToElement(validate1).sendKeys(suburb).build().perform();
			System.out.println("Suburb is enterred");
		}
		else
			System.out.println("Suburb is NOT displayed");
		
		
		int size =  wdriver.findElements(By.xpath(Dealer_pages.dealer_residential_suburb_AllItem_xpath)).size();
		
		Thread.sleep(5000);
		if(size>0) {
			WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_AllItem_xpath));
			if(item.isDisplayed()) {
				System.out.println("abled to search item");
				
				JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click()", item);
				System.out.println("item selected");
			}
			else
				System.out.println("item not found");
		}
//		else {
//			String item1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_suburb_invalid_Err_xpath)).getText();
//			if(item1.contains("No records found")) {
//				System.out.println("Search result of suburb is not found");
//				
//			}
//	
			else
				System.out.println("Search result of suburb is found");
//		}
			Thread.sleep(5000);
			
		
	}
	
	@When("^Check for city and Postal code is auto populated$")
	public void check_for_city_and_Postal_code_is_auto_populated() throws Throwable {
		String city = wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_city_xpath)).getText();
		String postalCode= wdriver.findElement(By.xpath(Dealer_pages.dealer_residential_postalcode_xpath)).getText();
		if(city.equals(""))
			System.out.println("City is not autopopulated");
		else
			System.out.println("City is autopopulated");		
		
		if(postalCode.equals(""))
			System.out.println("Postal code is not autopopulated");
		else
			System.out.println("Postal code is autopopulated");
	}
}
