package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import main.java.Pages.Dashboard_V1;
import cucumber.api.java.en.When;

public class AcceptConsent_582 extends CommonSteps{

	@When("^Check for your consent page contents$")
	public void check_for_your_consent_page_contents() throws Throwable {
		String title = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_YourConsent_page_xpath)).getText();
		if(title.contains("Your consent"))
			System.out.println("Your consent page is displayed");
		else
			System.out.println("Your consent page is NOT displayed");
	}
	
	@When("^check for default value of all radio buttons$")
	public void check_for_default_value_of_all_radio_buttons() throws Throwable {
		WebElement toggle1 = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_No_btn1_xpath));
		WebElement toggle2 = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_No_btn2_xpath));
		WebElement toggle3 = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_No_btn3_xpath));
		
		if(toggle1.isEnabled())
			System.out.println("First toggle button is enabled");
		if(toggle2.isEnabled())
			System.out.println("Second toggle button is enabled");
		if(toggle3.isEnabled())
			System.out.println("Third toggle button is enabled");
	}
	
	@When("^check start application is enabled or not$")
	public void check_start_application_is_enabled_or_not() throws Throwable {
		WebElement app_btn = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_YourConsent_StartApp_Btn_xpath));
		
		if(!app_btn.isEnabled())
			System.out.println("Start application button is disabled");
		else
			System.out.println("Start application button is NOT disabled");
	}
	
	Actions actions = new Actions(wdriver);
	@When("^i can click on Yes toggle button of first button$")
	public void i_can_click_on_Yes_toggle_button_of_first_button() throws Throwable {
		
		WebElement app_btn = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_Yes_btn1_xpath));
		
		if(app_btn.isDisplayed()) {
			Thread.sleep(1000);
			System.out.println("First Yes toggle button is displayed");
			//app_btn.sendKeys(Keys.ENTER);	
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", app_btn);

//			 actions.moveToElement(app_btn);
//			        // actions.click();
//			       actions.sendKeys(Keys.ENTER);
//			         actions.build().perform();
			         System.out.println("Clicked on First Yes toggle button");

		}
		else
			System.out.println("First Yes toggle button is NOT displayed");
	}
	
	@When("^I can click on start application button$")
	public void i_can_click_on_start_application_button() throws Throwable {
		WebElement app_btn = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_YourConsent_StartApp_Btn_xpath));
		
		if(app_btn.isDisplayed()) {
			System.out.println("Start application button is displayed");
			app_btn.sendKeys(Keys.ENTER);			
		}
		else
			System.out.println("Start application button is NOT displayed");
	}
}
