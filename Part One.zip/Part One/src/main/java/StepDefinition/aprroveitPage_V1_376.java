package main.java.StepDefinition;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class aprroveitPage_V1_376 extends CommonSteps{

	@Then("^check last four digit number is displayed on approve it page \"([^\"]*)\"$")
	public void check_last_four_digit_number_is_displayed_on_approve_it_page(String mbNumber) throws Throwable {

//		WebDriverWait wait = new WebDriverWait(wdriver, 80);
//       WebElement validate = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
		Thread.sleep(60000);
   String msg = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
   //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='approvit-msg']")));
   int size = wdriver.findElements(By.xpath("Login_approveit_page")).size();
   String firstPart = msg.substring(0, size);
   System.out.println(firstPart);
   if (firstPart.contains(mbNumber)) 
		   System.out.println("Cellnumber displayed correct");
		   else
			  System.out.println("Cellnumber is NOT displayed correct");
	}
	
	@When("^check for qualifying criteria page is displayed$")
	public void check_for_qualifying_criteria_page_is_displayed() throws Throwable {
		String title= wdriver.findElement(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)).getText();
		if(title.equalsIgnoreCase("Qualifying criteria"))
			System.out.println("Qualifying criteria is displayed");
		else
			System.out.println("Qualifying criteria is NOT displayed");
		
	}
	

}
