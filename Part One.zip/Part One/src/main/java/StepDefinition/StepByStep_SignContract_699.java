package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import main.java.Pages.StepByStep_pages;
import cucumber.api.java.en.When;

public class StepByStep_SignContract_699 extends CommonSteps{

	@When("^check for Sign Contract icon$")
	public void check_for_Sign_Contract_icon() throws Throwable {
		String find_Vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_sign_the_contract_link_xpath)).getText();
		
		if (find_Vehicle.contains("Sign the contract"))
			System.out.println("Sign the contract icon is displayed");
		else
			System.out.println("Sign the contract icon is NOT displayed");
	}
	
	@When("^i can click on Sign Contract icon$")
	public void i_can_click_on_Sign_Contract_icon() throws Throwable {
		String find_vehicle = wdriver.findElement(By.xpath(StepByStep_pages.Step_sign_the_contract_link_xpath)).getText();
		WebElement validate = wdriver.findElement(By.xpath(StepByStep_pages.Step_sign_the_contract_link_xpath));
		//Actions actions = new Actions(wdriver); 
		if (find_vehicle.contains("Sign the contract")) {
			System.out.println("Sign the contract icon is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", validate);
			System.out.println("Clicked on Sign the contract icon");
			Thread.sleep(1000);
		}
		else
			System.out.println("Sign the contract icon is NOT displayed");
	}
	
	@When("^check for page contents of Sign Contract icon$")
	public void check_for_page_contents_of_Sign_Contract_icon() throws Throwable {
		String heading = wdriver.findElement(By.xpath(StepByStep_pages.Step_by_step_page_xpath)).getText();
		if (heading.equalsIgnoreCase("Sign the contract"))
			System.out.println("Sign the contract page id displayed");
		else
			System.out.println("Sign the contract page id NOT displayed");
		
	}
	
}
