package main.java.StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import cucumber.api.java.en.When;

public class Approveit_reject_V1_378 extends CommonSteps {

	WebDriverWait wait = new WebDriverWait(wdriver, 20);
	 
	
	@When("^wait till reject page displayed on screen$")
	public void wait_till_reject_page_displayed_on_screen() throws Throwable {
		String reject = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
		if(reject.contains("rejected")) {
			System.out.println("Rejected page displayed");
				 wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Login_page.Login_approveit_page)));
	}
		else 
			System.out.println("Rejected page is NOT displayed");
	}
	
	@When("^i can click on Ok button and check login page displayed$")
	public void i_can_click_on_Ok_button_and_check_login_page_displayed() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Login_V1.reject_Ok_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Ok button displayed");
			validate.sendKeys(Keys.ENTER);
		}
		else
			System.out.println("Ok button is NOT displayed");
	}
}
