package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dashboard_V1;
import main.java.Pages.Dealer_pages;
import main.java.Pages.StepByStep_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Dealer_483_VehicleInfo_VehicleInstalment extends CommonSteps{
	
	@When("^Fill form of About your Vehicle of dealer and click on Next button \"([^\"]*)\"$")
	public void fill_form_of_Delear_About_your_Vehicle_of_dealer_and_click_on_Next_button(String dealer) throws Throwable {
		//Select dealer
		WebDriverWait wait = new WebDriverWait(wdriver, 30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@formcontrolname='dealer']")));
		Thread.sleep(2000);
		System.out.println("Dealer field");
		Actions action = new Actions(wdriver);
		Thread.sleep(2000);
		
//		WebDriverWait wait = new WebDriverWait(wdriver, 30);
//		WebElement deal = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//INPUT[@_ngcontent-c16='']")));
		Thread.sleep(2000);		
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
		int count = 0;
		boolean clicked = false;
		Thread.sleep(2000);
		while (count < 4 || !clicked){
		    try {
		    	WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@formcontrolname='dealer']")));
		       //WebElement element= wdriver.findElement(By.xpath("//INPUT[@_ngcontent-c16='']"));
		       	if(clicked==false) {
		       	action.moveToElement(element);
				 action.click().build().perform();
				 action.sendKeys(dealer).build().perform();
				 //js.executeScript("arguments[0].value="+dealer+";", element);
				 Thread.sleep(000);
		         clicked = true;
		       	 count=4;
		       	}
		     } catch (StaleElementReferenceException e){
		       e.toString();
		       System.out.println("Trying to recover from a stale element :" + e.getMessage());
		       count = count+1;
		     }
		
		Thread.sleep(2000);
		System.out.println("dealer entered");
		Thread.sleep(2000);
		int size =  wdriver.findElements(By.xpath(Dealer_pages.dealer_abtVehicle_dealer_SelItem_xpath)).size();
		Thread.sleep(3000);
	if(size>0) {
		WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_dealer_SelItem_xpath));
		if(item.isDisplayed()) {
			System.out.println("abled to search item");
		    js.executeScript("arguments[0].click()", item);
			System.out.println("item selected");
			
			
		}
		else
			System.out.println("item not found");
	}
		else
			System.out.println("Search result is found");
	
		Thread.sleep(2000);		
	
		// Select make
		WebElement vehicleMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_xpath));
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", vehicleMake);
	    Thread.sleep(2000);
		WebElement optionMake = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleMake_selItem_xpath));
		js.executeScript("arguments[0].click()", optionMake);
		System.out.println("Vehicle make selected");
		Thread.sleep(1000);
		
		//Select model
		WebElement vehicleModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_xpath));
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", vehicleModel);
	    Thread.sleep(2000);
		WebElement optionModel = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_vehicleModel_selItem_xpath));
		js.executeScript("arguments[0].click()", optionModel);
		System.out.println("Vehicle model selected");
		Thread.sleep(1000);
		
		//Next button
		scrollToElement(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_abtVehicle_nxt_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Next button is displayed");
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button is clicked");
			Thread.sleep(2000);
		}
		else
			System.out.println("Next button is NOT displayed");
		}
	}

	@When("^check page contents of Vehicle instalment$")
	public void check_page_contents_of_Vehicle_instalment() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_pageContents_xpath));
		String heading = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_pageContents_xpath)).getText();
		if (validate.isDisplayed()) {
			if(heading.contains("Your vehicle instalments"))
				System.out.println("Your vehicle instalments page is displayed");
		}
		else
			System.out.println("Your vehicle instalments page is NOT displayed");
	}
	
	@When("^click on submit button of Vehicle Instalment of dealer$")
	public void click_on_submit_button_of_Vehicle_Instalment_of_dealer() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Submit button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Submit button is clicked");
		}
		else
			System.out.println("Next button is NOT displayed");
		Thread.sleep(3000);
	}
	
	@When("^check blank error message of Purchase Price of dealer$")
	public void check_blank_error_message_of_Purchase_Price_of_dealer() throws Throwable {
		String purchasePrice = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_Blankerr_xpath)).getText();
		if (purchasePrice.contains("This is a required field.")) 
			System.out.println("Blank Purchase price is displayed");	
		else
			System.out.println("Blank purchase price is NOT displayed");
	}
	
	@When("^I can enter purchase price of dealer \"([^\"]*)\"$")
	public void i_can_enter_purchase_price_of_dealer(String pPrice) throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_xpath)));
		WebElement price = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
//	    js.executeScript("arguments[0].value="+pPrice+";", price);
		price.sendKeys(pPrice);
			System.out.println("Purchase price entered");
		
			Thread.sleep(2000);
				
	}
	
	@When("^check error message of Purchase Price dealer$")
	public void check_error_message_of_Purchase_Price_dealer() throws Throwable {
		String purchasePrice = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_Err_xpath)).getText();
		if (purchasePrice.contains("Purchase Price cannot be less than 50000 amount")) 
			System.out.println("Purchase price message is displayed");	
		else
			System.out.println("Purchase price message is NOT displayed");
	}
	@When("^check error message of Purchase Price dealer for chars$")
	public void check_error_message_of_Purchase_Price_dealer_for_chars() throws Throwable {
		String purchasePrice = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_CharsErr_xpath)).getText();
		if (purchasePrice.contains("Please enter only two decimal number.")) 
			System.out.println("Purchase price special chars error message is displayed");	
		else
			System.out.println("Purchase price special chars error message is NOT displayed");
	}
	
	@When("^i can click on Yes button of deposit of dealer$")
	public void i_can_click_on_Yes_button_of_deposit_of_dealer() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_yesToggle_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", yesToggle);
	    System.out.println("clicked on yes toggle");
	    Thread.sleep(2000);
	}
	
	@When("^check amount is displayed$")
	public void check_amount_is_displayed() throws Throwable {
		WebElement amount = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_xpath));
		if(amount.isDisplayed())
			System.out.println("Deposit field is displayed");
		else
			System.out.println("Deposit field is NOT displayed");
		
	}
	
	@When("^i can enter value in Amount field \"([^\"]*)\"$")
	public void i_can_enter_value_in_Amount_field(String amount) throws Throwable {
		WebElement amount1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_xpath));
		amount1.sendKeys(amount);
		Thread.sleep(2000);
			System.out.println("Deposit amount entered");
			
	}
	

	@When("^check maximum value of deposit amount$")
	public void check_maximum_value_of_deposit_amount() throws Throwable {
		String purchasePrice = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_MaxValue_xpath)).getText();
		if (purchasePrice.contains("Deposit Price cannot be greater than")) 
			System.out.println("Deposit amount max value error message is displayed");	
		else
			System.out.println("Deposit amount max value error message is NOT displayed");
	}
	
	@When("^check Percentage field is displayed with min max value of dealer$")
	public void check_Percentage_field_is_displayed_with_min_max_value_of_dealer() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_VehicleInstalment_balloon_percentage_label_xpath)));

		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_balloon_percentage_label_xpath));
		if (validate.isDisplayed())
			System.out.println("Percentage field is displayed");
		else
			System.out.println("Percentage field is not displayed");
		Thread.sleep(1000);
		}	
	
	@When("^select percentage of dealer to next step$")
	public void select_percentage_of_dealer_to_next_step() throws Throwable {
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_balloon_percentage_slider_xpath));
		scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
		int width=validate1.getSize().getWidth();
		Actions actions = new Actions(wdriver);
		actions.dragAndDropBy(validate1, ((width*25)/100), 0).click().build().perform();
		Thread.sleep(2000);
		System.out.println("shifted to next step");
		//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
		Thread.sleep(1000);
	}
	
	@When("^check for blank message for instalment to begin of dealer$")
	public void check_for_blank_message_for_instalment_to_begin_of_dealer() throws Throwable {
		String errMsg = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment__err_xpath)).getText();
		if (errMsg.contains("Please select a valid date.")) 
			System.out.println("Instlment date blank error message is displayed");	
		else
			System.out.println("Instlment date blank error message is NOT displayed");
	}
	
	@When("^I can select date for Instalment to begin in dealer$")
	public void i_can_select_date_for_Instalment_to_begin_in_dealer() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_xpath));
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			scrollToElement(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
			cal.add(Calendar.DATE, 3);
			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(after);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
			scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
			System.out.println("Date after 3 days is selected");
			
		}
		else 
			System.out.println("Date after 3 days is NOT selected");
		scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
	}
	
	@When("^i can enter date for greater than sixty days of dealer$")
	public void i_can_enter_date_for_greater_than_sixty_days_of_dealer() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_xpath));
		WebElement nextMonth = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_month_xpath));
		WebElement nextMonth1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_month_xpath));
		if (validate.isDisplayed()) {
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("clicked on Date picker");
			Thread.sleep(1000);
			nextMonth.click();
			nextMonth1.click();
			scrollToElement(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath);

			Date date1 = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			
			//cal.add(Calendar.DAY_OF_YEAR, 3);
			cal.add(Calendar.DATE, 63);
			Date after = cal.getTime();
			
			
			SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
			String str = df.format(after);

			System.out.println("the date today is " + str);
			System.out.println("the date today is " + str.substring(0,2));
			//validate.sendKeys(str);
			String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
			//scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
			Thread.sleep(2000);
			//wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
//			if (wdriver.findElement(By.xpath(statement)).isDisplayed())
//				System.out.println("Date is not enabled to select. Test case Passed");
//			else
//				System.out.println("Date is enabled to select. Test case Failed");
//			Thread.sleep(5000);
//			System.out.println("Date after 60 days is selected");
			
//			WebDriverWait wait = new WebDriverWait(wdriver, 10);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(statement)));
			
			try{
	            WebDriverWait wait = new WebDriverWait(wdriver, 6);
	            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(statement)));
	            System.out.println("Date is not enabled to select. Test case Passed");
	        }
	        catch (Exception e){
	        	System.out.println("Date is enabled to select. Test case Failed");
	        }

			Thread.sleep(2000);
			
		}
		else 
			System.out.println("Date after 60 days is NOT selected");
		
	}
	
	@When("^i can select paying vehicle months$")
	public void i_can_select_paying_vehicle_months() throws Throwable {
		Thread.sleep(1000);
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath));
		scrollToElement(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath);
		int width=validate1.getSize().getWidth();
		Actions actions = new Actions(wdriver);
		actions.dragAndDropBy(validate1, ((width*25)/100), 0).click().build().perform();
		Thread.sleep(2000);
		System.out.println("shifted to next step");
		//scrollToElement(StepByStep_pages.Step_InstalmentCal_payingVehicle_label_xpath);
		Thread.sleep(2000);
	}
	
	
	@Then("^check monthly instalment calculated correct or not \"([^\"]*)\"$")
	public void check_monthly_instalment_calculated_correct_or_not(String monthExp) throws Throwable {
		String monthlyExpenses = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_monthlyExpense_xpath)).getAttribute("value");
		  if (monthlyExpenses.isEmpty())
			  System.out.println("Monthly expenses is not calculated");
		  else
			  System.out.println("Monthly expenses is calculated");	 
		  
		  if (monthlyExpenses.contains(monthExp))
			  System.out.println("It is calculated correct monthly expense" + monthlyExpenses);
		  else
			  System.out.println("It is calculated incorrect monthly expenses");
	}
	
}
