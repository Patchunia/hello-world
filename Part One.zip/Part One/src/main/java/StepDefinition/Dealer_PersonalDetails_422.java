package main.java.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;
import main.java.Pages.BuyingPages_page;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.Dealer_pages;
import main.java.Pages.Login_V1;
import main.java.Pages.Login_page;
import main.java.Pages.P2P_pages;
import cucumber.api.java.en.When;

public class Dealer_PersonalDetails_422 extends CommonSteps{

	Actions action = new Actions(wdriver);
		@When("^i can login MFC application through ID number and Cellphone number \"([^\"]*)\" \"([^\"]*)\"$")
	public void i_can_login_MFC_application_through_ID_number_and_Cellphone_number(String SAID, String mbNumber) throws Throwable {
		//enter ID number
			Thread.sleep(3000);
			WebElement validate = wdriver.findElement(By.id(Login_V1.idNumber_id));
		    if (validate.isDisplayed()) {
		    	System.out.println("ID number field is displayed");
		    	validate.sendKeys(SAID);
		    	System.out.println("ID number entered");
		    }
		    else
		    	System.out.println("ID number field is NOT displayed");
		    
		    //Enter Cellphone number
		    WebElement validate1 = wdriver.findElement(By.id(Login_V1.cellNumb_id));
		    if (validate1.isDisplayed()) {
		    	System.out.println("Cellphone number field is displayed");
		    	validate1.sendKeys(mbNumber);
		    	System.out.println("Cellphone number entered");
		    }
		    else
		    	System.out.println("Cellphone number field is NOT displayed");
		    
		    //click on check box
		    WebElement validate2 = wdriver.findElement(By.xpath(Login_V1.checkBox_xpath));
			 if(validate2.isSelected())
				{
					System.out.println("Already selected First Check box");
				}
				
				else {
					WebElement element = wdriver.findElement(By.xpath(Login_V1.checkBox_xpath));	   
				    JavascriptExecutor js = (JavascriptExecutor) wdriver;
				    js.executeScript("arguments[0].click();", element);
				   
				//wdriver.findElement(By.xpath(Login_page.Login_CheckBox1_xpath)).click();
				System.out.println("Clicked on Check box");
				}
			 //Click on Next button
			 
			 Thread.sleep(2000);
			 
			 	WebElement validate4 = wdriver.findElement(By.xpath(Login_V1.Nxt_btn_xpath));
				
			    if (validate4.isDisplayed()) {
				wdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				scrollToElement("Nxt_btn_xpath");
				wdriver.findElement(By.xpath(Login_V1.Nxt_btn_xpath)).sendKeys(Keys.ENTER);
//				JavascriptExecutor js = (JavascriptExecutor) wdriver;
//			    js.executeScript("arguments[0].click();", validate4);
				//	scrollToElement("Nxt_btn_xpath");
			    }
			    else
			    	System.out.println("Next btn is NOT displayed");
			   
			    Thread.sleep(5000);
			    
			    System.out.println("Approve it");
				WebElement validate5 = wdriver.findElement(By.xpath(Login_page.Login_approveit_page));
				if (validate5.isDisplayed())
					System.out.println("Approveit message displayed");
					//Thread.sleep(60000);
				else
					System.out.println("Approveit message is not displayed");
				WebDriverWait wait = new WebDriverWait(wdriver, 60);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath)));
	}
		
		@When("^check for qualifying criteria page and accept your consent$")
		public void check_for_qualifying_criteria_page_and_accept_your_consent() throws Throwable {
			List<WebElement> qualifyingCriteria = wdriver.findElements(By.xpath(Dashboard_V1.dashboard_qualifyingCriteria_page_xpath));
			WebElement validate_accept = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_accept_btn_xpath));
			int size = qualifyingCriteria.size();
			if (size>0) {
				System.out.println("Qualifying Criteria page is displayed");
				if (validate_accept.isDisplayed()) {
					System.out.println("Accept button displayed");
					JavascriptExecutor js = (JavascriptExecutor) wdriver;
				    js.executeScript("arguments[0].click()", validate_accept);
					System.out.println("Accept button clicked");
				}
				else
					System.out.println("Accept button is NOT displayed");
				Thread.sleep(1000);
//				String consentHeading = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_YourConsent_page_xpath)).getText();
////				WebElement consentYesBtn1 = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_Yes_xpath));
//				
//				if(consentHeading.contains("Your consent")) {
//					System.out.println("Consent page is displayed");					
	
					WebElement app_btn = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_Yes_btn1_xpath));
					
					if(app_btn.isDisplayed()) {
						Thread.sleep(1000);
						System.out.println("First Yes toggle button is displayed");
						//app_btn.sendKeys(Keys.ENTER);	
						JavascriptExecutor js = (JavascriptExecutor) wdriver;
					    js.executeScript("arguments[0].click()", app_btn);
					    System.out.println("Clicked on First Yes toggle button");
					    WebDriverWait wait = new WebDriverWait(wdriver, 20);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dashboard_V1.dashboard_consent_StartAppl_xpath)));
					    WebElement consentStartApplication = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_StartAppl_xpath));
					    scrollToElement(Dashboard_V1.dashboard_consent_StartAppl_xpath);
					    if(consentStartApplication.isEnabled()) {
				    	System.out.println("Start Application is Enabled");
//					    JavascriptExecutor js1 = (JavascriptExecutor) wdriver;
				    	
					    js.executeScript("arguments[0].click();", consentStartApplication);
					    Thread.sleep(1000);
					    }
					    else
					    	System.out.println("Start Application is NOT Enabled");
						}
//				}
//				else 
//					System.out.println("Consent page is NOT displayed");
			Thread.sleep(2000);	
			}
			
			else {
				WebElement buyingpage = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_class_xpath));
				 if (buyingpage.isDisplayed()) {
					 System.out.println("Buying from page is displayed");
					 action.moveToElement(buyingpage).perform();
					 Thread.sleep(2000);
				     WebElement nxt_btn = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_Nxt_Btn_xpath));
			        if(nxt_btn.isDisplayed()) {
			        	System.out.println("Next button of dealer is displayed");
			        	JavascriptExecutor js = (JavascriptExecutor) wdriver;
					    js.executeScript("arguments[0].click();", nxt_btn);
			        }
			        else
			        	System.out.println("Next button of dealer is NOT displayed");
			        
			}
				 else 
					 System.out.println("Buying from page is NOT displayed");
			
			}
			
				
		}
	
		@When("^i can click on Apply button of dashboard page$")
		public void i_can_click_on_Apply_button_of_dashboard_page() throws Throwable {
			WebElement validate = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_apply_btn_xpath));
			if (validate.isDisplayed()) {
				System.out.println("Apply button displayed");
				validate.sendKeys(Keys.ENTER);
			}
			else
				System.out.println("Apply button is NOT displayed");	
			
		}
		
		@When("^i can accept terms$")
		public void i_can_accept_terms() throws Throwable {
			WebElement validate = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_accept_btn_xpath));
			scrollToElement(Dashboard_V1.dashboard_accept_btn_xpath);
			if (validate.isDisplayed()) {
				System.out.println("Accept button displayed");
				validate.sendKeys(Keys.ENTER);
				System.out.println("Accept button clicked");
			}
			else
				System.out.println("Accept button is NOT displayed");	
			//Thread.sleep(1000);
			Thread.sleep(2000);
			//ConsentForm
			scrollToElement(Dashboard_V1.dashboard_YourConsent_page_xpath);
			WebElement app_btn = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_consent_Yes_btn1_xpath));
			
			if(app_btn.isDisplayed()) {
				System.out.println("First Yes toggle button is displayed");
//				 action.moveToElement(app_btn);
//		       action.sendKeys(Keys.ENTER);
//			         action.build().perform();
				JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", app_btn);
			}
			else
				System.out.println("First Yes toggle button is NOT displayed");
			
			WebElement startApp = wdriver.findElement(By.xpath(Dashboard_V1.dashboard_YourConsent_StartApp_Btn_xpath));
			
			if(startApp.isDisplayed()) {
				System.out.println("Start application button is displayed");
				//startApp.sendKeys(Keys.ENTER);
				JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", startApp);
			}
			else
				System.out.println("Start application button is NOT displayed");		        
		 
		}
		
		@When("^i can navigate to dealer information$")
		public void i_can_navigate_to_dealer_information() throws Throwable {
			Thread.sleep(1000);
			WebElement mousehover = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_class_xpath));
			action.moveToElement(mousehover).perform();
			Thread.sleep(3000);
			WebElement nxt_btntest = wdriver.findElement(By.xpath(BuyingPages_page.buying_dealer_Nxt_Btn_xpath));
		    JavascriptExecutor js = (JavascriptExecutor) wdriver;
			js.executeScript("arguments[0].click()", nxt_btntest);
			System.out.println("Clicked on Next button of dealer is displayed");
			Thread.sleep(1000);
		}
		
	@When("^Check for Personal Information page contents$")
	public void check_for_Personal_Information_page_contents() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_page_xpath));
		if (validate.isDisplayed()) {
			String page = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_page_xpath)).getText();
			if(page.contains("personal"))
				System.out.println("Personal Details page is displayed");
				else
					System.out.println("Personal Details page is NOT displayed");
			}
			
		}
	
	@When("^i can click on next button of personal info$")
	public void i_can_click_on_next_button_of_personal_info() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_nxt_btn_xpath));
		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		if (validate.isDisplayed()) {
			System.out.println("Next button of Personal info is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", validate);
			System.out.println("Next button of Personal info clicked");
		}
		else
			System.out.println("Next button of Personal info is NOT displayed");
		Thread.sleep(1000);
	}
	
	@When("^Check for Prepopulated ID number and Cellphone number \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_for_Prepopulated_ID_number_and_Cellphone_number(String SAID, String mbNumber) throws Throwable {
		String said1 = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_said_display_xpath)).getText();
		String cellnumber = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_Cellnumber_display_xpath)).getText();
		if (said1.contains(SAID)) 
			System.out.println("Identity Number is prepopulated");
		else
			System.out.println("Identity Number is NOT prepopulated");
		
		if (cellnumber.contains(mbNumber)) 
			System.out.println("Cellphone number is prepopulated");
		else
			System.out.println("Cellphone number is NOT prepopulated");
	}
	
	@When("^Check blank error message of title$")
	public void check_blank_error_message_of_title() throws Throwable {
		String blank_msg = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_title_blankField_xpath)).getText();
		if (blank_msg.equalsIgnoreCase("Please select title"))
			System.out.println("Title is blank. Please select title");
		else
			System.out.println("Title is NOT blank.");
	}
	
	@When("^I can select title of personal info$")
	public void i_can_select_title_of_personal_info() throws Throwable {
		WebElement title = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_title_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", title);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_title_option_xpath));
		js.executeScript("arguments[0].click();", option);
		System.out.println("Title selected");
		Thread.sleep(1000);
	}
	
	@When("^Check for blank error message of Firstname$")
	public void check_for_blank_error_message_of_Firstname() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_err_fname_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for first name");
		}
		else
			System.out.println("Blank error message is NOT displayed for first name");
	}
	
	@When("^i can enter first name in personal info \"([^\"]*)\"$")
	public void i_can_enter_first_name_in_personal_info(String fname) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_FirstName_xpath));
		if (validate.isDisplayed()) {
			System.out.println("First Name field displayed");
			validate.sendKeys(fname);
		    Thread.sleep(1000);
		    System.out.println("First Name entered");
		}
		else
			System.out.println("First Name field is NOT displayed");
	}
	
	@When("^Check for error message of First name for Max chars$")
	public void check_for_error_message_of_First_name_for_Max_chars() throws Throwable {
		String err = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_MaxChar_FirstName)).getText();
		if (err.contains("Maximum 55 characters allowed.")) { 
			System.out.println("Error message of max chars is displayed for first name");
		}
		else
			System.out.println("Error message of max chars is NOT displayed for first name");
		
	}
	
	@When("^check for error message of First name for special chars$")
	public void check_for_error_message_of_First_name_for_special_chars() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_err_Splfname_xpath)).getText();
		if (err.contains("Special characters not allowed.")) { 
			System.out.println("Error message of special chars is displayed for first name");
		}
		else
			System.out.println("Error message of special chars is NOT displayed for first name");
		
	}
	
	@When("^Check blank error message of blank Surname in personal info$")
	public void check_blank_error_message_of_blank_Surname_in_personal_info() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_err_fname_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for Surname");
		}
		else
			System.out.println("Blank error message is NOT displayed for Surname");
	}
	
	@When("^Check error message of Surname for Max chars$")
	public void check_error_message_of_Surname_for_Max_chars() throws Throwable {
		Thread.sleep(1000);
		String err = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_MaxChar_FirstName)).getText();
		if (err.contains("Maximum 55 characters allowed.")) { 
			System.out.println("Error message of max chars is displayed for Surname");
		}
		else
			System.out.println("Error message of max chars is NOT displayed for Surname");
		
	}
	
	@When("^Check error message of Surname for Special characters$")
	public void check_error_message_of_Surname_for_Special_characters() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_err_Splfname_xpath)).getText();
		if (err.contains("Special characters not allowed.")) { 
			System.out.println("Error message of special chars is displayed for Surname");
		}
		else
			System.out.println("Error message of special chars is NOT displayed for Surname");
		
	}
	
	@When("^i can enter Surname in personal info \"([^\"]*)\"$")
	public void i_can_enter_Surname_in_personal_info(String surname) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_surname_xpath));
		if (validate.isDisplayed()) {
			System.out.println("Surname field displayed");
			validate.sendKeys(surname);
		}
		else
			System.out.println("Surname field is NOT displayed");
	}
	
	@When("^Check blank error message of marital status$")
	public void check_blank_error_message_of_marital_status() throws Throwable {
		String blank_msg = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_maritalStatus_BlankErr_xpath)).getText();
		if (blank_msg.equalsIgnoreCase("Please select marital status"))
			System.out.println("Marital status is blank. Please select title");
		else
			System.out.println("Marital status is NOT blank.");
	}
	
	@When("^i can select marital status in personal info$")
	public void i_can_select_marital_status_in_personal_info() throws Throwable {
		WebElement marrital = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_maritalStatus_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", marrital);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_MaritalStatus_option_xpath));
		js.executeScript("arguments[0].click();", option);
		System.out.println("Marital status selected");
		Thread.sleep(1000);
	}
	
	@When("^i can enter Work telephone number \"([^\"]*)\"$")
	public void i_can_enter_Work_telephone_number(String phNumber) throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_xpath));
		if(validate.isDisplayed()) {
			wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_xpath)).sendKeys(phNumber);
			System.out.println("Work Telephone number entered");
			}
		else 
			System.out.println("Work Telephone number field not present");
	}
	
	@When("^check error message of Work Home telephone number for max digits$")
	public void check_error_message_of_Work_Home_telephone_number_for_max_digits() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_MaxDigit_xpath));
		String telMsg = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_WorkTelNumber_MaxDigit_xpath)).getText();
		Thread.sleep(1000);
		if(validate.isDisplayed()) {
			if(telMsg.contains(" Please enter valid work telephone number."))
					System.out.println("Maximum digits are entered");
			}
		else 
			System.out.println("Error message of max digits is NOT displayed");
	}

	@When("^check error message of Home telephone number for max digits$")
	public void check_error_message_of_Home_telephone_number_for_max_digits() throws Throwable {
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_HomeTelNumber_MaxDigit_xpath));
		String telMsg = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_HomeTelNumber_MaxDigit_xpath)).getText();
		if(validate.isDisplayed()) {
			if(telMsg.contains("Please enter valid home telephone number."))
					System.out.println("Maximum digits are entered");
			}
		else 
			System.out.println("Error message of max digits is NOT displayed");
		
	}
	
	@When("^i can enter Home telephone number \"([^\"]*)\"$")
	public void i_can_enter_Home_telephone_number(String phNumber) throws Throwable {
		scrollToElement(Login_page.Login_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_HomeTelNumber_xpath));
		if(validate.isDisplayed()) {
			wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_HomeTelNumber_xpath)).sendKeys(phNumber);
			System.out.println("Home Telephone number entered");
			}
		else 
			System.out.println("Home Telephone number field not present");	 
	}
	
	@When("^check blank error message for email address$")
	public void check_blank_error_message_for_email_address() throws Throwable {
		String err = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_email_blank_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for Email");
		}
		else
			System.out.println("Blank error message is NOT displayed for Email");
	}
	
	@When("^i can enter email address in personal info \"([^\"]*)\"$")
	public void i_can_enter_email_address_in_personal_info(String email) throws Throwable {
		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement validate = wdriver.findElement(By.id(P2P_pages.PersonalDetails_email_id));
		if(validate.isDisplayed()) {
			wdriver.findElement(By.id(P2P_pages.PersonalDetails_email_id)).sendKeys(email);
			System.out.println("Email entered");
			}
		else 
			System.out.println("Email field is blank");
		validate.sendKeys(Keys.TAB);
		
	}
	
	@When("check error message of email address for invalid email address$")
	public void check_error_message_of_email_address_for_invalid_email_address() throws Throwable {
		//scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement validate = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_invalid_email_xpath));
		if(validate.isDisplayed()) {
			wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_invalid_email_xpath));
			System.out.println("Invalid Email id is entered");
			}
		else 
			System.out.println("No message displayed");
	}
	
	@When("^check blank error message for country field$")
	public void check_blank_error_message_for_country_field() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_blankErr_xpath)).getText();
		if (err.contains("This is a required field.")) {
			System.out.println("Blank error message is displayed for country");
		}
		else
			System.out.println("Blank error message is NOT displayed for country");
	}

	@When("^i can enter country name \"([^\"]*)\" and select country$")
	public void i_can_enter_country_name_and_select_country(String country) throws Throwable {
		System.out.println("Born country field");
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_xpath));
		Thread.sleep(2000);		
		if(validate.isDisplayed()) {
			System.out.println("Born country field is displayed");
			Thread.sleep(1000);
			validate.sendKeys(country);
			Thread.sleep(2000);
			System.out.println("Born country entered");
		}
		else
			System.out.println("Born country field is NOT displayed");
		Thread.sleep(5000);
	
	if( wdriver.findElements(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath)).size()> 0) {
		WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath));
		if(item.isDisplayed()) {
			System.out.println("abled to search item");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", item);
			System.out.println("item selected");
		}
		else
			System.out.println("item not found");
	}
//	else {
//		String item1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_blankErr_xpath)).getText();
//		if(item1.contains("No records found")) {
//			System.out.println("Search result is not found");
//			
//		}
		else
			System.out.println("Search result is found");
		
//	}
		Thread.sleep(5000);
	}

	
	@When("check for default selection of multi nationality field of personal info$")
	public void check_for_default_selection_of_multi_nationality_field_of_personal_info() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(P2P_pages.PersonalDetails_Nationality_NoToggle_xpath));
		if (noToggle.isDisplayed())
			System.out.println("By default No toggle button selected");
		else 
			System.out.println("By default Yes toggle button selected");
	}
	
	@When("^i can click on Yes toggle button of Multinationality field$")
	public void i_can_click_on_Yes_toggle_button_of_Multinationality_field() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_multiNat_Yes_toggle_xpath));
		
			System.out.println("Yes toggle button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", yesToggle);
			 System.out.println("clicked on Yes toggle button ");
	}
	

	@When("^i can enter additional country name \"([^\"]*)\" and select country$")
	public void i_can_enter_additional_country_name_and_select_country(String addCountry) throws Throwable {
		System.out.println("Additional country field");
		
		Actions action = new Actions(wdriver);
		WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_MultiNationality_xpath));
		Thread.sleep(2000);
		validate.sendKeys(Keys.TAB);
			System.out.println("Additional country field is displayed");
			Thread.sleep(1000);
			//validate.sendKeys(addCountry);
			action.moveToElement(validate).sendKeys(addCountry).build().perform();
			Thread.sleep(2000);
			System.out.println("Additional country entered");

		Thread.sleep(5000);
	
	if( wdriver.findElements(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath)).size()> 0) {
		WebElement item = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_born_cntry_AllSelItem_xpath));
		if(item.isDisplayed()) {
			System.out.println("abled to search item");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", item);
			System.out.println("item selected");
		}
		else
			System.out.println("item not found");
	}
//	else {
//		String item1 = wdriver.findElement(By.xpath("//div[@class='error-message']")).getText();
//		if(item1.contains("No records found")) {
//			System.out.println("Search result is not found");
//			
//		}
		else
			System.out.println("Search result is found");
		
//	}
		Thread.sleep(5000);
		
	}
	
	
	@When("^check addtional country field is displayed$")
	public void check_addtional_country_field_is_displayed() throws Throwable {
		WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_AdditionalCountry_link_xpath));
		
		if(validate1.isDisplayed()) {
			System.out.println("Additional country is displayed");
			Thread.sleep(1000);
			//validate.sendKeys("test");
//			action.moveToElement(validate1).sendKeys(Keys.ENTER).build().perform();
//			System.out.println("Clicked on Add nationality plus link");
		}
		else
			System.out.println("Additional is NOT displayed");
	}
	
	@When("^check for default selection of foreign birthplace$")
	public void check_for_default_selection_of_foreign_birthplace() throws Throwable {
		WebElement noToggle = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_birthPlace_NoToggle_xpath));
		if (noToggle.isDisplayed())
			System.out.println("No toggle button of birthplace is selected");
		else
			System.out.println("No toggle button of birthplace is NOT selected");
	}
	
	@When("^i can click on yes toggle button of Foreign birth place$")
	public void i_can_click_on_yes_toggle_button_of_Foreign_birth_place() throws Throwable {
		WebElement yesToggle = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_birthPlace_YesToggle_xpath));
		
		if(yesToggle.isDisplayed()) {
			System.out.println("Yes toggle button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", yesToggle);
			 System.out.println("clicked on Yes toggle button ");
		}
		else
			System.out.println("Yes toggle button cannot be selected");
	}
	
	@When("^i can select Ethnic group in personal information$")
	public void i_can_select_Ethnic_group_in_personal_information() throws Throwable {
		scrollToElement(Dealer_pages.dealer_personalInfo_nxt_btn_xpath);
		WebElement ethnicGroup = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_EthnicGroup_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click();", ethnicGroup);
	    Thread.sleep(2000);
		WebElement option = wdriver.findElement(By.xpath("(//DIV[@_ngcontent-c14=''])[5]"));
		js.executeScript("arguments[0].click()", option);
		System.out.println("Title selected");
		Thread.sleep(1000);
		
		System.out.println("Ethnic group selected");
		Thread.sleep(1000);
	}
	
	@When("^i can click on close button of personal information$")
	public void i_can_click_on_close_button_of_personal_information() throws Throwable {
		Thread.sleep(3000);
		WebElement closeBtn = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_close_btn_xpath));
		
		if(closeBtn.isDisplayed()) {
			System.out.println("Close button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click()", closeBtn);
			 System.out.println("clicked on close button ");
		}
		else
			System.out.println("close button cannot be selected");
		
		WebElement confirmBtn = wdriver.findElement(By.xpath(Dealer_pages.dealer_personalInfo_closeExit_btn_xpath));
		
		if(confirmBtn.isDisplayed()) {
			System.out.println("Exit button is displayed");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
		    js.executeScript("arguments[0].click();", confirmBtn);
			 System.out.println("clicked on Exit button ");
		}
		else
			System.out.println("Exit button cannot be selected");
	}
	
	@When("^check for blank error message for Ethnic group$")
	public void check_for_blank_error_message_for_Ethnic_group() throws Throwable {
		String err = wdriver.findElement(By.xpath(Dealer_pages.PersonalDetails_EthnicGroup_BlankGrp_xpath)).getText();
		if (err.contains("Please select ethnic group")) {
			System.out.println("Blank error message is displayed for ethnic group");
		}
		else
			System.out.println("Blank error message is NOT displayed for ethnic group");
	}
	
}
