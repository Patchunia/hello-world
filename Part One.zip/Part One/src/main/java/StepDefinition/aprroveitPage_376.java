package main.java.StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import main.java.Pages.Dashboard_Pages;
import main.java.Pages.Dashboard_V1;
import main.java.Pages.Login_page;



public class aprroveitPage_376 extends CommonSteps {

	@Given("^I Open MFC Application In Browser and hit login page1$")
	public void i_Open_MFC_Application_In_Browser_and_hit_login_page1() throws Throwable
	{
		i_Open_MFC_link_in_Browser();
		Thread.sleep(1000);
	//	validateLoginPage();

	}
	
	@When("^I can type SA IDNew \"([^\"]*)\"$")
	public void i_can_type_SA_ID1(String SAID) throws Throwable {
		enter_SAID(SAID);
	}
	
	
	@When("^i can enter Cellphone number1 \"([^\"]*)\"$")
	public void i_can_type_SAID_N_CellNumber1(String mbNumber) throws Throwable {
		enter_Cellnumber(mbNumber);


	}
	
	
	@When("^I can click on first and second check box1$")
	public void i_can_click_on_first_and_second_check_box1() throws Throwable {
		click_on_first_and_second_check_box();
	}
	
	@When("^ApproveIT page displayed with proper message$")
	public void approveit_page_displayed_with_proper_message() throws Throwable {
		approveit_page();

	}
	
	@When("^i can click Next button$")
	public void i_can_click_Next_button() throws Throwable {
		next_btn_click();
	}
	
	@When("^ApproveIT page displayed correct last four digit cellnumber with \"([^\"]*)\"$")
	public void approveit_page_displayed_correct_last_four_digit_cellnumber_with(String mbNumber) throws Throwable {
	    Thread.sleep(60000);
	   String msg = wdriver.findElement(By.xpath(Login_page.Login_approveit_page)).getText();
	   
	   int size = wdriver.findElements(By.xpath(Login_page.Login_approveit_page)).size();
	   String firstPart = msg.substring(0, size);
	   if (msg.contains(firstPart)) 
		   System.out.println("Cellnumber displayed correct");
		   else
			  System.out.println("Cellnumber is NOT displayed correct");
		   
	   }
	
	@When("^i can click on close button$")
	public void i_can_click_on_close_button() throws Throwable {
		
		WebElement validate = wdriver.findElement(By.xpath(Dashboard_Pages.ApproveIt_close_btn_xpath));
		if (validate.isDisplayed()) {
			Thread.sleep(2000);
			wdriver.findElement(By.xpath(Dashboard_Pages.ApproveIt_close_btn_xpath)).click();
			System.out.println("clicked on close button");
		}
		else
			System.out.println("Not able to click on close button");
	}
	
	}
	
	

		
	
	
	
