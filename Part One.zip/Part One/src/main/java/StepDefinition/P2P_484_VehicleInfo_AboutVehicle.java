package main.java.StepDefinition;

public class P2P_484_VehicleInfo_AboutVehicle extends CommonSteps{
	
	

}
