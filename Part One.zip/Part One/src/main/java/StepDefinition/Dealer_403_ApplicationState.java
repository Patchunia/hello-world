package main.java.StepDefinition;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.java.Pages.Dealer_pages;
import main.java.Pages.VehicleInfo_page;
import cucumber.api.java.en.When;

public class Dealer_403_ApplicationState extends CommonSteps{
	
	@When("^Fill form of Vehicle installment of dealer and click on Next \"([^\"]*)\" \"([^\"]*)\"$")
	public void Fill_form_of_Vehicle_installment_of_dealer_and_click_on_Next(String purchasePrice, String amount) throws Throwable {
		//Purchase price
		WebElement price = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_purchasePrice_xpath));
		price.sendKeys(purchasePrice);
		System.out.println("Purchase price entered");
		Thread.sleep(2000);
		//amount
		
		WebElement yesToggle = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_yesToggle_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", yesToggle);
	    System.out.println("clicked on yes toggle");
	    Thread.sleep(2000);
	    
	    WebElement amount1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_deposit_xpath));
		amount1.sendKeys(amount);
		Thread.sleep(2000);
			System.out.println("Deposit amount entered");
			
			WebElement validate = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_dateInstalment_xpath));
			if (validate.isDisplayed()) {
				//JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", validate);
				System.out.println("clicked on Date picker");
				Thread.sleep(1000);
				scrollToElement(Dealer_pages.dealer_VehicleInstalment_paying_slider_xpath);

				Date date1 = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				
				//cal.add(Calendar.DAY_OF_YEAR, 3);
				cal.add(Calendar.DATE, 3);
				Date after = cal.getTime();
				
				
				SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
				String str = df.format(after);

				System.out.println("the date today is " + str);
				System.out.println("the date today is " + str.substring(0,2));
				//validate.sendKeys(str);
				String statement = "//*[@class='dp-calendar-day dp-current-month'][contains(text(),'"+ str.substring(0,2)+"')]";
				scrollToElement(VehicleInfo_page.vehicleInfo_next_btn_xpath);
				wdriver.findElement(By.xpath(statement)).sendKeys(Keys.ENTER);
				System.out.println("Date after 3 days is selected");
				
			}
			else 
				System.out.println("Date after 3 days is NOT selected");
			
		//Submit button
			WebElement validate1 = wdriver.findElement(By.xpath(Dealer_pages.dealer_VehicleInstalment_submit_btn_xpath));
			if (validate1.isDisplayed()) {
				System.out.println("Submit button is displayed");
				//JavascriptExecutor js = (JavascriptExecutor) wdriver;
			    js.executeScript("arguments[0].click();", validate1);
				System.out.println("Submit button is clicked");
			}
			else
				System.out.println("Next button is NOT displayed");
			
	}
	
	@When("^check for reference number of application state of dealer generated or not$")
	public void check_for_reference_number_of_application_state_of_dealer_generated_or_not() throws Throwable {
		WebDriverWait wait = new WebDriverWait(wdriver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Dealer_pages.dealer_ApplicationState_ReferenceNo_xpath)));

		String ref = wdriver.findElement(By.xpath(Dealer_pages.dealer_ApplicationState_ReferenceNo_xpath)).getText();
		System.out.println(ref);
		String refNo= ref.substring(5, 14);
		System.out.println(refNo);
		if (refNo.isEmpty())
			System.out.println("Reference Number is NOT generated");
		else
			System.out.println("Reference Number is generated");
	}
	
	@When("^i can click on continue button$")
	public void i_can_click_on_continue_button() throws Throwable {
		WebElement continue_btn = wdriver.findElement(By.xpath(Dealer_pages.dealer_ApplicationState_Continue_xpath));
		JavascriptExecutor js = (JavascriptExecutor) wdriver;
	    js.executeScript("arguments[0].click()", continue_btn);
	    System.out.println("clicked on continue button");
	}

}
