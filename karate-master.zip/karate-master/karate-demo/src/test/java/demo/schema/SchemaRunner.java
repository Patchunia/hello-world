package demo.schema;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

/**
 *
 * @author pthomas3
 */
@RunWith(Karate.class)
public class SchemaRunner {
    
}
