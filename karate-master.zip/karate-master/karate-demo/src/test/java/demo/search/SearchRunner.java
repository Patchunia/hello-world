package demo.search;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/search/dynamic-params.feature")
public class SearchRunner extends TestBase {
    
}
