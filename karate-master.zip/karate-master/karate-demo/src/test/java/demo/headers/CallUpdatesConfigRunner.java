package demo.headers;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/headers/call-updates-config.feature")
public class CallUpdatesConfigRunner extends TestBase {
    
}
