package demo.headers;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/headers/headers-form-get.feature")
public class HeadersFormGetRunner extends TestBase {
    
}
