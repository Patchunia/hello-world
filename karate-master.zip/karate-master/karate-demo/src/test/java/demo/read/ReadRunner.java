package demo.read;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/read/read-files.feature")
public class ReadRunner extends TestBase {
    
}
