package demo.params;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class ParamsRunner extends TestBase {
    
}
