package demo.callarray;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/callarray/call-json-array.feature")
public class CallJsonArrayRunner extends TestBase {
    
}
