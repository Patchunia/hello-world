package demo.delete;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class DeleteRunner extends TestBase {

}
