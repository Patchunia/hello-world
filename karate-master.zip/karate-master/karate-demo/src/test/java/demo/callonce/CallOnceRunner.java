package demo.callonce;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class CallOnceRunner extends TestBase {
    
}
