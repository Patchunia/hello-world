package demo.cookies;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class CookiesRunner extends TestBase {
    
}
