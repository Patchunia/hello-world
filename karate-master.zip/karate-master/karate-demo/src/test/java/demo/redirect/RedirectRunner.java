package demo.redirect;

import cucumber.api.CucumberOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@CucumberOptions(features = "classpath:demo/redirect/redirect.feature")
public class RedirectRunner extends TestBase {
    
}
