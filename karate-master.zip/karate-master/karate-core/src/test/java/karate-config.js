function() {   
  return { someConfig: 'someValue' }
}