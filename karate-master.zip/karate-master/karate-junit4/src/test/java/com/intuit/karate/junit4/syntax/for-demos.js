function() {
  // this file is used by another package and is to test
  // reading files via 'relative paths' from the 'demos' package
  return 'foo'; 
}
