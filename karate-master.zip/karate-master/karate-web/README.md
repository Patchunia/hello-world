# Karate Web

## On Hold !
Instead - please use the [Karate UI](https://github.com/intuit/karate/wiki/Karate-UI) built-in to the karate-core Maven artifact (JAR) itself.

## Instructions
A 'Saas' option for Karate would be great in the future. If you can, do consider contributing to this !

Refer to [this video](https://twitter.com/ptrthomas/status/861249247282319360)

