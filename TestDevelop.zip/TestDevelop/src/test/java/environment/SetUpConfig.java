package environment;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class SetUpConfig {
	Properties prop = new Properties();
	InputStream input = null;
	public static String url = "";
	
	public void setUpUrl() {
		try {
			input = new FileInputStream("target/classes/application.properties");

			// load a properties file
			prop.load(input);
			url = prop.getProperty("url");
			System.out.println(prop.getProperty("username"));
			System.out.println(prop.getProperty("password"));
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
