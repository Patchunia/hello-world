import static org.hamcrest.Matchers.equalTo;
import io.restassured.builder.*;
import io.restassured.specification.*;
import io.restassured.response.*;
import org.junit.*;
import org.junit.runners.Parameterized.*;
import org.junit.runner.*;
import org.junit.runners.*;
import static io.restassured.RestAssured.*;
import java.util.*;

@RunWith(Parameterized.class)
public class MyTest {

	private ResponseSpecification respSpec = null;
	private RequestSpecification reqSpec = null;
	private Response response = null;
	private RequestSpecBuilder reqSpecBuilder = null;
	
	@Parameter // first data value (0) is default
	public String code;
	@Parameter(1) // first data value (0) is default
	public String all;
	@Parameter(2)
	public String expectedPathValue;

	@Test
	public void asParameterizedTest() {
		setReqSpec(code,all);
		setRespSpec(expectedPathValue);
		reqSpec.given().log().all();
		response = given(reqSpec, respSpec).get("{code}", "{all}");
		response.then().log().all();
		
	}
  private void setRespSpec(String expectedPathValue) {
		respSpec = new ResponseSpecBuilder().expectStatusCode(200).expectBody("RestResponse.result.name", equalTo(expectedPathValue)).build();
  }
  
  private void setReqSpec(String code, String all) {
		reqSpec = new RequestSpecBuilder().setBaseUri("http://services.groupkt.com").setBasePath("/state/get/").addPathParam("code",code).addPathParam("all",all).build();
  }
  
  private void setReqSpecBuilder() {
	  reqSpecBuilder = null;
	  reqSpecBuilder = new RequestSpecBuilder();
  }
  
  private void setReqSpecBuilderBaseUri(String baseUri) {
	  System.out.println(baseUri);
	  reqSpecBuilder.setBaseUri(baseUri);
	  System.out.println(baseUri);
  }

  private void setReqSpecBuilderBasePath(String basePath) {
	  reqSpecBuilder.setBasePath(basePath);
  }

  private void addPathParam(String paramName, String paramValue) {
	  reqSpecBuilder.addPathParam(paramName, paramValue);
  }

  @Parameters
  public static Collection<Object[]> data() {
      return Arrays.asList(new Object[][]{
               { "USA","all","United States of America"}, 
               {"ZA","all","South Africa"},
               {"SA","all","South America"}
               
         });
  }
}
