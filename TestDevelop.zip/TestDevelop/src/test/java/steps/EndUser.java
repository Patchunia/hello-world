package steps;

import net.thucydides.core.annotations.Step;
import pageobjects.PageS;


public class EndUser{

	
    PageS registerUser;
    
	@Step
    public void is_the_home_page() {
		 registerUser.openPage();
    }
    @Step
	public void signup(String arg1,String arg2,String arg3,String arg4,String arg5) {
    	registerUser.createUsers(arg1,arg2,arg3,arg4,arg5);
	}
    @Step
	public void accessthesystem() {
		System.out.println("End");
	}
}
