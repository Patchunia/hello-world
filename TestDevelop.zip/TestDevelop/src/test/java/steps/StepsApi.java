package steps;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.jws.soap.*;
import net.thucydides.core.annotations.Step;
import org.tempuri.*;

public class StepsApi {
	private ObjectFactory service = null;
	private Add add = null;
	private Calculator calc = null;

	@Step
	public void getInstance() {
		service = new ObjectFactory();
		add = service.createAdd();

		
	}

	@Step
	public void createResquest() {
		System.out.println("000");
		add.setIntA(30);
		System.out.println("001");
		add.setIntB(30);
		System.out.println("002");
		calc = new Calculator();
		int answer = calc.getCalculatorSoap().add(add.getIntA(), add.getIntB());
		System.out.println("003");
		service.createAddResponse().setAddResult(answer);
		
	}

	@Step
	public void getSoapResponse() {
		System.out.println("Response000");
		int answer = service.createAddResponse().getAddResult();
		System.out.println("answer from response is >>> " + answer);
	}
}
