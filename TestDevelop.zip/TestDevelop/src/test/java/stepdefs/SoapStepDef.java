package stepdefs;

import org.slf4j.LoggerFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import steps.StepsApi;;

public class SoapStepDef {
	 @Steps
	    StepsApi apiSteps;

	    @Given("^a client wants to create a calculation$")
	    public void soap_requestCalculatorApp() {
	    	apiSteps.getInstance();
	    }

	    @When("^they provide two numbers and a operation$")
	    public void soap_provideValidData() {
	    	apiSteps.createResquest();
	    }

	    @Then("^system should give valid response information$")
	    public void soap_systemSoapResponse() {
	    	apiSteps.getSoapResponse();
	    }
}
