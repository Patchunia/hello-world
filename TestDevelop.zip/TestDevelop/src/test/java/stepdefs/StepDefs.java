package stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import steps.EndUser;

public class StepDefs {
	 @Steps
	    EndUser users;

	    @Given("^A client is on mercury tours landing page$")
	    public void user_can_access_landingpage() {
	    	users.is_the_home_page();
	    }

	    @When("^they try to sign up a user (.*) (.*) (.*) (.*) (.*)$")
	    public void request_to_signup(String arg1,String arg2,String arg3,String arg4,String arg5) {
	    	System.out.println(arg1+">>"+arg2);
	       users.signup(arg1, arg2, arg3, arg4, arg5);
	    }

	    @Then("^system should allow a successful application$")
	    public void access_the_system() {
	     users.accessthesystem();
	    }
}
