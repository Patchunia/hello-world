package stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RestStepDef {
	@Given("^A customer has an existing ISO (.*)$")
    public void rest_checkISO(String isoName) {
		System.out.println(">?? IMplement REST next 00");
    }

    @When("^they request to get the corresponding name of iso$")
    public void rest_requestNames() {
    	System.out.println(">?? IMplement REST next 01");
    }

    @Then("^A successful message should be displayed$")
    public void rest_messageDisplaed() {
    	System.out.println(">?? IMplement REST next 02");
    }
}
