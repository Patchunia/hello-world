function(fileName) {
  var text = karate.read(fileName);
  return text;
}
